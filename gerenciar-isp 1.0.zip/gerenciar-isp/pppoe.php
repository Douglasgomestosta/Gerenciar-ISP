﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
            $senha = $row["senha"];
            $cpf = $row["cpf"];
            $cepantigo = $row["cep"];
            $numeroantigo = $row["numero"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
        }
    }


    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
            $senhapppoe = $row["senha"];
            $ip = $row["ip"];
            $roteador = $row["roteador"];
            $mac = $row["mac"];
            $ativopppoe = $row["ativo"];
            $servidor = $row["servidor"];

        }
    }
}
else
{
    header('Location: login.php');
}

if($_GET['desconectar'] == "1")
{

    $sql = "SELECT * FROM `servidores` WHERE `id` = " . $servidor;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $ipservidor = $row["ipprivado"];

        }
    }
    echo shell_exec('echo "User-Name=' . $usuariopppoe . '" | radclient -x ' . $ipservidor . ':3799 disconnect ' . $secret);




    header('Location: pppoe.php');
}

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />



<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


</style>


   <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <h3>Dados do serviço PPPOE</h3>
<h5>PPPoE é o serviço utilizado para a autenticação e controle do seu serviço a internet </h5><BR>
<h4>Usuario PPPOE: <?php echo $usuariopppoe; ?> </h4>
<h4>Senha PPPOE: <?php echo $senhapppoe; ?> </h4>
<h4>Endereço Ipv4: <?php echo $ip; ?> </h4>
<h4>Roteador: <?php echo $roteador; ?> </h4>
<h4>endereço MAC: <?php echo $mac; ?> </h4>
<h4>PPPoE ativo: <?php echo $ativopppoe; ?> </h4>
<h4>Servidor alocado: <?php echo $servidor; ?> </h4>
<?php
//Ver se usuario está conectado
require 'sistema/logadopppoe.php'; 
if($desconectado == 1){
        ?>
        <h4>Atualmente, seu roteador está <a style="color:red;">DESCONECTADO</a> a internet, você foi desconectado as <?php echo $stoptime; ?> pelo motivo: <?php echo $motivodesconect; ?></h4>
<?php
    }
    else
    {
?>
<h4>Atualmente, seu roteador está <a style="color:green;">CONECTADO</a> a internet, conexão realizada as <?php echo $starttime; ?></h4>
    <?php
    }
//
?>
<br><br>
<a onclick="desconectar()" style="width: 100%;
  background-color: red;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Desconectar usuario</a><br>

<script>
function desconectar()
{
var x;
var r=confirm("Ao desconectar o seu roteador do nosso serviço PPPoE, a sua conexão a internet ficara indisponivel  Lembre-se que geralmente ao ser desconectado o seu roteador tentara se reconectar, voltando a conexão em poucos segundos, deseja continuar?");
if (r==true)
  {
    window.location.href = "?desconectar=1"; 
  }
else
  {
  
  }

}
</script>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
