<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE); 
require 'sistema/db.php'; 
require 'sistema/FUNCTIONS.php'; 
if (!empty($_GET['redirect'])) {
    if (strpos($_GET['redirect'], 'http://') !== false) { exit();}
        if (strpos($_GET['redirect'], 'https://') !== false) { exit();}
            if (strpos($_GET['redirect'], 'www.') !== false) { exit();}
}
if($_SESSION['login'] == 1)
{
    if(!$_GET['sucesso'] == "1"){
    
    if (empty($_GET['redirect'])) {
        header('Location: painel.php');
    }else
    {
        header('Location: ' . $_GET['redirect']);
    }


    }
}
$token = sqlinjection($_GET['token']);
$sql = "SELECT * FROM `autologin` WHERE `token` = '" . $token . "'";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$cliente = $row['idcliente'];
$sqll = "SELECT * FROM `usuarios` WHERE `id` = 1";
$resultt = $conn->query($sqll);
if ($resultt->num_rows > 0) {
while($roww = $resultt->fetch_assoc()) {

    $_SESSION['login'] = "1";
                      $_SESSION['email'] = $roww["email"];
                      $_SESSION['id'] = $roww["id"];
                      $_SESSION['usuariocomum'] = "1";
                      $_SESSION['nome_completo'] = $roww["nome"];
                      header('Location: painel.php'); 
}
}else{
    header('Location: login.php'); 
}
    }
}else{
    header('Location: login.php'); 
}
