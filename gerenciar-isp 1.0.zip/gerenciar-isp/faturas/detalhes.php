﻿<?php
session_start();

require '../sistema/db.php';
require '../sistema/FUNCTIONS.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
            $asaasid = $row["asaasid"];
            $cpf = $row["cpf"];
            $cnpj = $row["cnpj"];
            $nome = $row["nome"];
            $array=explode(" ",$nome);
            $nome = $array[0];
            $sobrenome = $array[1];

        }
    }

    if(empty($cpf)){
        $tipodocumento = "cnpj";
        $documento = $cnpj;
    }else{
        $tipodocumento = "cpf";
        $documento = $cpf; 
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
        }
    }
}
else
{
    header('Location: ../login.php');
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />



<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


</style>


   <script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../../index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="../../exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    <?php
$idsuporte = $_GET['id'];

if (!is_numeric($idsuporte)) {
   exit;
  }
///faturas


//$sql = "SELECT * FROM `pagamentos` WHERE `id` = " . $idsuporte;
$sql = "SELECT * FROM `pagamentos` WHERE `id` = " . $idsuporte . " AND `idusuario` = " . $id ;
$result = $conn->query($sql);
///

?>


 
<div class="panel panel-default">
                      
<?php
                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                        while($row = $result->fetch_assoc()) {
                                            $preco = $row["valor"];
                                            $vencimento = $row["vencimento"];
                                            $status = $row["pago"];
                                            $pagodata = $row["pagodata"];
                                            $idfatura = $row["id"];
                                            $checkout = $row["checkout"];
                                            $checkoutid = $row["checkoutid"];
                                            $descricao = $row["descricao"];
                                            $array=explode("-",$vencimento);
                                            $mes = $array[1];
                                            $dia = $array[2];
                                            $ano = $array[0];
                                            $vencimento =  "$dia/$mes/$ano";
                                            $array=explode("-",$pagodata);
                                            $mes = $array[1];
                                            $dia = $array[2];
                                            $ano = $array[0];
                                            $pagodata =  "$dia/$mes/$ano";

                                            $statusexterno = "Fatura em aberto";
                                            $statuscor = "green";
                                            if($status == "1")
                                            {
                                                $statustexto = "Fatura liquidada";
                                                $statuscor = "green";
                                            }
                                            if($row["vencido"] == "1")
                                            {
                                                if($row["pago"] == "1")
                                                {
                                                    $statusexterno = "Fatura liquidada após o vencimento";
                                                    $statuscor = "red";
                                                }else{
                                                    $statusexterno = "Fatura vencida e não liquidada!";
                                                    $statuscor = "red";
                                                }
                                            }
                                            //colocar forma de pagamento
                                            if(empty($checkout)){
                                                //Mercadopago
                                            if(true)
                                            {
                                             
//$vencimentofatura = date('Y-m-d', strtotime($row["vencimento"]. ' + 5 days'));                                
$array=explode("-",$row["vencimento"]);
                                            $mes = $array[1];
                                            $dia = $array[2] + 2;
                                            $ano = $array[0];
                                            $vencimento =  "$dia/$mes/$ano";
                                            $vencimentomercadopago = "$ano-$mes-$dia";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.mercadolibre.com/checkout/preferences?access_token=TOKEN-MERCADO-PAGO');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
//curl_setopt($ch, CURLOPT_POSTFIELDS, "{\n    \"items\": [\n        {\n            \"title\": \"Conexão a internet Data Web, fatura numero " . $idfatura . "\",\n            \"quantity\": 1,\n      \"external_reference\": \"" . $idfatura . "\",\n       \"unit_price\": " . $preco . "\n        }\n    ]\n}");
curl_setopt($ch, CURLOPT_POSTFIELDS, '{   "items": [        {           "title": "Conexão a internet Data Web, fatura numero ' . $idfatura . '",            "quantity": 1,     "unit_price": ' . $preco . '        }    ], "payer": {"first_name": "' . $nome . '", "last_name": "' . $sobrenome . '", "email": "' . $email . '", "identification": { "type": "' . $tipodocumento . '", "number": "' . $documento . '"}},  "external_reference": "' . $idfatura . '", "date_of_expiration": "' . $vencimentomercadopago . '", "callback_url": "https://painel.datawebtelecom.site/faturas/detalhes.php?id=' . $idsuporte . '"  }');
$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'Cache-Control: no-cache';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);


$result = json_decode( $result, FALSE );


                     $idpagamento = $result->id;
$checkoutid = $idpagamento;
$checkout = "mercadopago";

                     $sql = "UPDATE `pagamentos` SET `checkout` = 'mercadopago', `checkoutid` = '" . $idpagamento . "' WHERE `pagamentos`.`id` = " . $idfatura . ";";
$result = $conn->query($sql);

                     

                                            }
                                            }


                                            //ver se a fatura foi atualizada

if($checkout == "mercadopago")
{
    if(empty($status)){
    $referencia = $idsuporte;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.mercadopago.com/v1/payments/search?access_token=TOKEN-MERCADO-PAGO&external_reference=' . $referencia);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch, CURLOPT_POST, 1);
//curl_setopt($ch, CURLOPT_POSTFIELDS, "{\n    \"items\": [\n        {\n            \"title\": \"Conexão a internet Data Web, fatura numero " . $idfatura . "\",\n            \"quantity\": 1,\n            \"unit_price\": " . $preco . "\n        }\n    ]\n}");
//curl_setopt($ch, CURLOPT_POSTFIELDS, "access_token=APP_USR-8577420671656709-032615-60fadbf4bb5e81e5b322b78f027ca140-207928615&status=approved&offset=0&limit=10`");

$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'Cache-Control: no-cache';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);

$result = json_decode( $result, FALSE );

$statuss = $result->results[0]->status;

if($statuss == "approved")
{
    $sql = "UPDATE `pagamentos` SET `pago` = '1', `pagodata` = CURRENT_DATE WHERE `pagamentos`.`id` = " . $idsuporte .";";
    $result = $conn->query($sql);
?>
<div class="alert alert-danger" style="background-color:green; color:white;">
Houve uma atualização na sua fatura! seu pagamento foi aprovado
<center><a href="?id=<?php echo $idsuporte; ?>" class="btn btn-primary btn-lg">Atualizar página</a></center>
</div>
<?php
}
}
}
                                            //fim ver se a fatura foi atualizada
                                           ?>


<div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Sua fatura de internet
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <div class="">

                                            <?php
                                            $precoexibido = $preco;
                                            $precoexibido = str_replace('.', ',', $precoexibido);
                                            $array=explode(",",$precoexibido);
                                            $teste = $array[1];
                                            $teste = strlen($teste);
                                            if($teste == 1)
                                            {
                                                $precoexibido = $precoexibido . "0";
                                            }
                                            ?>
				


                                           <h3>Fatura de numero <?php echo $idfatura; ?>  com vencimento em <?php echo $vencimento; ?></h3>
                                           <h3>Valor: <a style="color:green;"> R$<?php echo $precoexibido; ?> </a> </h3>
                                           <h3>Status: <a style="color:<?php echo $statuscor; ?>;"> <?php echo $statusexterno; ?>  </a></h3>
                                           <h3>Descrição da fatura:<br> <?php echo $descricao; ?></h3>
                                           <?php
                                           //mostrar as formas de pagamento
                                           if(empty($checkout)){
                                            ?>
                                            <h3>Qual a sua forma de pagamento desejada? </h3>
                                            
                                            <?php
                                        }



                                        //Mostrar pagamento feito
                                        if($status == "1")
                                        {
                                            ?>
                                            <div class="">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            Sua fatura foi paga com exito
                        </div>
                        <div class="panel-body">
                            <p>Esta fatura já foi paga no dia <?php echo $pagodata; ?> usando a forma de pagamento <?php echo $checkout; ?></p>
                        </div>
                        
                    </div>
                </div>
                                            <?php
                                        }


                                        $data = date("Y-m");
$dia = date("d");
$dia = $dia - 1;
$data = date("Y-m");
$datateste = $data . "-" . $dia;

$sql = "SELECT * FROM `pagamentos` WHERE `id` = " . $idfatura . " AND `vencimento` < '" . $datateste . "' AND `pago` IS NULL AND `vencido` IS NOT NULL";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
$fimdevez = "1";
    }
}

if($fimdevez == "1")
{
 ?>
 <div class="">
                    <div class="panel panel-danger">
                        <div class="panel-heading" style="color:black; background-color:red;">
                            Fatura Vencida!
                        </div>
                        <div class="panel-body">
<h3>Já se passaram mais de dois dias desde que sua fatura foi considerada vencida, e você não pode mais pagar-la! </h3>
                        </div>
                        <div class="panel-footer">
                        </div>
                    </div>
                </div>
 <?php
}


                                        //mostrar o botão de pagamento mercadopago
                                        if($checkout == "mercadopago" && !$status == "1" && !$fimdevez == "1")
                                        {
?>

<div class="">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Pagar fatura usando MercadoPago
                        </div>
                        <div class="panel-body">
                            <p>Pague sua fatura utilizando MercadoPago com cartão de crédito, Boleto, pagamento na lotérica e saldo em conta digital MercadoPago.</p>
                       
                            <form action="/processar_pagamento" method="POST">
  <script
   src="https://www.mercadopago.com.br/integrations/v1/web-payment-checkout.js"
   data-preference-id="<?php echo $checkoutid; ?>">
  </script>
</form>
                       
                        </div>
                        <div class="panel-footer">
                            Pagamentos na lotérica podem levar 1 hora para serem processadas, pagamento de boletos até 2 dias, pagamento com saldo em conta e cartão de crédito são instantâneas.
                        </div>
                    </div>
                </div>

<?php
                                        }
         
}
                                    }
?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>




										
									

                    </div>
                                    </div>
                    </div>
                    </div>


                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
    
   
</body>
</html>
