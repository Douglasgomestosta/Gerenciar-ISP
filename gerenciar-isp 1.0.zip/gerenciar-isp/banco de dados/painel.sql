-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 14-Jan-2021 às 08:19
-- Versão do servidor: 10.4.17-MariaDB
-- versão do PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `painel`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `adesao`
--

CREATE TABLE `adesao` (
  `id` int(11) NOT NULL,
  `email` varchar(244) NOT NULL,
  `nome` varchar(244) NOT NULL,
  `senha` varchar(244) NOT NULL,
  `cep` varchar(244) NOT NULL,
  `numero` varchar(244) NOT NULL,
  `sobreacasa` varchar(244) DEFAULT NULL,
  `plano` varchar(244) NOT NULL,
  `cpf` varchar(244) NOT NULL,
  `roteador` varchar(244) NOT NULL,
  `datapedido` datetime NOT NULL DEFAULT current_timestamp(),
  `andamento` int(11) NOT NULL,
  `tecnico` int(11) NOT NULL,
  `cancelado` int(11) NOT NULL,
  `resposta` varchar(244) NOT NULL,
  `horario` varchar(244) NOT NULL,
  `finalizadodata` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `email` varchar(244) NOT NULL,
  `senha` varchar(244) NOT NULL,
  `nome` varchar(244) NOT NULL,
  `nivel` int(11) NOT NULL,
  `cidade` varchar(244) NOT NULL,
  `foto` varchar(244) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `admins`
--

INSERT INTO `admins` (`id`, `email`, `senha`, `nome`, `nivel`, `cidade`, `foto`) VALUES
(1, 'douglasgomestosta@gmail.com', '202cb962ac59075b964b07152d234b70', 'Douglas Gomes', 1, 'seropedica', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `agendas`
--

CREATE TABLE `agendas` (
  `id` int(11) NOT NULL,
  `idadmin` int(11) NOT NULL,
  `data` datetime NOT NULL DEFAULT current_timestamp(),
  `tipo` int(11) DEFAULT NULL,
  `idtipo` int(11) DEFAULT NULL,
  `resolvido` int(11) DEFAULT NULL,
  `resolvidodata` datetime DEFAULT NULL,
  `marcado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `agendas`
--

INSERT INTO `agendas` (`id`, `idadmin`, `data`, `tipo`, `idtipo`, `resolvido`, `resolvidodata`, `marcado`) VALUES
(6, 1, '2020-11-16 04:08:29', NULL, NULL, NULL, NULL, NULL),
(11, 1, '2020-11-25 04:08:42', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `autenticacoes`
--

CREATE TABLE `autenticacoes` (
  `id` int(11) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `data` datetime NOT NULL DEFAULT current_timestamp(),
  `navegador` varchar(244) COLLATE utf8_bin NOT NULL,
  `ip` varchar(244) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `autenticacoes`
--

INSERT INTO `autenticacoes` (`id`, `idcliente`, `data`, `navegador`, `ip`) VALUES
(252, 1, '2020-10-15 14:54:04', 'Mozilla/5.0 (Linux; Android 10; moto g(8) power lite Build/QOD30.160-26; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.75 Mobile Safari/537.36', ''),
(253, 1, '2020-10-15 17:07:51', 'Mozilla/5.0 (Linux; Android 9; moto g(7) play Build/PPYS29.105-134-12; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/85.0.4183.127 Mobile Safari/537.36', ''),
(254, 1, '2020-10-16 17:07:09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.234', ''),
(255, 1, '2020-10-16 17:28:24', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.234', ''),
(256, 1, '2020-10-17 15:56:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36', ''),
(257, 1, '2020-10-17 18:28:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.234', ''),
(258, 1, '2020-10-19 00:12:08', 'Mozilla/5.0 (Linux; Android 7.1.1; ONEPLUS A3010 Build/NMF26F; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/72.0.3626.121 Mobile Safari/537.36', ''),
(259, 1, '2020-10-20 18:00:14', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.234', ''),
(260, 1, '2020-10-21 20:33:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.234', ''),
(261, 1, '2020-10-22 01:07:52', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.234', ''),
(262, 1, '2020-10-22 01:27:36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.234', ''),
(263, 1, '2020-10-23 02:37:27', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.110 Mobile Safari/537.36', ''),
(264, 2, '2020-10-23 06:30:52', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.198', ''),
(265, 1, '2020-10-27 11:37:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(266, 1, '2020-10-29 06:55:18', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(267, 1, '2020-10-29 07:03:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(268, 1, '2020-10-29 07:16:13', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(269, 1, '2020-10-29 07:16:24', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(270, 1, '2020-10-29 07:18:59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(271, 1, '2020-10-29 07:19:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(272, 1, '2020-10-29 07:20:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(273, 1, '2020-10-29 07:23:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(274, 1, '2020-10-29 16:06:10', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.114 Mobile Safari/537.36', ''),
(275, 1, '2020-10-31 11:39:13', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', ''),
(276, 1, '2020-11-01 16:34:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', ''),
(277, 1, '2020-11-02 15:34:20', 'Mozilla/5.0 (Linux; Android 10; moto g(8) power lite) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.114 Mobile Safari/537.36', ''),
(278, 1, '2020-11-03 12:52:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(279, 8, '2020-11-03 17:46:14', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(280, 8, '2020-11-03 22:00:23', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(281, 1, '2020-11-04 18:24:22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(282, 1, '2020-11-05 20:11:26', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(283, 1, '2020-11-05 23:54:23', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.185 Mobile Safari/537.36', ''),
(284, 1, '2020-11-06 14:32:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(285, 1, '2020-11-06 19:51:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(286, 8, '2020-11-06 19:55:39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.287', ''),
(287, 1, '2020-11-08 22:35:43', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.185 Mobile Safari/537.36', ''),
(288, 1, '2020-11-08 22:48:33', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.185 Mobile Safari/537.36', ''),
(289, 1, '2020-11-09 16:24:33', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(290, 1, '2020-11-09 16:27:03', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(291, 1, '2020-11-09 16:36:51', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(292, 1, '2020-11-09 17:26:10', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(293, 1, '2020-11-09 17:33:12', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(294, 1, '2020-11-09 17:46:18', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(295, 1, '2020-11-09 17:47:54', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(296, 1, '2020-11-09 18:57:40', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(297, 1, '2020-11-09 19:07:35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.310', ''),
(298, 1, '2020-11-09 19:29:25', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(299, 1, '2020-11-09 19:34:13', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(300, 1, '2020-11-09 19:36:17', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(301, 1, '2020-11-09 20:02:03', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(302, 1, '2020-11-09 20:17:07', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(303, 1, '2020-11-10 21:23:05', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(304, 1, '2020-11-11 01:08:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.310', ''),
(305, 1, '2020-11-12 22:49:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.323', ''),
(306, 1, '2020-11-12 23:37:24', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.185 Mobile Safari/537.36', ''),
(307, 1, '2020-11-13 01:49:39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.323', ''),
(308, 1, '2020-11-15 04:16:56', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.185 Mobile Safari/537.36', ''),
(309, 1, '2020-11-15 04:17:17', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.185 Mobile Safari/537.36', ''),
(310, 8, '2020-11-16 04:24:15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36 OPR/71.0.3770.323', ''),
(311, 1, '2020-11-17 06:36:04', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(312, 1, '2020-11-19 12:04:03', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(313, 1, '2020-11-19 16:09:15', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(314, 1, '2020-11-19 16:35:32', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(315, 1, '2020-11-19 16:37:30', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0', ''),
(316, 8, '2020-11-19 16:39:23', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0', ''),
(317, 1, '2020-11-20 09:58:40', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(318, 1, '2020-11-20 11:55:12', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(319, 1, '2020-11-20 13:30:11', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(320, 1, '2020-11-20 13:48:40', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(321, 1, '2020-11-21 16:23:54', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(322, 1, '2020-11-21 21:46:13', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(323, 1, '2020-11-21 22:43:29', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(324, 1, '2020-11-22 11:58:43', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(325, 1, '2020-11-22 12:43:13', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(326, 1, '2020-11-22 12:48:29', 'Mozilla/5.0 (Linux; Android 8.1.0; Twist 2 Fit) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Mobile Safari/537.36', ''),
(327, 1, '2020-11-22 13:15:09', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(328, 1, '2020-11-22 14:15:59', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(329, 1, '2020-11-22 16:02:40', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(330, 1, '2020-11-22 18:02:51', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(331, 1, '2020-11-22 18:02:52', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(332, 1, '2020-11-22 19:28:48', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(333, 1, '2020-11-22 23:04:48', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(334, 1, '2020-11-23 01:02:52', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(335, 1, '2020-11-23 11:38:25', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(336, 1, '2020-11-23 12:50:55', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(337, 1, '2020-11-23 20:08:00', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(338, 1, '2020-11-23 20:48:58', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(339, 1, '2020-11-23 22:23:19', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(340, 1, '2020-11-23 22:57:14', 'Dalvik/2.1.0 (Linux; U; Android 7.1.1; Moto E (4) Plus Build/NMA26.42-169)', ''),
(341, 1, '2020-11-24 20:50:09', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(342, 1, '2020-11-24 22:57:20', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36', ''),
(343, 1, '2021-01-14 03:33:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36', ''),
(344, 1, '2021-01-14 03:52:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36', ''),
(345, 1, '2021-01-14 03:56:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `autologin`
--

CREATE TABLE `autologin` (
  `id` int(11) NOT NULL,
  `token` varchar(244) COLLATE utf8_bin NOT NULL,
  `idcliente` int(11) NOT NULL,
  `validade` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `bancohoras`
--

CREATE TABLE `bancohoras` (
  `id` int(11) NOT NULL,
  `idadmin` int(11) NOT NULL,
  `datainicio` datetime NOT NULL,
  `datafim` datetime DEFAULT NULL,
  `faltajustificavel` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `bancohoras`
--

INSERT INTO `bancohoras` (`id`, `idadmin`, `datainicio`, `datafim`, `faltajustificavel`) VALUES
(1, 1, '2020-10-21 07:41:00', '2020-10-22 22:29:23', NULL),
(2, 1, '2020-10-22 07:41:18', '2020-10-22 19:08:31', NULL),
(5, 1, '2020-10-22 22:08:40', '2020-10-22 19:26:40', NULL),
(6, 1, '2020-10-22 22:28:34', '2020-10-22 22:34:20', NULL),
(7, 1, '2020-10-22 22:34:25', '2020-10-22 22:34:30', NULL),
(8, 1, '2020-10-30 11:06:27', '2020-10-30 11:06:42', NULL),
(9, 1, '2020-11-14 23:11:33', '2020-11-14 23:11:37', NULL),
(10, 1, '2020-11-20 13:45:12', '2020-11-20 13:45:22', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `caboid`
--

CREATE TABLE `caboid` (
  `id` int(11) NOT NULL,
  `tipo` varchar(244) COLLATE utf8_bin NOT NULL,
  `fo` int(11) NOT NULL,
  `mapa` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `cidade` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `bairro` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `coordenadas` varchar(244) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `caboid`
--

INSERT INTO `caboid` (`id`, `tipo`, `fo`, `mapa`, `cidade`, `bairro`, `coordenadas`) VALUES
(1, 'utp', 1, NULL, 'seropedica', 'boa esperanca', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `caixas`
--

CREATE TABLE `caixas` (
  `id` int(11) NOT NULL,
  `cep` varchar(244) NOT NULL,
  `rotaid` int(11) DEFAULT NULL,
  `poste` varchar(244) DEFAULT NULL,
  `Tamanho` varchar(244) NOT NULL,
  `modelo` varchar(244) NOT NULL,
  `tecnologia` varchar(244) NOT NULL,
  `coordenadas` varchar(244) DEFAULT NULL,
  `portas` varchar(244) NOT NULL,
  `porta1` varchar(244) DEFAULT NULL,
  `porta2` varchar(244) DEFAULT NULL,
  `porta3` varchar(244) DEFAULT NULL,
  `porta4` varchar(244) DEFAULT NULL,
  `porta5` varchar(244) DEFAULT NULL,
  `porta6` varchar(244) DEFAULT NULL,
  `porta7` varchar(244) DEFAULT NULL,
  `porta8` varchar(244) DEFAULT NULL,
  `porta9` varchar(244) DEFAULT NULL,
  `porta10` varchar(244) DEFAULT NULL,
  `porta11` varchar(244) DEFAULT NULL,
  `porta12` varchar(244) DEFAULT NULL,
  `porta13` varchar(244) DEFAULT NULL,
  `porta14` varchar(244) DEFAULT NULL,
  `porta15` varchar(244) DEFAULT NULL,
  `porta16` varchar(244) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `caixas`
--

INSERT INTO `caixas` (`id`, `cep`, `rotaid`, `poste`, `Tamanho`, `modelo`, `tecnologia`, `coordenadas`, `portas`, `porta1`, `porta2`, `porta3`, `porta4`, `porta5`, `porta6`, `porta7`, `porta8`, `porta9`, `porta10`, `porta11`, `porta12`, `porta13`, `porta14`, `porta15`, `porta16`) VALUES
(1, '23894886', 1, NULL, '100', '', 'utp', '-22.740075, -43.706082', '6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, '23894886', 1, NULL, '100', '', 'utp', '-22.740302, -43.705825', '6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, '23894806', 1, NULL, '100', '', 'utp', '-22.739871, -43.705303', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `cancelamentos`
--

CREATE TABLE `cancelamentos` (
  `idcliente` varchar(244) COLLATE utf8_bin NOT NULL,
  `data` varchar(244) COLLATE utf8_bin NOT NULL,
  `motivo` varchar(244) COLLATE utf8_bin NOT NULL,
  `andamento` varchar(244) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `compraspagamento`
--

CREATE TABLE `compraspagamento` (
  `id` int(11) NOT NULL,
  `faturaid` int(11) DEFAULT NULL,
  `data` date NOT NULL,
  `valor` double NOT NULL,
  `pago` int(11) DEFAULT NULL,
  `vencido` int(11) DEFAULT NULL,
  `nota_fiscal_tipo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `configs`
--

CREATE TABLE `configs` (
  `novasadesao` int(11) NOT NULL,
  `bandamaxima` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `configs`
--

INSERT INTO `configs` (`novasadesao`, `bandamaxima`) VALUES
(1, 100);

-- --------------------------------------------------------

--
-- Estrutura da tabela `cronjobs`
--

CREATE TABLE `cronjobs` (
  `id` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `tipo` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `descontos`
--

CREATE TABLE `descontos` (
  `id` int(11) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `valor` double NOT NULL,
  `data` datetime NOT NULL DEFAULT current_timestamp(),
  `permanente` int(11) DEFAULT NULL,
  `excluirplano` int(11) DEFAULT NULL,
  `geradorid` int(11) DEFAULT NULL,
  `descricao` text COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `doacoes`
--

CREATE TABLE `doacoes` (
  `id` int(11) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `data` date NOT NULL,
  `valor` varchar(244) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `doacoes`
--

INSERT INTO `doacoes` (`id`, `idcliente`, `data`, `valor`) VALUES
(10, 1, '2020-09-09', '0.50'),
(11, 1, '2020-11-04', '0.50');

-- --------------------------------------------------------

--
-- Estrutura da tabela `doacoescampanhas`
--

CREATE TABLE `doacoescampanhas` (
  `id` int(11) NOT NULL,
  `data` date DEFAULT NULL,
  `nome` longtext COLLATE utf8_bin DEFAULT NULL,
  `descricao` longtext COLLATE utf8_bin DEFAULT NULL,
  `valor` varchar(244) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `doacoescampanhas`
--

INSERT INTO `doacoescampanhas` (`id`, `data`, `nome`, `descricao`, `valor`) VALUES
(1, '2020-09-03', 'n/a', 'n/a 2', '0');

-- --------------------------------------------------------

--
-- Estrutura da tabela `emails`
--

CREATE TABLE `emails` (
  `id` int(11) NOT NULL,
  `solicitante` varchar(244) NOT NULL,
  `data` datetime NOT NULL DEFAULT current_timestamp(),
  `destino` varchar(244) NOT NULL,
  `sobre` varchar(244) NOT NULL,
  `texto` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `emails`
--

INSERT INTO `emails` (`id`, `solicitante`, `data`, `destino`, `sobre`, `texto`) VALUES
(55, 'Sistema', '2021-01-14 04:00:34', 'douglasgomestosta@gmail.com', 'Sua fatura de internet está vencida!', '<center><H2>Sua fatura de internet está vencida!</h2><br> <h3>O prazo de pagamento de sua fatura de internet está vencida, se não houver o pagamento da mesma em até 2 dias apos o vencimento, o seu serviço será automaticamente cancelado. </h3> http://painel.datawebtelecom.site/faturas');

-- --------------------------------------------------------

--
-- Estrutura da tabela `features`
--

CREATE TABLE `features` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `nome` varchar(244) COLLATE utf8_bin NOT NULL,
  `sobre` text COLLATE utf8_bin NOT NULL,
  `categoria` int(11) NOT NULL,
  `solucionado` int(11) NOT NULL,
  `data` datetime NOT NULL DEFAULT current_timestamp(),
  `resposta` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `features`
--

INSERT INTO `features` (`id`, `userid`, `nome`, `sobre`, `categoria`, `solucionado`, `data`, `resposta`) VALUES
(1, 1, 'aaa   and delete   ', 'seila     caramba        -se mano    ', 1, 0, '2020-06-27 13:41:14', ''),
(2, 1, 'testando sistema', 'teste do sistema haha', 3, 0, '2020-10-20 06:18:34', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mudancas`
--

CREATE TABLE `mudancas` (
  `id` int(11) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `cepantigo` varchar(244) NOT NULL,
  `numeroantigo` int(11) NOT NULL,
  `cepnovo` varchar(244) NOT NULL,
  `numeronovo` int(11) NOT NULL,
  `andamento` int(11) NOT NULL,
  `data` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `notas_fiscais`
--

CREATE TABLE `notas_fiscais` (
  `id` int(11) NOT NULL,
  `nome` varchar(244) COLLATE utf8_bin NOT NULL,
  `preco` varchar(244) COLLATE utf8_bin NOT NULL,
  `foto` varchar(244) COLLATE utf8_bin NOT NULL,
  `data` date NOT NULL,
  `codigo` varchar(244) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `notificacaorua`
--

CREATE TABLE `notificacaorua` (
  `id` int(11) NOT NULL,
  `email` varchar(244) COLLATE utf8_bin NOT NULL,
  `cep` varchar(244) COLLATE utf8_bin NOT NULL,
  `casa` varchar(244) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `notificacoes`
--

CREATE TABLE `notificacoes` (
  `id` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `texto` varchar(244) NOT NULL,
  `conteudo` longtext CHARACTER SET utf32 COLLATE utf32_bin NOT NULL,
  `exibido` int(11) NOT NULL,
  `data` datetime NOT NULL DEFAULT current_timestamp(),
  `url` varchar(244) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `notificacoes`
--

INSERT INTO `notificacoes` (`id`, `idusuario`, `texto`, `conteudo`, `exibido`, `data`, `url`) VALUES
(82, 1, 'Sua fatura de internet está vencida!', 'Infelizmente sua fatura de internet está vencida, caso ocorra o não pagamento pelos proximos 2 dias do vencimento o seu serviço será automaticamente cancelado.', 0, '2021-01-14 04:00:34', 'http://painel.datawebtelecom.site/faturas');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamentos`
--

CREATE TABLE `pagamentos` (
  `id` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `vencimento` date NOT NULL,
  `pago` int(11) DEFAULT NULL,
  `pagodata` date DEFAULT NULL,
  `vencido` int(11) DEFAULT NULL,
  `valor` double NOT NULL,
  `checkout` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `checkoutid` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `descricao` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `restaurarservico` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `pagamentos`
--

INSERT INTO `pagamentos` (`id`, `idusuario`, `vencimento`, `pago`, `pagodata`, `vencido`, `valor`, `checkout`, `checkoutid`, `descricao`, `restaurarservico`) VALUES
(11, 1, '2020-11-23', 1, '2020-11-22', NULL, 100, 'mercadopago', '207928615-479f3bb4-aece-4c1a-9f24-230633512048', 'Pagamento do seu serviço de internet ', NULL),
(13, 1, '2021-01-13', 1, '2021-01-14', NULL, 100, 'mercadopago', NULL, 'Pagamento da instalação!', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `planos`
--

CREATE TABLE `planos` (
  `id` int(11) NOT NULL,
  `nome` varchar(244) NOT NULL,
  `velocidade` varchar(244) NOT NULL,
  `velocidademinima` varchar(244) NOT NULL,
  `preco` varchar(244) NOT NULL,
  `sva` varchar(244) DEFAULT NULL,
  `tecnologia` varchar(244) NOT NULL,
  `visivel` int(11) NOT NULL,
  `descricao` longtext DEFAULT NULL,
  `vantagensdataweb` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `planos`
--

INSERT INTO `planos` (`id`, `nome`, `velocidade`, `velocidademinima`, `preco`, `sva`, `tecnologia`, `visivel`, `descricao`, `vantagensdataweb`) VALUES
(1, 'Internet 25 megas + Clube de vantagens', '25', '15', '80', NULL, 'utp', 1, 'Velocidade de download: 25 Megas<br>\r\nVelocidade de Upload: 25 Megas<br>\r\nParticipe do clube de vantagens Data Web<br>\r\n', 1),
(2, 'Internet 35 Megas + Clube de vantagens', '35', '21', '100', NULL, 'utp', 1, 'Velocidade de download: 35 Megas<br>\r\nVelocidade de Upload: 35 Megas<br>\r\nParticipe do clube de vantagens Data Web<br>\r\n', 1),
(3, 'Internet 50 Megas + Clube de vantagens', '50', '30', '120', NULL, 'utp', 1, 'Velocidade de download: 50 Megas<br>\r\nVelocidade de Upload: 50 Megas<br>\r\nParticipe do clube de vantagens Data Web<br>\r\n', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pppoe`
--

CREATE TABLE `pppoe` (
  `id` bigint(20) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `usuario` varchar(244) NOT NULL,
  `senha` varchar(244) NOT NULL,
  `ip` varchar(244) NOT NULL,
  `ipv6` varchar(244) DEFAULT NULL,
  `plano` int(11) NOT NULL,
  `roteador` varchar(244) NOT NULL,
  `mac` varchar(244) NOT NULL,
  `ativo` int(11) NOT NULL,
  `bloqueiovirus` int(11) NOT NULL,
  `bloqueioadulto` int(11) NOT NULL,
  `ssidwifi` varchar(244) NOT NULL,
  `senhawifi` varchar(244) NOT NULL,
  `servidor` int(11) NOT NULL,
  `onu` varchar(244) DEFAULT NULL,
  `rota` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `pppoe`
--

INSERT INTO `pppoe` (`id`, `idcliente`, `usuario`, `senha`, `ip`, `ipv6`, `plano`, `roteador`, `mac`, `ativo`, `bloqueiovirus`, `bloqueioadulto`, `ssidwifi`, `senhawifi`, `servidor`, `onu`, `rota`) VALUES
(1, 1, 'roteador', '123456', '192.168.2.1', '', 3, '1', 'n/a', 1, 1, 1, 'Data Web provedor de internet', '123456', 1, '', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `problemas`
--

CREATE TABLE `problemas` (
  `id` int(11) NOT NULL,
  `firewall` int(11) NOT NULL,
  `titulo` varchar(244) COLLATE utf8_bin NOT NULL,
  `sobre` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `problemas`
--

INSERT INTO `problemas` (`id`, `firewall`, `titulo`, `sobre`) VALUES
(1, 1, 'Sobrecarga na rede por COVID-19', 'Devido a COVID-19, estamos com uma sobrecarga em nossa rede, causando lentidão em horários de picos, estamos fazendo o possível para resolver todos os problemas.');

-- --------------------------------------------------------

--
-- Estrutura da tabela `problemasexternos`
--

CREATE TABLE `problemasexternos` (
  `id` int(11) NOT NULL,
  `rota` int(11) NOT NULL,
  `data` datetime DEFAULT NULL,
  `datasolucionado` datetime DEFAULT NULL,
  `andamento` int(11) DEFAULT NULL,
  `tecnico` int(11) DEFAULT NULL,
  `razao` text COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `problemasexternos`
--

INSERT INTO `problemasexternos` (`id`, `rota`, `data`, `datasolucionado`, `andamento`, `tecnico`, `razao`) VALUES
(11, 1, '2020-10-31 06:04:05', '2020-11-02 00:43:46', 2, 1, 'problema solucionado');

-- --------------------------------------------------------

--
-- Estrutura da tabela `rotas`
--

CREATE TABLE `rotas` (
  `id` int(11) NOT NULL,
  `caboid` int(11) NOT NULL,
  `cornocabo` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `tubo` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `cidade` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `bairro` varchar(244) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `rotas`
--

INSERT INTO `rotas` (`id`, `caboid`, `cornocabo`, `tubo`, `cidade`, `bairro`) VALUES
(1, 1, NULL, NULL, 'seropedica', 'boa esperanca');

-- --------------------------------------------------------

--
-- Estrutura da tabela `roteadores`
--

CREATE TABLE `roteadores` (
  `id` int(11) NOT NULL,
  `modelo` varchar(244) COLLATE utf8_bin NOT NULL,
  `marca` varchar(244) COLLATE utf8_bin NOT NULL,
  `portas` int(11) NOT NULL,
  `frequencia` varchar(244) COLLATE utf8_bin NOT NULL,
  `api` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `roteadores`
--

INSERT INTO `roteadores` (`id`, `modelo`, `marca`, `portas`, `frequencia`, `api`) VALUES
(1, 'dir-822', 'D-LINK', 100, '5', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `ruas`
--

CREATE TABLE `ruas` (
  `id` int(11) NOT NULL,
  `cep` varchar(244) NOT NULL,
  `rua` varchar(244) NOT NULL,
  `cidade` varchar(244) NOT NULL,
  `bairro` varchar(244) NOT NULL,
  `tecnologias` varchar(244) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `capacidade` varchar(244) NOT NULL,
  `disponivel` varchar(244) NOT NULL,
  `caboid` int(11) DEFAULT NULL,
  `coordenadas` varchar(244) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `ruas`
--

INSERT INTO `ruas` (`id`, `cep`, `rua`, `cidade`, `bairro`, `tecnologias`, `capacidade`, `disponivel`, `caboid`, `coordenadas`) VALUES
(1, '23894-786', 'Rua jose pereira dos santos', 'seropedica', 'Boa esperança', 'UTP', '100', '0', 1, '-22.736333, -43.703306');

-- --------------------------------------------------------

--
-- Estrutura da tabela `servidores`
--

CREATE TABLE `servidores` (
  `id` int(11) NOT NULL,
  `ippublico` varchar(244) COLLATE utf8_bin NOT NULL,
  `ipprivado` varchar(244) COLLATE utf8_bin NOT NULL,
  `firewall` varchar(244) COLLATE utf8_bin NOT NULL,
  `secret` varchar(244) COLLATE utf8_bin NOT NULL,
  `cidade` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `coordenadas` longtext COLLATE utf8_bin DEFAULT NULL,
  `portassh` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `servidores`
--

INSERT INTO `servidores` (`id`, `ippublico`, `ipprivado`, `firewall`, `secret`, `cidade`, `coordenadas`, `portassh`) VALUES
(1, '192.168.0.108', '192.168.0.108', 'vyos', '123456', 'seropedica', NULL, 21);

-- --------------------------------------------------------

--
-- Estrutura da tabela `suporte`
--

CREATE TABLE `suporte` (
  `id` int(11) NOT NULL,
  `data` datetime NOT NULL DEFAULT current_timestamp(),
  `nome_cliente` varchar(244) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `problema` varchar(244) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `categoria` varchar(244) NOT NULL,
  `status` varchar(244) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Log` text NOT NULL,
  `idcliente` varchar(244) NOT NULL,
  `Resposta` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `respostacliente` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `atendente` int(11) NOT NULL,
  `resolvidodata` datetime DEFAULT NULL,
  `tipoproblema` int(11) DEFAULT NULL,
  `externo` int(22) DEFAULT NULL,
  `importancia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `trocardeplanos`
--

CREATE TABLE `trocardeplanos` (
  `id` int(11) NOT NULL,
  `usuarioid` int(11) NOT NULL,
  `planoanterior` int(11) NOT NULL,
  `novoplano` int(11) NOT NULL,
  `data` varchar(244) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `trocardeplanos`
--

INSERT INTO `trocardeplanos` (`id`, `usuarioid`, `planoanterior`, `novoplano`, `data`) VALUES
(9, 1, 2, 3, '22/11/2020');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` bigint(20) NOT NULL,
  `email` varchar(244) NOT NULL,
  `nome` varchar(244) NOT NULL,
  `senha` varchar(244) NOT NULL,
  `whatsapp` varchar(244) NOT NULL,
  `cep` varchar(244) NOT NULL,
  `numero` varchar(244) NOT NULL,
  `plano` bigint(20) NOT NULL,
  `cpf` varchar(244) DEFAULT NULL,
  `cnpj` bigint(20) DEFAULT NULL,
  `ativo` int(11) NOT NULL,
  `desativado` int(11) DEFAULT NULL,
  `vencimento` varchar(244) NOT NULL,
  `observacoes` varchar(244) NOT NULL,
  `caixa` int(11) NOT NULL,
  `idoso` int(11) NOT NULL,
  `cidade` varchar(244) NOT NULL,
  `coordenadas` varchar(244) NOT NULL,
  `nome_mae` varchar(244) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `naturalidade` varchar(244) DEFAULT NULL,
  `RG` varchar(244) DEFAULT NULL,
  `jalogou` int(11) DEFAULT NULL,
  `data_adesao` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `email`, `nome`, `senha`, `whatsapp`, `cep`, `numero`, `plano`, `cpf`, `cnpj`, `ativo`, `desativado`, `vencimento`, `observacoes`, `caixa`, `idoso`, `cidade`, `coordenadas`, `nome_mae`, `data_nascimento`, `naturalidade`, `RG`, `jalogou`, `data_adesao`) VALUES
(1, 'douglasgomestosta@gmail.com', 'Douglas Gomes Tosta', 'e10adc3949ba59abbe56e057f20f883e', '2126823332', '23894786', '1550', 3, '02447113056', NULL, 0, NULL, '23', 'seila', 1, 0, 'seropedica', '-22.735818205817615, -43.7031296706225', 'maria cristina', '2002-08-29', 'Seropedica/rj', '236710795', 1, '2020-11-12');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `adesao`
--
ALTER TABLE `adesao`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `agendas`
--
ALTER TABLE `agendas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `autenticacoes`
--
ALTER TABLE `autenticacoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `autologin`
--
ALTER TABLE `autologin`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `bancohoras`
--
ALTER TABLE `bancohoras`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `caboid`
--
ALTER TABLE `caboid`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `caixas`
--
ALTER TABLE `caixas`
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices para tabela `cancelamentos`
--
ALTER TABLE `cancelamentos`
  ADD PRIMARY KEY (`idcliente`);

--
-- Índices para tabela `compraspagamento`
--
ALTER TABLE `compraspagamento`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `configs`
--
ALTER TABLE `configs`
  ADD UNIQUE KEY `novasadesao` (`novasadesao`);

--
-- Índices para tabela `cronjobs`
--
ALTER TABLE `cronjobs`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `descontos`
--
ALTER TABLE `descontos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `doacoes`
--
ALTER TABLE `doacoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `doacoescampanhas`
--
ALTER TABLE `doacoescampanhas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `emails`
--
ALTER TABLE `emails`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `mudancas`
--
ALTER TABLE `mudancas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices para tabela `notas_fiscais`
--
ALTER TABLE `notas_fiscais`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `notificacaorua`
--
ALTER TABLE `notificacaorua`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `notificacoes`
--
ALTER TABLE `notificacoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `planos`
--
ALTER TABLE `planos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices para tabela `pppoe`
--
ALTER TABLE `pppoe`
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices para tabela `problemas`
--
ALTER TABLE `problemas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices para tabela `problemasexternos`
--
ALTER TABLE `problemasexternos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `rotas`
--
ALTER TABLE `rotas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `roteadores`
--
ALTER TABLE `roteadores`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `ruas`
--
ALTER TABLE `ruas`
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices para tabela `servidores`
--
ALTER TABLE `servidores`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `suporte`
--
ALTER TABLE `suporte`
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices para tabela `trocardeplanos`
--
ALTER TABLE `trocardeplanos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `adesao`
--
ALTER TABLE `adesao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `agendas`
--
ALTER TABLE `agendas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `autenticacoes`
--
ALTER TABLE `autenticacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=346;

--
-- AUTO_INCREMENT de tabela `autologin`
--
ALTER TABLE `autologin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `bancohoras`
--
ALTER TABLE `bancohoras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `caixas`
--
ALTER TABLE `caixas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `compraspagamento`
--
ALTER TABLE `compraspagamento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cronjobs`
--
ALTER TABLE `cronjobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=394;

--
-- AUTO_INCREMENT de tabela `descontos`
--
ALTER TABLE `descontos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `doacoes`
--
ALTER TABLE `doacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `doacoescampanhas`
--
ALTER TABLE `doacoescampanhas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `emails`
--
ALTER TABLE `emails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT de tabela `features`
--
ALTER TABLE `features`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `mudancas`
--
ALTER TABLE `mudancas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `notas_fiscais`
--
ALTER TABLE `notas_fiscais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `notificacaorua`
--
ALTER TABLE `notificacaorua`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `notificacoes`
--
ALTER TABLE `notificacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT de tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `planos`
--
ALTER TABLE `planos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `pppoe`
--
ALTER TABLE `pppoe`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `problemas`
--
ALTER TABLE `problemas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `problemasexternos`
--
ALTER TABLE `problemasexternos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `rotas`
--
ALTER TABLE `rotas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `roteadores`
--
ALTER TABLE `roteadores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `ruas`
--
ALTER TABLE `ruas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `servidores`
--
ALTER TABLE `servidores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `suporte`
--
ALTER TABLE `suporte`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT de tabela `trocardeplanos`
--
ALTER TABLE `trocardeplanos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
