﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['usuariocomum'] == 1){exit();}
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `admins` WHERE `id` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $nivel = $row["nivel"];
            $cidade = $row["cidade"];
        }
    }else
    {
        exit();
    }
}
else
{
    header('Location: login.php');
}


if($_GET['iniciartrabalho'] == "1")
{
    $sql = "SELECT * FROM `bancohoras` WHERE `idadmin` = " . $id . " AND `datainicio` IS NOT NULL AND `datafim` IS NULL";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        //tem hora de trabalho em aberto
    }else{
        //não tem hora de trabalho em aberto
        $sql = "INSERT INTO `bancohoras` (`id`, `idadmin`, `datainicio`, `datafim`, `faltajustificavel`) VALUES (NULL, '" . $id . "', CURRENT_TIMESTAMP, NULL, NULL);";
    $result = $conn->query($sql);
    }
}


if($_GET['fimtrabalho'] == "1")
{
    $sql = "SELECT * FROM `bancohoras` WHERE `idadmin` = " . $id . " AND `datainicio` IS NOT NULL AND `datafim` IS NULL";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $idhora = $row["id"];
        }
        //tem hora de trabalho em aberto
        $sql = "UPDATE `bancohoras` SET `datafim` = CURRENT_TIMESTAMP WHERE `bancohoras`.`id` = " . $idhora . ";";
        $result = $conn->query($sql);
    }else{
        //não tem hora de trabalho em aberto

    }
}



?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    

                    <?php
//Ver se tem pedido de suporte aberto
$sql = "SELECT * FROM `suporte` WHERE `status` LIKE '1' AND `atendente` = " . $id . " AND `externo` IS NULL ORDER BY `data` DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $nomecliente = $row["nome_cliente"];
        $idsuporte = $row["id"];
        ?>
        <div class="alert alert-danger" style="background-color:red; color:white;">
        Atenção! você já tem um pedido de suporte aberto para <?php echo $nomecliente; ?> <a href="suporte.php?id=<?php echo $idsuporte; ?>" style="">Ver pedido de suporte</a>

</div>

        <?php

    }
}


//Ver se tem suporte externo aberto
$sql = "SELECT * FROM `problemasexternos` WHERE `andamento` = 1 AND `tecnico` = " . $id;
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $rotaid = $row["rota"];
        $idproblema = $row["id"];
        ?>
        <div class="alert alert-danger" style="background-color:red; color:white;">
        Atenção! você tem um suporte externo na rota <?php echo $rotaid; ?> <a href="problemasexternos.php?id=<?php echo $idproblema; ?>" style="">Ver suporte externo</a>

</div>

        <?php

    }
}
//banco de horas
?>
<div class="">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Banco de horas.
                        </div>        
                                      <?php
$sql = "SELECT * FROM `bancohoras` WHERE `idadmin` = " . $id . " ORDER BY `id` DESC LIMIT 1";
                                      ?>
                                    <div class="panel-body"> 
<?php
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
$iniciotrabalho = $row['datainicio'];
$fimtrabalho = $row['datafim'];
$array=explode("-",$iniciotrabalho);
$mes = $array[1];
$dia = $array[2];
$arrayy=explode(" ",$dia);
$dia = $arrayy[0];
$hora = $arrayy[1];
$arrayy=explode(":",$hora);
$hora = $arrayy[0] . ":" . $arrayy[1];
$ano = $array[0];
$iniciotrabalho =  "$dia/$mes/$ano as $hora";


$array=explode("-",$fimtrabalho);
$mes = $array[1];
$dia = $array[2];
$arrayy=explode(" ",$dia);
$dia = $arrayy[0];
$hora = $arrayy[1];
$arrayy=explode(":",$hora);
$hora = $arrayy[0] . ":" . $arrayy[1];
$ano = $array[0];
$fimtrabalho =  "$dia/$mes/$ano as $hora";
if(empty($dia)){
    ?>
<h3>Você está trabalhando desde <?php echo $iniciotrabalho; ?></h3>
<a href="?fimtrabalho=1" class="btn btn-primary btn-lg">Terminar trabalho.</a>
    <?php
}else{
    ?>
    <h3>Você não está trabalhando agora!</h3>
    <h5>Você terminou seu ultimo serviço as <?php echo $fimtrabalho; ?></h5>
                                    <a href="?iniciartrabalho=1" class="btn btn-primary btn-lg">Iniciar trabalho</a>
    <h3>
    <?php
}
        }
    }else{
?>

                                    <h3>Você não está trabalhando agora!</h3>
                                    <a href="?iniciartrabalho=1" class="btn btn-primary btn-lg">Iniciar trabalho</a>
                   <?php
    }
                   ?>
                </div>
            </div>
                          </div>

<?php
//fim banco de horas



if($nivel == "1")
{
?>

<div class="">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Usuarios conectados
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <?php
//ver usuarios conectados no pppoe
$cont = 0;
$conectados = 0;
$sql = "SELECT * FROM `usuarios` WHERE `desativado` IS NULL";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $idcliente = $row["id"];
            $cont = $cont + 1;

            $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $idcliente;
            $resultl = $conn->query($sqll);
            
            if ($resultl->num_rows > 0) {
                // output data of each row
                while($rowl = $resultl->fetch_assoc()) {
                    $usuariopppoe = $rowl["usuario"];
                    



                    $sql = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usuariopppoe . "' ORDER BY `acctstarttime` DESC LIMIT 1";
$resultt = $connradius->query($sql);
if ($resultt->num_rows > 0) {
    // output data of each row
    while($row = $resultt->fetch_assoc()) {
        $stoptime = $row["acctstoptime"];
        $starttime = $row["acctstarttime"];
        $motivodesconect = $row["acctterminatecause"];
    
if(empty($stoptime)){
    $conectados = $conectados + 1;
}
    }
}





                }
            }




        }
    }
//

?>
<h3><?php echo $conectados; ?> usuario(s) de <?php echo $cont; ?> usuarios conectados </h3>

<a href="clientes.php" class="btn btn-primary">Ver clientes</a>
                   
                </div>
            </div>
                          </div>

<?php
}
?>




                          <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                           Pedidos de suporte
                        </div>        
                                      
                                    <div class="panel-body"> 



                                    <?php
 //Ver pedidos de suporte

$sql = "SELECT * FROM `suporte` WHERE `status` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);

$sql = "SELECT * FROM `suporte` WHERE `status` LIKE '1' AND `atendente` = " . $id . " ORDER BY `id` ASC";
$result = $conn->query($sql);
$contt = mysqli_num_rows($result);



?>

<h3><?php echo $cont; ?> Pedidos de suporte pendentes na sua região</h3>

<h3>Você tem <?php echo $contt; ?> pedido(s) em aberto</h3>
<?php
//problemas externos
$problemasexternos = 0;
$sql = "SELECT * FROM `problemasexternos` WHERE `datasolucionado` IS NULL";
$result = $conn->query($sql);
                        if ($result->num_rows > 0) {while($row = $result->fetch_assoc()) {
$idrota = $row['rota'];
$sqll = "SELECT * FROM `rotas` WHERE `id` = ". $idrota;
$resultt = $conn->query($sqll);
if ($resultt->num_rows > 0) {while($roww = $resultt->fetch_assoc()) {
    $cidadeproblema = $roww['cidade'];
    $problemaexterno = strpos(" " . $cidade,$cidadeproblema);
    if($problemaexterno > 0)
    {
        $problemasexternos = $problemasexternos + 1;
    }
                            }}

                        }}

                        //$problemaexterno = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
if($problemasexternos > 0)
{
    ?>
<div class="alert alert-danger" style="background-color:red; color:white;">
   Existem <?php echo $problemasexternos; ?> Problemas externos na sua região
</div>
    <?php
}else
{
    ?>
<div class="alert alert-danger" style="background-color:green; color:white;">
   Não existem suportes externos na sua região!
</div>
    <?php
}
?>





                                       <div style="margin-top: 10px;">
											
                                       <a href="suporte.php" class="btn btn-primary">Pedidos de suporte</a>
					
                                       <a href="problemasexternos.php" class="btn btn-primary">Ver todos problemas externos</a>

                                        </div>
                                    </div>
                    </div>
                    </div>
































                    <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                           Pedidos de instalações na sua região
                        </div>        
                                      
                                    <div class="panel-body"> 

<?php
$sql = "SELECT * FROM `adesao` WHERE `andamento` = 0";
$result = $conn->query($sql);
$instalacoes = 0;
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
$cepinstalacao = $row['cep'];
$sqll = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cepinstalacao . "'";
$resultt = $conn->query($sqll);
while($roww = $resultt->fetch_assoc()) {
$cidadeinstalacao = $roww['cidade'];
}
$mesmacidade = strpos(" " . $cidade,$cidadeinstalacao);
if($mesmacidade > 0)
{
    $instalacoes = $instalacoes + 1;
}



    }
}

if($instalacoes > 0)
{
    ?>
    <div class="alert alert-danger" style="background-color:red; color:white;">
   Existem <?php echo $instalacoes; ?> Pedidos de instalação sem agendamentos em sua região! 
</div>

    <?php
}else{
?>
    <div class="alert alert-danger" style="background-color:green; color:white;">
   Não existem pedidos de instalação na sua região!
</div>
<?php
}
?>
<a href="instalacoes.php" class="btn btn-primary">Pedidos de instalação</a>

									

                                        </div>
                                    </div>
                    </div>
                    </div>


</div>


















                    <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                           Sua agenda de serviços.
                        </div>        
                                      
                                    <div class="panel-body"> 



                                    <?php
 //Ver pedidos de suporte
 $data = date("Y-m-d");
$sql = "SELECT * FROM `agendas` WHERE `idadmin` = " . $id . " AND `resolvido` IS NULL";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);

$sql = "SELECT * FROM `agendas` WHERE `idadmin` = " . $id .  " AND `data` LIKE '%" . $data . "%' AND `resolvido` IS NULL";
$result = $conn->query($sql);
$contt = mysqli_num_rows($result);

$sql = "SELECT * FROM `agendas` WHERE `idadmin` = " . $id . " AND `data` LIKE '%" . $data . "%' AND `resolvido` IS NULL AND `idtipo` IS NOT NULL ORDER BY `data` ASC limit 1";
$result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            // output data of each row
                            while($row = $result->fetch_assoc()) {
                                $data = $row["data"];
                                $array=explode("-",$data);
                                $mes = $array[1];
                                $dia = $array[2];
                                $arrayy=explode(" ",$dia);
                                $dia = $arrayy[0];
                                $hora = $arrayy[1];
                                $arrayy=explode(":",$hora);
                                $hora = $arrayy[0] . ":" . $arrayy[1];
                                $ano = $array[0];
                                $data =  "$dia/$mes/$ano as $hora";
                                ?>
                                <h3>O seu proximo serviço de hoje é as <?php echo $hora; ?> </a href="suporte.php?id=<?php echo $roteador;?>"> Ver serviço </a> </h3>
                                <?php
                            }
                        }else{
?>
<h3>Você AINDA não tem serviços marcados para o dia de hoje! </h3>
<h5>Lembre-se que horários marcados que ainda não foram agendados por nenhum cliente podem ser agendados com no mínimo 2 horas de antecedência</h5>
<?php
                        }
?>
<h3>Você tem outros <?php echo $contt; ?> Serviço(s) agendados para hoje.</h3>
<h3>Você tem no total <?php echo $cont; ?> Serviço(s) agendados para os proximos dias.</h3>

<?php
$sql = "SELECT * FROM `agendas` WHERE `idadmin` = " . $id . " AND `resolvido` IS NULL AND `marcado` IS NULL";
$result = $conn->query($sql);
$naomarcados = mysqli_num_rows($result);
?>
<h3>Você tem <?php echo $naomarcados; ?> Serviços agendados e ainda não marcados por nenhum cliente.</h3>



                                       <div style="margin-top: 10px;">
											
                                       <a href="agendamentos.php" class="btn btn-primary">ver mais</a>
					
									

                                        </div>
                                    </div>
                    </div>
                    </div>






<h1>Estatisticas do serviço </h1>
<?php
//ver usuarios conectados no pppoe
$cont = 0;
$conectados = 0;
$sql = "SELECT * FROM `usuarios` WHERE `ativo` = 1";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $idcliente = $row["id"];
            $cont = $cont + 1;

            $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $idcliente;
            $resultl = $conn->query($sqll);
            
            if ($resultl->num_rows > 0) {
                // output data of each row
                while($rowl = $resultl->fetch_assoc()) {
                    $usuariopppoe = $rowl["usuario"];
                    



                    $sql = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usuariopppoe . "' ORDER BY `acctstarttime` DESC LIMIT 1";
$resultt = $connradius->query($sql);
if ($resultt->num_rows > 0) {
    // output data of each row
    while($row = $resultt->fetch_assoc()) {
        $stoptime = $row["acctstoptime"];
        $starttime = $row["acctstarttime"];
        $motivodesconect = $row["acctterminatecause"];
    
if(empty($stoptime)){
    $conectados = $conectados + 1;
}
    }
}





                }
            }




        }
    }

//
?>






















<h3> Usuarios conectados: <?php echo $conectados;  ?>/<?php echo $cont; ?> <a href="clientes.php">Ver Clientes</a>  </h3>

<?php
 //Ver pedidos de suporte

$sql = "SELECT * FROM `suporte` WHERE `status` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>

<h3> Pedidos de suporte pendentes: <?php echo $cont; ?>  <a href="suporte.php">Ver Todos</a>  <a href="addsuporte.php">Criar novo</a> </h3>


<?php
 //ver instalações pendentes

$sql = "SELECT * FROM `adesao` WHERE `andamento` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>

<h3> Instalações pendentes: <?php echo $cont; ?>  <a href="adesao.php">Ver Todos</a>  <a href="addadesao.php">Criar novo</a> </h3>


<?php
//Caixas instaladas no poste
$sql = "SELECT * FROM `caixas`";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>
<h3> Caixas instaladas: <?php echo $cont; ?>   <a href="caixa.php">Ver Todos</a> <a href="addcaixa.php">Adicionar novo</a></h3>

<?php
//Ruas atendidas
$sql = "SELECT * FROM `ruas`";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>
<h3> Ruas atendidas: <?php echo $cont; ?>   <a href="ruas.php">Ver Todas</a> <a href="addruas.php">Adicionar nova</a></h3>


<?php
//Ruas atendidas
$sql = "SELECT * FROM `mudancas` WHERE `andamento` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>
<h3> Mudanças de endereço: <?php echo $cont; ?>   <a href="ruas.php">Ver Todas</a> <a href="addruas.php">Adicionar nova</a></h3>


<?php
 //ver instalações pendentes

$sql = "SELECT * FROM `cancelamentos` WHERE `andamento` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>

<h3> Cancelamentos de serviço pendentes: <?php echo $cont; ?>  <a href="adesao.php">Ver Todos</a>  <a href="addadesao.php">Criar novo</a> </h3>



<p>Painel de administração exclusivo Data Web, Versão BETA</p>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
