<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['usuariocomum'] == 1){exit();}
if($_SESSION['login'] == 1)
{
}
else
{
    header('Location: login.php');
}





?>

<html>
  <head>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.0.3/dist/leaflet.css" integrity="sha512-07I2e+7D8p6he1SIM+1twR5TIrhUQn9+I6yjqD53JQjFiMf8EtC93ty0/5vJTZGF8aAocvHYNEDJajGdNx1IsQ==" crossorigin=""/>
    
    <style>
      #location-map{
        background: #fff;
        border: none;
        height: 540px;
        width: 100%;

        box-sizing: border-box;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
      }
    </style>
  </head>
  <body>
    <div id="location-map"></div>
    
    <script src="https://unpkg.com/leaflet@1.0.3/dist/leaflet.js" integrity="sha512-A7vV8IFfih/D732iSSKi20u/ooOfj/AGehOKq0f4vLT1Zr2Y+RX7C+w8A1gaSasGtRUZpF/NZgzSAu4/Gc41Lg==" crossorigin=""></script>

    <script type="text/javascript">
      var map = L.map('location-map').setView([	-22.7397, -43.6956], 12);
      mapLink = '<a href="https://openstreetmap.org">OpenStreetMap</a>';
      L.tileLayer(
        'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: 'Map data &copy; ' + mapLink,
          maxZoom: 20,
        }).addTo(map);
        




        var offline = L.icon({
    iconUrl: 'imagens/offline.png',
    iconSize:[20, 20],
});

var online = L.icon({
    iconUrl: 'imagens/online.png',
    iconSize:[20, 20],
});




        <?php
        //var marker = L.marker([-22.73612,-43.70368], {icon: offline}).addTo(map).bindPopup('usuario desconectado: ');
        //var marker = L.marker([-22.73650,-43.70299], {icon: online}).addTo(map).bindPopup('usuario conectado: ');
        $sql = "SELECT * FROM `usuarios`";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $coordenadas = $row["coordenadas"];
                $nome = $row["nome"];
                $id = $row["id"];
                
                $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id . " AND `ativo` = 1";
                $resultl = $conn->query($sqll);
                
                if ($resultl->num_rows > 0) {
                    // output data of each row
                    while($rowl = $resultl->fetch_assoc()) {
                        $usernamepppoe = $rowl["usuario"];
                    }}
            
                    $sqll = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usernamepppoe . "' ORDER BY `radacctid` DESC limit 1";
              
                    $resultl = $connradius->query($sqll);
                if ($resultl->num_rows > 0) {
                    // output data of each row
                    while($rowl = $resultl->fetch_assoc()) {
                        $motivodesconect = $rowl["acctterminatecause"];
                        $stoptime = $rowl["acctstoptime"];
                        $starttime = $rowl["acctstarttime"];
                        
                        if(empty($motivodesconect)){
                            $desconectado = "0";
                        }else
                        {
                            $desconectado = "1";
                        }

                        if($desconectado == "1")
                        {
                            ?>
                            console.log("usuario: <?php echo $usernamepppoe; ?> desconectado localização: <?php echo $coordenadas; ?> status: <?php echo $motivodesconect; ?> stop time: <?php echo $stoptime; ?>");
                            var marker = L.marker([<?php echo $coordenadas;?>], {icon: offline}).addTo(map).bindPopup('usuario desconectado: <?php echo $nome; ?> <br>motivo: <?php echo $motivodesconect; ?>');
                            <?php
                        }

                        if($desconectado == "0")
                        {
                            ?>
                            console.log("usuario: <?php echo $usernamepppoe; ?> conectado localização: <?php echo $coordenadas; ?>");
                            var marker = L.marker([<?php echo $coordenadas;?>], {icon: online}).addTo(map).bindPopup('usuario conectado: <?php echo $nome; ?>');
                            <?php
                        }

                    }}else{
                        ?>
                            console.log("usuario: <?php echo $usernamepppoe; ?> nunca houve conexão localização: <?php echo $coordenadas; ?>");
                            var marker = L.marker([<?php echo $coordenadas;?>], {icon: offline}).addTo(map).bindPopup('usuario nunca houve conexão: <?php echo $nome; ?>');
                            <?php
                    }

            
            
            }
        }
        ?>

       
    </script>
  </body>
</html>