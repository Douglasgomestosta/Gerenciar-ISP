﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
if($_SESSION['usuariocomum'] == 1){exit();}
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `admins` WHERE `id` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $nivel = $row["nivel"];
            $cidade = $row["cidade"];
        }
    }else
    {
        exit();
    }
}
else
{
    header('Location: login.php');
}


if (empty($_GET['id'])) {
exit();
}


?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
<?php

                    $sql = "SELECT * FROM `servidores` WHERE id = " . $_GET['id'] . "";
                 
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $ippublico = $row["ippublico"];
            $secret = $row["secret"];
            $tudook = "1";
            exec("ping -c 1 $ippublico", $output, $status);
  
            if ($status==0) {
                $ping = $output[1];
                $array = explode('time=', $ping);
            $ping = $array[1];
            $array = explode(' ', $ping);
            $ping = $array[0];
            } else {
                $tudook = "0";
            }
            $connection = ssh2_connect($ippublico, 22);
            ssh2_auth_password($connection, 'vyos', $secret);
            
            $stream = ssh2_exec($connection, 'uptime');
            stream_set_blocking($stream, true);
            $uptime = stream_get_contents($stream);


            //consumo de ram
            $stream = ssh2_shell($connection);
            fwrite($stream, "free -m". PHP_EOL);
            sleep(1);
        $data .= stream_get_contents($stream);
        $array = explode('Mem:', $data);
        $data = $array[1];
        $data = preg_replace("/[^0-9]/", " ", $data);
        //echo $data;

        $consumoram = explode(" ", $data);
        foreach ($consumoram as $value) {
            if (is_numeric($value)){
               
                if (empty($ramtotal)) {
                    $ramtotal = $value;
                }elseif(empty($ramusado)){
                    $ramusado = $value;
                }elseif(empty($ramlivre)){
                    $ramlivre = $value;
                }elseif(empty($ramshared)){
                    $ramshared = $value;
                }elseif(empty($ramcache)){
                    $ramcache = $value;
                }elseif(empty($ramdisponivel)){
                    $ramdisponivel = $value;
                }
            }
            
        }
//fim ver consumo de ram

        //$consumoram = explode(" ", $data);
        //$ramtotal = $consumoram[12];
        //$ramusado = $consumoram[21];
        //$ramlivre = $consumoram[31];
        //$ramdisponivel = $consumoram[51];
        //print_r (explode(" ",$data));
    //echo "<br>total: $ramtotal";


    //ver consumo de banda

    //$data = " ";
    //$stream = ssh2_shell($connection);
    //        fwrite($stream, "monitor bandwidth interface eth0". PHP_EOL);
    //        sleep(1);
    //        $data .= stream_get_contents($stream);
    //        echo $data;

            //fim ver consumo de banda





            //ver consumo de cpu
            $data = " ";
            $stream = ssh2_shell($connection);
                    fwrite($stream, "top -n 1". PHP_EOL);
                    sleep(2);
                    $data .= stream_get_contents($stream);
                    $array = explode('ni, ', $data);
        $data = $array[1];

        $array = explode(' id,', $data);
        $data = $array[0];
                    $livrecpu = $data;
                    $consumocpu = 100 - $data;
            //fim ver consumo de cpu
    fclose($stream);
     ?>

<div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Firewall <?php echo $row['id']; ?>
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <div class="">

<h4>Latência:  <?php echo $ping; ?>MS</h4>
<h4>Uptime: <?php echo $uptime; ?> </h4>

<h4>Consumo de recursos: <br> <?php //print_r(stream_get_contents($stream)); ?>
														

<div class="col-md-7">
    Memoria ram:
    <br>Total: <?php echo $ramtotal; ?>MB
    <br>Em uso: <?php echo $ramusado; ?>MB
    <br>Livre: <?php echo $ramlivre; ?>MB
    <br>Disponivel sem cache: <?php echo $ramdisponivel; ?>MB
</div>

<div class="col-md-5">
    CPU<br>
    <?php echo $consumocpu; ?>% de consumo.<br>
    <?php echo $livrecpu; ?>% de cpu sem uso.
</div>
									

                                        </div>
                                    </div>
                    </div>
                    </div>


     <?php
        }
    }
            ?>

<p>Painel de administração exclusivo Data Web, Versão BETA</p>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
    
   
</body>
</html>
