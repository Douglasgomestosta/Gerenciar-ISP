<?php
$connection = ssh2_connect('192.168.0.108', 22);
ssh2_auth_password($connection, 'vyos', '123');

$stream = ssh2_exec($connection, 'htop');

$errorStream = ssh2_fetch_stream($stream, SSH2_STREAM_STDERR);

// Enable blocking for both streams
stream_set_blocking($errorStream, true);
stream_set_blocking($stream, true);
echo "Output: " . stream_get_contents($stream);
