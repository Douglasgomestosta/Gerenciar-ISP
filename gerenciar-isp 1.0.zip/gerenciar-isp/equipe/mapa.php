﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['usuariocomum'] == 1){exit();}
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `admins` WHERE `id` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $nivel = $row["nivel"];
        }
    }else
    {
        exit();
    }
}
else
{
    header('Location: login.php');
}



?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <link rel="stylesheet" href="https://unpkg.com/leaflet@1.0.3/dist/leaflet.css" integrity="sha512-07I2e+7D8p6he1SIM+1twR5TIrhUQn9+I6yjqD53JQjFiMf8EtC93ty0/5vJTZGF8aAocvHYNEDJajGdNx1IsQ==" crossorigin=""/>

   <style>
      #location-map{
        background: #fff;
        border: none;
        height: 540px;
        width: 100%;

        box-sizing: border-box;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
      }
    </style>


   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>

</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    <form method="get">
<h4>Cidade</h4>
                                    <select id="ordenacao" name="cidade">
                                    <option value="seropedica">seropedica</option>
                                    <option value="paracambi">paracambi</option>
                                    <option value="itaguai">itaguai</option>
                                    </select>
                                        
                                    
                                        <tr>

                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </form>

 <div id="location-map"></div>
    
    <script src="https://unpkg.com/leaflet@1.0.3/dist/leaflet.js" integrity="sha512-A7vV8IFfih/D732iSSKi20u/ooOfj/AGehOKq0f4vLT1Zr2Y+RX7C+w8A1gaSasGtRUZpF/NZgzSAu4/Gc41Lg==" crossorigin=""></script>

    <script type="text/javascript">
      var map = L.map('location-map').setView([	-22.7397, -43.6956], 12);
      mapLink = '<a href="https://openstreetmap.org">OpenStreetMap</a>';
      L.tileLayer(
        'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: 'Map data &copy; ' + mapLink,
          maxZoom: 30,
        }).addTo(map);
        



        var offline = L.icon({
    iconUrl: 'imagens/offline.png',
    iconSize:[19, 19],
});

var online = L.icon({
    iconUrl: 'imagens/online.png',
    iconSize:[19, 19],
});


var nuncaonline = L.icon({
    iconUrl: 'imagens/nuncaonline.png',
    iconSize:[19, 19],
});


        <?php
        //var marker = L.marker([-22.73612,-43.70368], {icon: offline}).addTo(map).bindPopup('usuario desconectado: ');
        //var marker = L.marker([-22.73650,-43.70299], {icon: online}).addTo(map).bindPopup('usuario conectado: ');
        $sql = "SELECT * FROM `usuarios` WHERE `desativado` IS NULL";
        if($_GET['cidade'] == "seropedica")
        {
            $sql = "SELECT * FROM `usuarios` WHERE `cidade` LIKE 'seropedica' AND `desativado` IS NULL";
        }
        if($_GET['cidade'] == "itaguai")
        {
            $sql = "SELECT * FROM `usuarios` WHERE `cidade` LIKE 'itaguai' AND `desativado` IS NULL";
        }
        if($_GET['cidade'] == "paracambi")
        {
            $sql = "SELECT * FROM `usuarios` WHERE `cidade` LIKE 'paracambi' AND `desativado` IS NULL";
        }
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $coordenadas = $row["coordenadas"];
                $nome = $row["nome"];
                $id = $row["id"];
                
                $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id . " AND `ativo` = 1";
                $resultl = $conn->query($sqll);
                
                if ($resultl->num_rows > 0) {
                    // output data of each row
                    while($rowl = $resultl->fetch_assoc()) {
                        $usernamepppoe = $rowl["usuario"];
                    }}
            
                    $sqll = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usernamepppoe . "' ORDER BY `radacctid` DESC limit 1";
              
                    $resultl = $connradius->query($sqll);
                if ($resultl->num_rows > 0) {
                    // output data of each row
                    while($rowl = $resultl->fetch_assoc()) {
                        $motivodesconect = $rowl["acctterminatecause"];
                        $stoptime = $rowl["acctstoptime"];
                        $starttime = $rowl["acctstarttime"];
                        
                        if(empty($motivodesconect)){
                            $desconectado = "0";
                        }else
                        {
                            $desconectado = "1";
                        }

                        if($desconectado == "1")
                        {
                            ?>
                            console.log("usuario: <?php echo $usernamepppoe; ?> desconectado localização: <?php echo $coordenadas; ?> status: <?php echo $motivodesconect; ?> stop time: <?php echo $stoptime; ?>");
                            var marker = L.marker([<?php echo $coordenadas;?>], {icon: offline}).addTo(map).bindPopup('usuario desconectado: <?php echo $nome; ?> <br>motivo: <?php echo $motivodesconect; ?>');
                            <?php
                        }

                        if($desconectado == "0")
                        {
                            ?>
                            console.log("usuario: <?php echo $usernamepppoe; ?> conectado localização: <?php echo $coordenadas; ?>");
                            var marker = L.marker([<?php echo $coordenadas;?>], {icon: online}).addTo(map).bindPopup('usuario conectado: <?php echo $nome; ?>');
                            <?php
                        }

                    }}else{
                        ?>
                            console.log("usuario: <?php echo $usernamepppoe; ?> nunca houve conexão localização: <?php echo $coordenadas; ?>");
                            var marker = L.marker([<?php echo $coordenadas;?>], {icon: nuncaonline}).addTo(map).bindPopup('usuario nunca houve conexão: <?php echo $nome; ?>');
                            <?php
                    }

            
            
            }
        }
        ?>

       
    </script>



                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
