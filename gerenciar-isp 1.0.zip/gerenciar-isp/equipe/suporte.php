﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['usuariocomum'] == 1){exit();}
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `admins` WHERE `id` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $nivel = $row["nivel"];
            $cidade = $row["cidade"];
        }
    }else
    {
        exit();
    }
}
else
{
    header('Location: login.php');
}




?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />



<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


</style>

</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
<?php
if (!is_numeric($_GET['id'])) {
    if($_GET['parte'] == "2")
    {
        if($_GET['problema'] == "1") { $sql = "SELECT * FROM `suporte` WHERE `status` LIKE '0' AND `externo` IS NULL ORDER BY `data` ASC"; }
    if($_GET['problema'] == "2") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '1' AND `status` LIKE '0' AND `externo` IS NULL ORDER BY `data` ASC"; }
    if($_GET['problema'] == "3") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '2' AND `status` LIKE '0' AND `externo` IS NULL ORDER BY `data` ASC"; }
    if($_GET['problema'] == "4") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '3' AND `status` LIKE '0' AND `externo` IS NULL ORDER BY `data` ASC"; }
    if($_GET['problema'] == "5") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '4' AND `status` LIKE '0' AND `externo` IS NULL ORDER BY `data` ASC"; }
    if($_GET['problema'] == "6") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '5' AND `status` LIKE '0' AND `externo` IS NULL ORDER BY `data` ASC"; }
    if($_GET['problema'] == "7") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '6' AND `status` LIKE '0' AND `externo` IS NULL ORDER BY `data` ASC"; }

    ?>
<div class="card-header-right">


</div>
</div>
<div class="card-block p-b-0">
<div class="table-responsive">
<table class="table table-hover m-b-0">
<thead>
<tr>
<th>Categoria</th>
<th>Problema</th>
<th>Importancia</th>
<th>Status</th>
</tr>
</thead>
<tbody>
<?php

    $result = $conn->query($sql);
    $temsuportes = "0";
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $temsuportes = "1";
            $problema = $row["problema"];
            $categoria = $row["categoria"];
            $idsuporte = $row["id"];
            $status = $row["status"];
            if($categoria == 1){$categoria = "Estou sem internet";}
            if($categoria == 2){$categoria = "Minha conexão a internet está lenta";}
            if($categoria == 3){$categoria = "Estou com problemas de perda de pacotes ou alta latencia";}
            if($categoria == 4){$categoria = "Estou com pronlemas relacionado ao pagamento";}
            if($categoria == 5){$categoria = "Tenho perguntas";}
            if($categoria == 6){$categoria = "Outros assuntos";}


            //pegar cep do cliente
            $sqll = "SELECT * FROM `usuarios` WHERE `id` = " . $row["idcliente"];
    $resultt = $conn->query($sqll);
    if ($resultt->num_rows > 0) {
        while($roww = $resultt->fetch_assoc()) { $cep = $roww["cep"]; }}
//pegar nome da cidade no cep
        $sqll = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "'";
    $resultt = $conn->query($sqll);
    if ($resultt->num_rows > 0) {
        while($roww = $resultt->fetch_assoc()) { $cidadeproblema = $roww["cidade"]; }}

//ver se já existe um agendamento para o suporte
        $sqll = "SELECT * FROM `agendas` WHERE `tipo` = 1 AND `idtipo` = " . $idsuporte;
        $resultt = $conn->query($sqll);
        $temagendamento = "0";
        if ($resultt->num_rows > 0) { $temagendamento = "1";}

        //ver se a cidade do cliente é a mesma selecionada pelo técnico
        $problemaexterno = strpos(" " . $cidade,$cidadeproblema);

        if($problemaexterno > 0)
{

    //ver se suporte já tem agendamento
if($temagendamento == "0")
{
            ?>
<tr>
<td> <a href="?id=<?php echo $idsuporte; ?>"><?php echo $categoria; ?></a></td> 
<td><?php echo $problema; ?></td>
<td>0</td>
<?php
if($status == 0)
{
    ?>
<td><label class="label label-danger">Aguardando...</label></td>
<?php
}
if($status == 1)
{
    ?>
<td><label class="label label-danger">Em analise...</label></td>
<?php
}
if($status == 2)
{
    ?>
<td><label class="label label-success">Resolvido</label></td>
<?php
}
?>
</tr>
            <?php
}
}
}
        
    }else{
        ?>
        <h3>N/A</h3>
        <?php
    }
    
?>



    
        















</tbody>
</table>
</div>
</div>
</div>
</div>
<?php


    }else
    {
?>
<form method="GET">
    <input type="hidden" name="parte" value="2">
                                    <table class="login-box">
                                        <h3>Tipo de problema </h3>
                                    <select id="ordenacao" name="problema">
                                    <option value="1">Todos</option>
                                    <option value="2">Estou sem internet</option>
                                    <option value="3">Minha conexão a internet está lenta</option>
                                    <option value="4">Estou com problemas de perda de pacotes ou alta latência </option>
                                    <option value="5">Estou com problemas relacionado ao pagamento da minha conta</option>
                                    <option value="6">Tenho perguntas, perguntas que precisam ser respondidas!</option>
                                    <option value="7">Outros assuntos</option>
                                    </select>

                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Buscar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>







<!---- pedidos de suporte em andamento ---->

                                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Pedidos de suporte em andamento
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <div id="dataTables-example_wrapper" class="dataTables_wrapper form-inline" role="grid"><div class="row"><div class="col-sm-6"></div><div class="col-sm-6"><div id="dataTables-example_filter" class="dataTables_filter"></div></div></div><table class="table table-striped table-bordered table-hover dataTable no-footer" id="dataTables-example" aria-describedby="dataTables-example_info">
                                    <thead>
                                        <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column ascending" style="width: 165px;">Problema</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" style="width: 256px;">Data</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending" style="width: 232px;">Categoria</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending" style="width: 139px;">Cliente</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending" style="width: 98px;">Ver Mais</th></tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php
                                        $sql = "SELECT * FROM `suporte` WHERE `status` LIKE '1' AND `atendente` = " . $id . " ORDER BY `id` ASC";

                                        $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
    if($row["categoria"] == "1")
    {
        $categoria = "Sem conexão a internet";
    }
    if($row["categoria"] == "2")
    {
        $categoria = "Conexão a internet lenta";
    }
    if($row["categoria"] == "3")
    {
        $categoria = "Perda de pacotes/alta latencia";
    }
    if($row["categoria"] == "4")
    {
        $categoria = "Problemas de pagamento";
    }
    if($row["categoria"] == "5")
    {
        $categoria = "Estou com duvidas";
    }
    if($row["categoria"] == "6")
    {
        $categoria = "Outros problemas";
    }

            ?>
             <tr class="gradeA odd">
                                            <td class="sorting_1"><?php echo $row["problema"]; ?></td>
                                            <td class=" "><?php echo $row["data"]; ?></td>
                                            <td class=" "><?php echo $categoria; ?></td>
                                            <td class="center "><?php echo $row['']; ?></td>
                                            <td class="center "><a href="?id=<?php echo $row["id"];?>">Ver Mais</a></td>
                                        </tr>
            <?php
        
        }
    }
}
                                        ?>
                                        
                                   

                                       


                                        </tbody>
                                </table></div>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>



<!---- pedidos de suporte em andamento ---->

<div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Agendamentos marcados para você
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <div id="dataTables-example_wrapper" class="dataTables_wrapper form-inline" role="grid"><div class="row"><div class="col-sm-6"></div><div class="col-sm-6"><div id="dataTables-example_filter" class="dataTables_filter"></div></div></div><table class="table table-striped table-bordered table-hover dataTable no-footer" id="dataTables-example" aria-describedby="dataTables-example_info">
                                    <thead>
                                        <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column ascending" style="width: 165px;">Problema</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" style="width: 256px;">Data</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending" style="width: 232px;">Categoria</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending" style="width: 139px;">Marcado</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending" style="width: 98px;">Ver Mais</th></tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php
                                        $hora = date('H');
                                        $data = date("Y-m-d");
                                        $sql = "SELECT * FROM `agendas` WHERE `idadmin` = " . $id . " AND `data` > '" . $data . " " . $hora . ":00:00'";

                                        $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {

if($row["marcado"] == "1")
{
    $marcado = "Sim";
    if($row["tipo"] == "1")
    {
$tipo = "Suporte técnico";
    }
}else{
    $marcado = "Não";
    $tipo = "N/A";
}
            ?>
             <tr class="gradeA odd">
                                            <td class="sorting_1"><?php echo $row["problema"]; ?></td>
                                            <td class=" "><?php echo $row["data"]; ?></td>
                                            <td class=" "><?php echo $tipo; ?></td>
                                            <td class="center "><?php echo $marcado; ?></td>
                                            <td class="center "><a href="?id=<?php echo $row["idtipo"];?>">Ver Mais</a></td>
                                        </tr>
            <?php
        
        }
    }

                                        ?>
                                        
                                   

                                       


                                        </tbody>
                                </table></div>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>






<?php


}else{
$idsuporte = $_GET['id'];


//mudar status do suporte
if($_GET['status'] == "1"){
    $sql = "UPDATE `suporte` SET `status` = '1', `atendente` = '" . $id . "' WHERE `suporte`.`id` = " . $_GET['id'] . ";";
  
    
    if ($conn->query($sql) === TRUE) {}}


//dar como encerrado
    if($_POST['status'] == "2"){
        $sql = "UPDATE `suporte` SET `status` = '2', `Resposta` = '" . $_POST['comentario'] . "' WHERE `suporte`.`id` = '" . $_GET['id'] . "';";
        
        if ($conn->query($sql) === TRUE) {}
  
        $sql = "INSERT INTO `notificacoes` (`id`, `idusuario`, `texto`, `conteudo`, `exibido`, `data`) VALUES (NULL, '" . $_POST['idcliente'] . "', 'Seu pedido de suporte foi respondido!', 'O tecnico " . $nome . " respondeu pelo seu pedido de suporte <br> " . $_POST['comentario'] . "', '0', CURRENT_TIMESTAMP);";
        if ($conn->query($sql) === TRUE) {}
      

        $sql = "UPDATE `agendas` SET `resolvido` = '1', `resolvidodata` = CURRENT_TIMESTAMP WHERE `agendas`.`idtipo` = " . $_GET['id'] . ";";

        if ($conn->query($sql) === TRUE) {}


      }


    //fim


$sql = "SELECT * FROM `suporte` WHERE `id` = " . $idsuporte;
$result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
     $data = $row["data"];
     $categoria = $row["categoria"];
     $nome_cliente = $row["nome_cliente"];
     $idcliente = $row["idcliente"];
     $status = $row["status"];
     $respostacliente = $row["respostacliente"];
     $log = $row["Log"];
     $resposta = $row["Resposta"];
    }
}


    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $idcliente;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $email = $row["email"];
        $velocidade = $row["velocidade"];
        $cep = $row["cep"];
        $numero = $row["numero"];
        $coordenadas = $row["coordenadas"];
        $idusuario = $row["id"];
        $telefone = $row["whatsapp"];
    }
}

$sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $idcliente;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $usuariopppoe = $row["usuario"];
    }
}



    if($categoria == 1){$categoria = "Estou sem internet";}
            if($categoria == 2){$categoria = "Minha conexão a internet está lenta";}
            if($categoria == 3){$categoria = "Estou com problemas de perda de pacotes ou alta latencia";}
            if($categoria == 4){$categoria = "Estou com pronlemas relacionado ao pagamento da minha conta";}
            if($categoria == 5){$categoria = "Tenho perguntas";}
            if($categoria == 6){$categoria = "Outros assuntos";}
            if($status == "0") { $status = "Aguardando...";}
if($status == "1") { $status = "Em andamento";}
if($status == "2") { $status = "Encerrado";}
            ?>
<div class="col-md-7">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Pedido de suporte
                        </div>        
                                      
                                    <div class="panel-body"> 

                    <h4>Nome do cliente: <?php echo $nome_cliente; ?></h4>
                    <h4>Categoria: <?php echo $categoria; ?></h4>
                    <h4>Status do atendimento: <?php echo $status; ?></h4>
                    <h4>Resposta do cliente: "<?php echo $respostacliente; ?>"</h4>
                    <br><br>

                    <h4>Log do suporte:<br> <?php echo $log; ?></h4>

                    <br>
<?php
                    if($status == "Aguardando...")
{
?>
<a href="suporte.php?id=<?php echo $idsuporte; ?>&status=1&idcliente=<?php echo $idcliente;?>">
<button type="button" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">Marcar como em Andamento</button>
</a>
<?php
}


if($status == "Em andamento")
{
?>
<form class="md-float-material form-material" method="post" name="formulario">
<input type="hidden" name="status" value="2">
<input type="hidden" name="idcliente" value="<?php echo $idcliente; ?>">
<input type="text" name="comentario" class="form-control" required="">



<input type="submit" name="enviar" value="Marcar como encerrado" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">  

</form>


</a>
<?php
}


if (!empty($resposta)) {
    ?><h4>Resposta do técnico: <?php echo $resposta; ?></h4><?php
}

?>
                </div>
            </div>
                          </div>





                          <div class="col-md-5">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Sobre o Cliente
                        </div>        
                                      
                                    <div class="panel-body"> 
                                    <h4>Cep: <?php echo $cep; ?> Numero: <?php echo $numero; ?></h4>
                                    <?php
                                    //Ver se usuario está conectado
require 'sistema/logadopppoe.php'; 

    if($desconectado == 1){
        ?>
        <h4>Atualmente, este roteador está <a style="color:red;">DESCONECTADO</a> a internet, você foi desconectado as <?php echo $stoptime; ?> pelo motivo: <?php echo $motivodesconect; ?></h4>
<?php
    }
    else
    {
        ?>
<h4>Atualmente, este roteador está <a style="color:green;">CONECTADO</a> a internet, conexão realizada em <?php echo $starttime; ?> este cliente já consumiu <?php echo $consumo;?> desde a ultima desconexão </h4>
    <?php
    }
//
           
?>



         

                   <br><br>

<a href="https://www.google.com.br/maps/search/<?php echo $coordenadas; ?>" class="btn btn-success btn-lg" style="font-size: 15px;" target="_blank">Ver endereço do cliente no Google Maps</a>

<br><br>          

<a href="https://wa.me/55<?php echo $telefone; ?>?text=Olá, meu nome é <?php echo $nome; ?> e eu estou aqui em nome da Data Web para ajudar você" class="btn btn-success btn-lg" style="font-size: 15px;" target="_blank">Enviar mensagem pelo Whatsapp</a>


<br><br>
   

<a href="cliente.php?id=<?php echo $idcliente; ?>" class="btn btn-success btn-lg" style="font-size: 15px;" target="_blank">Ver mais sobre o cliente</a>

                </div>
            </div>
                          </div>

.<br>.<br>.<br>.
<?php
$sql = "SELECT * FROM `agendas` WHERE `idtipo` = " . $idsuporte;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $data = $row["data"];
        $array=explode("-",$data);
        $mes = $array[1];
        $dia = $array[2];
        $arrayy=explode(" ",$dia);
        $dia = $arrayy[0];
        $hora = $arrayy[1];
        $arrayy=explode(":",$hora);
        $hora = $arrayy[0] . ":" . $arrayy[1];
        $ano = $array[0];
        $data =  "$dia/$mes/$ano as $hora";


        $dataresolvido = $row["resolvidodata"];
        $array=explode("-",$dataresolvido);
        $mes = $array[1];
        $dia = $array[2];
        $arrayy=explode(" ",$dia);
        $dia = $arrayy[0];
        $hora = $arrayy[1];
        $arrayy=explode(":",$hora);
        $hora = $arrayy[0] . ":" . $arrayy[1];
        $ano = $array[0];
        $dataresolvido =  "$dia/$mes/$ano as $hora";
?>
                          <div class="">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Agendamento do suporte
                        </div>
                        <div class="panel-body">
                            <p style="font-size: 25px;">Um agendamento para <?php echo $data; ?> está marcado para esse suporte</p>
                            
                            <p style="font-size: 25px;">Este agendamento foi concluido as <?php echo $dataresolvido; ?></p>
                        
                       
                        </div>
                        <div class="panel-footer" style="font-size: 15px;">
                        <?php
                        if($row["resolvido"] == "1")
                        {

                        }else{
                        ?>
                        <a href="#" class="btn btn-success btn-lg">Mudar data do agendamento.</a>
                        <br><br>
                        <a href="#" class="btn btn-success btn-lg">Cancelar Agendamento.</a>
                        <?php
                        }
                        ?>
                        </div>
                    </div>
                </div>

<?php
    }
}

}
?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
