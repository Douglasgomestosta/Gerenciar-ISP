﻿<?php
session_start();
require 'sistema/db.php'; 
require 'sistema/FUNCTIONS.php'; 
if($_SESSION['usuariocomum'] == 1){exit();}
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `admins` WHERE `id` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $nivel = $row["nivel"];
        }
    }else
    {
        exit();
    }
}
else
{
    header('Location: login.php');
}


if (!is_numeric($_GET['id'])) {
exit();
}
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
<?php
                            $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $_GET['id'];
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            // output data of each row
                            while($row = $result->fetch_assoc()) {
                                $id = $row["id"];
                                $nome = $row["nome"];
                                $email = $row["email"];
                                $telefone = $row["whatsapp"];
                                $plano = $row["plano"];
                                $cpf = $row["cpf"];
                                $observacoes = $row["observacoes"];
                                $cto = $row["caixa"];
                                $asaasid = $row["asaasid"];
                            }
                        }


                        $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            // output data of each row
                            while($row = $result->fetch_assoc()) {
                                $usuariopppoe = $row["usuario"];
                                $senhapppoe = $row["senha"];
                                $ipv4 = $row["ip"];
                                $roteador = $row["roteador"];
                                $mac = $row["mac"];
                                $ativo = $row["ativo"];
                                $bloqueiovirus = $row["bloqueiovirus"];
                                $bloqueioadulto = $row["bloqueioadulto"];
                                $ssidwifi = $row["ssidwifi"];
                                $senhawifi = $row["senhawifi"];
                                $servidor = $row["servidor"];
                                $onu = $row["onu"];
                            }
                        }
if($bloeioadulto == "1"){$bloqueioadulto = "Sim";}else{$bloqueioadulto = "Não";}
if($bloqueiovirus == "1"){$bloqueiovirus = "Sim";}else{$bloqueiovirus = "Não";}

                        $sql = "SELECT * FROM `roteadores` WHERE `id` = " . $roteador;
                        $result = $conn->query($sql);
                        
                        if ($result->num_rows > 0) {
                            // output data of each row
                            while($row = $result->fetch_assoc()) {
                                $marca = $row["marca"];
                                $modelo = $row["modelo"];
                            }
                        }
                       

                         ?>
                         <center>
                           <h3>     <?php echo $nome; ?> </h3>


                           <div class="col-md-7">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Sobre o cliente
                        </div>        
                                      
                                    <div class="panel-body"> 

                    <h4>E-mail: <?php echo $email; ?></h4>
                    <h4>telefone: <?php echo $telefone; ?></h4>
                    <h4>Plano: <?php echo $plano; ?></h4>
                    <h4>cpf: <?php echo $cpf; ?></h4>
                    <h4>Observações: <?php echo $observacoes; ?></h4>
                    

                   
                </div>
            </div>
                          </div>

                          <div class="col-md-5">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Sobre a conexão PPPoE
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <h4>Usuario PPPoE: <?php echo $usuariopppoe; ?></h4>
                                    <h4>Senha PPPoE: <?php echo $senhapppoe; ?></h4>
                                    <h4>Ipv4 Privado: <?php echo $ipv4; ?></h4>

                                    <a href="roteador.php?id=<?php echo $roteador;?>"> <h4>Roteador: <?php echo $marca . " " . $modelo; ?></h4> </a>
                                    <h4>Mac: <?php echo $mac; ?></h4>
                                    <h4>Bloqueio DNS Virus: <?php echo $bloqueiovirus; ?></h4>
                                    <h4>BLoqueio DNS Adulto: <?php echo $bloqueioadulto; ?></h4>
                                    <h4>Ssid Wifi: <?php echo $ssidwifi; ?></h4>
                                    <h4>Senha Wifi: <?php echo $senhawifi; ?></h4>
                                    <h4>Servidor: <?php echo $servidor; ?></h4>
                    
                    <?php
                                    //Ver se usuario está conectado
require 'sistema/logadopppoe.php'; 

    if($desconectado == 1){
        ?>
        <h4>Atualmente, este roteador está <a style="color:red;">DESCONECTADO</a> a internet, você foi desconectado as <?php echo $stoptime; ?> pelo motivo: <?php echo $motivodesconect; ?></h4>
<?php
    }
    else
    {
        ?>
<h4>Atualmente, este roteador está <a style="color:green;">CONECTADO</a> a internet, conexão realizada em <?php echo $starttime; ?> este cliente já consumiu <?php echo $consumo;?> desde a ultima desconexão </h4>
    <?php
    }
//
           
?>
                </div>
            </div>
                          </div>


                          <?php

///Pagamentos
$sql = "SELECT * FROM `pagamentos` WHERE `idusuario` = " . $_GET['id'] . " ORDER BY `id` DESC LIMIT 12";
$result = $conn->query($sql);
?>


<h3>Faturas do Cliente </h3>
<div class="panel panel-default">
                       
                        
                        
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Abrir</th>
                                            <th>Vencimento</th>
                                            <th>Valor</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
    
//echo "Valor:" . $valor->value . "<br>";
//echo "Status:" . $valor->status . "<br>";
$preco = $row["valor"];
$vencimento = $row["vencimento"];
$status = $row["pago"];
$idfatura = $row["id"];
$array=explode("-",$vencimento);
$mes = $array[1];
$dia = $array[2];
$ano = $array[0];
$vencimento =  "$dia/$mes/$ano";
if(!$row["pago"] == "1"){ $cor = "warning";}
if($row["vencido"] == "1"){ $cor = "danger";}
if($row["pago"] == "1") { $cor = "success";}
?>
<tr class="<?php echo $cor; ?>">
        <td><a href="fatura.php?id=<?php echo $idfatura; ?>">Ver mais</a></td>
        <td><?php echo $vencimento; ?></td>
        <td>R$<?php echo $preco; ?></td>
        <?php

        if($row["pago"] == "1")
        {
            ?>
<td><label class="label label-success">Pago</label></td>
            <?php
        }else{
if($row["vencido"] == "1")
{
?>
<td><label class="label label-danger">ATRASADO!</label></td>
<?php 
}else{
?>
<td><label class="label label-danger">Não Pago</label></td>
<?php
}
        }

?>
    </tr>
<?php
}
}
?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>



                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
