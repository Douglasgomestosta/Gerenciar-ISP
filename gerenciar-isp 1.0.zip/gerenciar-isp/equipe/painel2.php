﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['usuariocomum'] == 1){exit();}
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `admins` WHERE `id` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $nivel = $row["nivel"];
        }
    }else
    {
        exit();
    }
}
else
{
    header('Location: login.php');
}



?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    

                    <?php
//Ver se tem pedido de suporte aberto
$sql = "SELECT * FROM `suporte` WHERE `status` LIKE '1' AND `atendente` = " . $id . " ORDER BY `data` DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $nomecliente = $row["nome_cliente"];
        $idsuporte = $row["id"];
        ?>
        <h3 style="color: red;">Atenção! você já tem um pedido de suporte aberto para <?php echo $nomecliente; ?> <a href="suporte.php?id=<?php echo $idsuporte; ?>" style="">Ver pedido de suporte</a> </h3>
        <?php

    }
}
?>
<h1>Estatisticas do serviço </h1>
<?php
//ver usuarios conectados no pppoe
$cont = 0;
$conectados = 0;
$sql = "SELECT * FROM `usuarios` WHERE `ativo` = 1";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $idcliente = $row["id"];
            $cont = $cont + 1;

            $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $idcliente;
            $resultl = $conn->query($sqll);
            
            if ($resultl->num_rows > 0) {
                // output data of each row
                while($rowl = $resultl->fetch_assoc()) {
                    $usuariopppoe = $rowl["usuario"];
                    



                    $sql = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usuariopppoe . "' ORDER BY `acctstarttime` DESC LIMIT 1";
$resultt = $connradius->query($sql);
if ($resultt->num_rows > 0) {
    // output data of each row
    while($row = $resultt->fetch_assoc()) {
        $stoptime = $row["acctstoptime"];
        $starttime = $row["acctstarttime"];
        $motivodesconect = $row["acctterminatecause"];
    
if(empty($stoptime)){
    $conectados = $conectados + 1;
}
    }
}





                }
            }




        }
    }
//
?>
<h3> Usuarios conectados: <?php echo $conectados;  ?>/<?php echo $cont; ?> <a href="clientes.php">Ver Clientes</a>  </h3>

<?php
 //Ver pedidos de suporte

$sql = "SELECT * FROM `suporte` WHERE `status` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>

<h3> Pedidos de suporte pendentes: <?php echo $cont; ?>  <a href="suporte.php">Ver Todos</a>  <a href="addsuporte.php">Criar novo</a> </h3>


<?php
 //ver instalações pendentes

$sql = "SELECT * FROM `adesao` WHERE `andamento` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>

<h3> Instalações pendentes: <?php echo $cont; ?>  <a href="adesao.php">Ver Todos</a>  <a href="addadesao.php">Criar novo</a> </h3>


<?php
//Caixas instaladas no poste
$sql = "SELECT * FROM `caixas`";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>
<h3> Caixas instaladas: <?php echo $cont; ?>   <a href="caixa.php">Ver Todos</a> <a href="addcaixa.php">Adicionar novo</a></h3>

<?php
//Ruas atendidas
$sql = "SELECT * FROM `ruas`";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>
<h3> Ruas atendidas: <?php echo $cont; ?>   <a href="ruas.php">Ver Todas</a> <a href="addruas.php">Adicionar nova</a></h3>


<?php
//Ruas atendidas
$sql = "SELECT * FROM `mudancas` WHERE `andamento` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>
<h3> Mudanças de endereço: <?php echo $cont; ?>   <a href="ruas.php">Ver Todas</a> <a href="addruas.php">Adicionar nova</a></h3>


<?php
 //ver instalações pendentes

$sql = "SELECT * FROM `cancelamentos` WHERE `andamento` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>

<h3> Cancelamentos de serviço pendentes: <?php echo $cont; ?>  <a href="adesao.php">Ver Todos</a>  <a href="addadesao.php">Criar novo</a> </h3>



<p>Painel de administração exclusivo Data Web, Versão BETA 1.0 </p>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
