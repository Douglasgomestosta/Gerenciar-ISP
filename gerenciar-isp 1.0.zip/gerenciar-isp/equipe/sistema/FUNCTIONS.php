<?php
function antipalavroes($texto, $correcao) {

    if($correcao == 1)
    {
        $texto = str_replace('porra', '***', $texto);
        $texto = str_replace('caralho', '***', $texto);
        $texto = str_replace('buceta', '***', $texto);
        $texto = str_replace('xota', '***', $texto);
        $texto = str_replace('foda', '***', $texto);
        $texto = str_replace('fude', '***', $texto);
        $texto = str_replace('foder', '***', $texto);
        $texto = str_replace('cu', '***', $texto);
        $texto = str_replace('puta', '***', $texto);
        $texto = str_replace('viado', '***', $texto);
        $texto = str_replace('veado', '***', $texto);
        $texto = str_replace('boceta', '***', $texto);

    }else
    {

    }


    return $texto;
  }
  //fim anti palavrôes

  function sqlinjection($texto) {
    $texto = str_replace(';', ' ', $texto);
    $texto = str_replace("'", ' ', $texto);
    $texto = str_replace('.', ' ', $texto);
    $texto = str_replace('*', ' ', $texto);
    $texto = str_replace('`', ' ', $texto);
    $texto = str_replace('=', ' ', $texto);
    $texto = str_replace(',', ' ', $texto);

    return $texto;
}
//fim anti sql

//ver se usuario está conectado no pppoe
function pppoeonline($id) {
  $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
  echo $sql;
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
      // output data of each row
      while($row = $result->fetch_assoc()) {
          $usuariopppoe = $row["usuario"];
      }
    }


  $sql = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usuariopppoe . "' ORDER BY `radacctid` DESC limit 1";
  $result = $connradius->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $idacct = $row["radacctid"];
            $stoptime = $row["acctstoptime"];
            $starttime = $row["acctstarttime"];
            $motivodesconect = $row["acctterminatecause"];
        }
    }
    if(empty($stoptime)){
      echo "1";
  }else
  {
      echo "0";
  }


}
//fim pppoe



//ver se faturas do usuario
function asaasfaturas($id) {
  $ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://www.asaas.com/api/v3/payments?customer=" . $id);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);

curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  "access_token: lkkkkkk"
));


$response = curl_exec($ch);
curl_close($ch);


return $response;
}
//fim faturas de um usuario