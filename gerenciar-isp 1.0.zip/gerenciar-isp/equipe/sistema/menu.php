<li>
                        <a  href="../../equipe/painel.php"><i class="fa fa-dashboard fa-3x"></i> Inicio</a>
                    </li>
                      <li>
                        <a  href="../../equipe/suporte.php"><i class="fa fa-desktop fa-3x"></i>Pedidos de suporte</a>
                    </li>
                    <li>
                        <a  href="../../equipe/mapa.php"><i class="fa fa-qrcode fa-3x"></i>Mapa de clientes</a>
                    </li>
                    <li>
                        <a  href="../../equipe/rede.php"><i class="fa fa-qrcode fa-3x"></i>Disponibilidades do sistema</a>
                    </li>

                    <li>
                        <a  href="../../equipe/servidores"><i class="fa fa-qrcode fa-3x"></i>Servidores Firewall</a>
                    </li>