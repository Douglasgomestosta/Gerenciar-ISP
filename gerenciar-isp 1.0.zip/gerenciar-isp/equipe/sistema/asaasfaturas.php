<?php
///asaas


$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://www.asaas.com/api/v3/payments?customer=" . $asaasid);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);

curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  "access_token: kkkkkk"
));


$response = curl_exec($ch);
curl_close($ch);


$decode = json_decode( $response, FALSE );
	


///
