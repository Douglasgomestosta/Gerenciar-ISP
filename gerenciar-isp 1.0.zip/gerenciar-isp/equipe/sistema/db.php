<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "painel";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//database radius
// Create connection
$connradius = new mysqli($servername, $username, $password, "radius");
// Check connection
if ($connradius->connect_error) {
    die("Connection failed: " . $connradius->connect_error);
}