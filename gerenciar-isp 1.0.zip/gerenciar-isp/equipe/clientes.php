﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['usuariocomum'] == 1){exit();}
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `admins` WHERE `id` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $nivel = $row["nivel"];
        }
    }else
    {
        exit();
    }
}
else
{
    header('Location: login.php');
}



?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />


   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>

</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">



                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Clientes
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <div id="dataTables-example_wrapper" class="dataTables_wrapper form-inline" role="grid"><div class="row"><div class="col-sm-6"><div class="dataTables_length" id="dataTables-example_length"></div></div><div class="col-sm-6"><div id="dataTables-example_filter" class="dataTables_filter"></div></div></div><table class="table table-striped table-bordered table-hover dataTable no-footer" id="dataTables-example" aria-describedby="dataTables-example_info">
                                    <thead>
                                        <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Rendering engine: activate to sort column ascending" aria-sort="ascending" style="width: 165px;">Cliente</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" style="width: 256px;">E-mail</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending" style="width: 232px;">Cidade</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending" style="width: 139px;">Ativo</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending" style="width: 98px;">Veja mais</th></tr>
                                    </thead>
                                    <tbody>
                                        
                                        
    


                                
                                        


                                 

<?php
$pagina = $_GET['pagina'];
if(empty($pagina)){
    $pagina = "0";
}
if($pagina < 0)
{
    $pagina = 0;
}
$parte = $_GET['parte'];
$cidade = $_GET['cidade'];
$categoria = $_GET['categoria'];

                    if($_GET['parte'] == "2")
                    {
                        if($_GET['cidade'] == "0")
                        {
                            $sql = "SELECT * FROM `usuarios` ORDER BY id asc LIMIT " . $pagina . ", 30";
                        }

                        if($_GET['cidade'] == "seropedica")
                        {
                            $sql = "SELECT * FROM `usuarios` WHERE `cidade` LIKE 'seropedica' ORDER BY id asc LIMIT " . $pagina . ", 30";
                        }
                        if($_GET['cidade'] == "itaguai")
                        {
                            $sql = "SELECT * FROM `usuarios` WHERE `cidade` LIKE 'itaguai' ORDER BY id asc LIMIT " . $pagina . ", 30";
                        }
                        if($_GET['cidade'] == "paracambi")
                        {
                            $sql = "SELECT * FROM `usuarios` WHERE `cidade` LIKE 'paracambi' ORDER BY id asc LIMIT " . $pagina . ", 30";
                        }


                    
                        if(!empty($_GET['pesquisar'])){
                            $sql = "SELECT * FROM `usuarios` WHERE `nome` LIKE '%" . $_GET['pesquisar'] . "%' ORDER BY id asc LIMIT " . $pagina . ", 30";
                        }


                        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                if($row["ativo"] == "1")
                {
                    $ativo = "Sim";
                }else{ $ativo = "Não";}
                ?>
                 <tr class="gradeA odd">
                                            <td class="sorting_1"><?php echo $row["nome"];?></td>
                                            <td class=" "><?php echo $row["email"];?></td>
                                            <td class=" "><?php echo $row["cidade"];?></td>
                                            <td class="center "><?php echo $ativo;?></td>
                                            <td class="center "><a href="cliente.php?id=<?php echo $row["id"];?>">Ver mais</a> </td>
                                        </tr>
                <?php

            }
        }
$menos = $pagina - 1;
$mais = $pagina + 1;
        ?>


     
                                    
        </tbody>
                                </table>
                                <div class="row">
                                <div class="col-sm-6">
                                <div class="dataTables_info" id="dataTables-example_info" role="alert" aria-live="polite" aria-relevant="all">
                                <a href="?pagina=<?Php echo $menos; ?>&cidade=<?php echo $cidade; ?>&categoria=<?Php echo $categoria; ?>&parte=2" class="btn btn-success"><</a> <?php echo $pagina; ?> <a href="?pagina=<?Php echo $mais; ?>&cidade=<?php echo $cidade; ?>&categoria=<?Php echo $categoria; ?>&parte=2" class="btn btn-success">></a>

                                </div></div><div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate"><ul class="pagination"><li class="paginate_button previous disabled" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_previous"></li><li class="paginate_button next" aria-controls="dataTables-example" tabindex="0" id="dataTables-example_next"></li></ul></div></div></div></div>
                            </div>
                            
                        </div>
                    </div>

<?php
                    }else
                    {
                        ?>
                    <form method="get">
    <input type="hidden" name="parte" value="2">

<h4>Cidade</h4>
                                    <select id="ordenacao" name="cidade">
                                    <option value="0">Todos</option>
                                    <option value="seropedica">seropedica</option>
                                    <option value="paracambi">paracambi</option>
                                    <option value="itaguai">itaguai</option>
                                    </select>
                                    <br><br>
<h4>Categoria</h4>
                                    <select id="ordenacao" name="categoria">
                                    <option value="0">Todos</option>
                                    <option value="1">Houve quedas de energia nas ultimas 12 horas</option>
                                    </select>
                                        
                                
                                        <tr>

                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </form>



                                <br>
                                <form method="get">
    <input type="hidden" name="parte" value="2">

<h4>Pesquisar:</h4>

<input tabindex="2" type="text" size="50px" style="width:500px;" class="input is-large" name="pesquisar" maxlength="200" placeholder="Pesquisar...">                           
                                    

                                        <tr>

                                            <td style="padding: 0 0 6px 0;">
                                                <input tabindex="3" type="submit" value="Pesquisar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </form>

<?php
                    }
?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
