﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['usuariocomum'] == 1){exit();}
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `admins` WHERE `id` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $nivel = $row["nivel"];
            $cidade = $row["cidade"];
        }
    }else
    {
        exit();
    }
}
else
{
    header('Location: login.php');
}




?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <link rel="stylesheet" href="https://unpkg.com/leaflet@1.0.3/dist/leaflet.css" integrity="sha512-07I2e+7D8p6he1SIM+1twR5TIrhUQn9+I6yjqD53JQjFiMf8EtC93ty0/5vJTZGF8aAocvHYNEDJajGdNx1IsQ==" crossorigin=""/>

   <style>
      #location-map{
        background: #fff;
        border: none;
        height: 540px;
        width: 100%;

        box-sizing: border-box;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
      }
    </style>


<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


</style>

</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
<?php
if (!is_numeric($_GET['id'])) {

?>
<div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Problemas externos
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <div id="dataTables-example_wrapper" class="dataTables_wrapper form-inline" role="grid"><div class="row"><div class="col-sm-6"><div class="dataTables_length" id="dataTables-example_length"></div></div></div><table class="table table-striped table-bordered table-hover dataTable no-footer" id="dataTables-example" aria-describedby="dataTables-example_info">
                                    <thead>
                                        <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column ascending" style="width: 157px;">Id da rota</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" style="width: 243px;">Data</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending" style="width: 221px;">Status</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending" style="width: 133px;">Engine version</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending" style="width: 93px;">Abrir</th></tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php
                                    //problemas externos
$problemasexternos = 0;
$sql = "SELECT * FROM `problemasexternos` ORDER BY `id` DESC";
$result = $conn->query($sql);
                        if ($result->num_rows > 0) {while($row = $result->fetch_assoc()) {
$idrota = $row['rota'];
$dataproblema = $row['data'];
$idproblemaexterno = $row['id'];
if($row['andamento'] == "1")
{
    $andamento = "Em reparo";
}elseif($row['andamento'] == "2")
{
    $andamento = "Solucionado";
}
else
{
    $andamento = "Aguardando técnico.";
}
$sqll = "SELECT * FROM `rotas` WHERE `id` = ". $idrota;
$resultt = $conn->query($sqll);
if ($resultt->num_rows > 0) {while($roww = $resultt->fetch_assoc()) {
    $cidadeproblema = $roww['cidade'];
    $problemaexterno = strpos(" " . $cidade,$cidadeproblema);
    if($problemaexterno > 0)
    {
        //aqui
        ?>
        <tr class="gradeA odd">
                                            <td class="sorting_1"><?php echo $idrota; ?></td>
                                            <td class=" "><?php echo $dataproblema; ?></td>
                                            <td class=" "><?php echo $andamento; ?></td>
                                            <td class="center ">1.7</td>
                                            <td class="center "><a href="?id=<?php echo $idproblemaexterno; ?>" class="btn btn-primary">Abrir</a></td>
                                        </tr>
                                        <?php
    }
                            }}

                        }}
                                        
                                        
                                        
                                ?>       
                                        
                                        
                                        
                                  
                                  </tbody>
                                </table><div class="row"></div></div>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
<?php
}else{
    if (!is_numeric($_GET['id'])) {echo "Utilize somente numeros no campo id"; exit();}
    //se estiver status como 1 coloca o técnico no suporte
    if($_GET['status'] == 1)
    {
        $sql = "UPDATE `problemasexternos` SET `andamento` = '1', `tecnico` = '" . $id . "' WHERE `problemasexternos`.`id` = " . $_GET['id'] . ";";
        $result = $conn->query($sql);

        //mudar suportes linkados
        $sql = "UPDATE `suporte` SET `status` = '1', `atendente` = '" . $id . "' WHERE `suporte`.`externo` = " . $_GET['id'] . ";";
        $result = $conn->query($sql);

    
    }
    if($_POST['status'] == 2){
        //se status é 2 coloca o problema como solucionado
$sql = "UPDATE `problemasexternos` SET `andamento` = '2', `razao` = '" . $_POST['comentario'] . "', `datasolucionado` = CURRENT_TIMESTAMP WHERE `problemasexternos`.`id` = " . $_GET['id'] . ";";
$result = $conn->query($sql);

//mudar suportes linkados
$sql = "UPDATE `suporte` SET `status` = '2', `Resposta` = '" . $_POST['comentario'] . "', `resolvidodata` = CURRENT_TIMESTAMP WHERE `suporte`.`externo` = " . $_GET['id'] . ";";
$result = $conn->query($sql);
    }
    $sql = "SELECT * FROM `problemasexternos` WHERE `id` = " . $_GET['id'];
    $result = $conn->query($sql);
                            if ($result->num_rows > 0) {while($row = $result->fetch_assoc()) {
                                $mostrartecnico = "1";
                                $idrota = $row['rota'];
                                $idproblemaexterno = $row['id'];
                               
                                if($row['andamento'] == "1")
{
    $andamento = "Em reparo";
    $andamenton = "1";
}elseif($row['andamento'] == "2")
{
    $andamento = "Solucionado";
    $andamenton = "2";
}
else
{
    $andamento = "Aguardando técnico.";
    $mostrartecnico = "0";
    $andamenton = "0";
}
                            ?>
                    <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Detalhes
                        </div>        
                                      
                                    <div class="panel-body"> 

                                 


                   <center><h2>Rota <?php echo $row['rota']; ?></h2></center>
                   
                   
    <h3>Data da abertura: <?php echo $row['data']; ?> </h3>
    <h3>Andamento: <?php echo $andamento; ?> </h3>
    <?php
    if($mostrartecnico == "1")
{
    $sql = "SELECT * FROM `admins` WHERE `id` = " . $row['tecnico'];
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {while($row = $result->fetch_assoc()) {
        $nometecnico = $row['nome'];
    }
}        
?>
    <h3>Técnico: <?php echo $nometecnico; ?></h3>
<?php
}
?>
<?php
$sql = "SELECT * FROM `pppoe` WHERE `ativo` = 1 AND `rota` = " . $idrota;
$result = $conn->query($sql);
$clientesrota = mysqli_num_rows($result);
?>
              <h3>Clientes nessa rota: <?php echo $clientesrota; ?></h3>

              <?php
              $clientesdesconectados = 0;
              $sql = "SELECT * FROM `pppoe` WHERE `ativo` = 1 AND `rota` = " . $idrota;
              $result = $conn->query($sql);
              if ($result->num_rows > 0) {while($row = $result->fetch_assoc()) {
                $usernamepppoe = $row["usuario"];
                $sqll = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usernamepppoe . "' ORDER BY `radacctid` DESC limit 1";
    $resultl = $connradius->query($sqll);
                if ($resultl->num_rows > 0) {
                    // output data of each row
                    while($rowl = $resultl->fetch_assoc()) {
                        $motivodesconect = $rowl["acctterminatecause"];
                        $stoptime = $rowl["acctstoptime"];
                        $starttime = $rowl["acctstarttime"];
                        
                        if(empty($motivodesconect)){
                            $desconectado = "0";
                        }else
                        {
                            $desconectado = "1";
                        }

                        if($desconectado == "1")
                        {
                        $clientesdesconectados = $clientesdesconecados + 1;
                        }


                    }}

              }
            }

              ?>
              <h3>Clientes desconectados nessa rota: <?php echo $clientesdesconectados; ?></h3>     
                   
                   <?php
                   $sql = "SELECT * FROM `suporte` WHERE `externo` = " . $idproblemaexterno;
                   
                   $result = $conn->query($sql);
                   $suportesnarota = mysqli_num_rows($result);
                   ?>
                   <h3>Clientes com pedidos de suporte em aberto nessa rota com esse problema externo marcado: <?php echo $suportesnarota; ?> </h3>
         
<?php
if($andamenton == "0")
{
?>
<a href="?status=1&id=<?php echo $_GET['id']; ?>" class="btn btn-primary btn-lg">Atender ao chamado externo</a>
  <?php
                            }
                            if($andamenton == "1"){
                               ?>
                               <form class="md-float-material form-material" method="post" name="formulario" action="?id=<?php echo $_GET['id']; ?>">
<input type="hidden" name="status" value="2">
<input type="text" name="comentario" class="form-control" required="" placeholder="O que aconteceu?">



<input type="submit" name="enviar" value="Marcar como encerrado" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">  

</form>
                               <?php
                            }
                           ?>                 


                                    </div>
                    </div>
                    </div>
                    </div>
                    </div>



                    <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Mapa da rota
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    
                                    <iframe src="https://www.google.com/maps/d/u/0/embed?mid=149kBh6ywp6JrIJobN1Js1OaV4bNNNjRr" width="100%" height="500"></iframe>														
									

                                    </div>
                    </div>
                    </div>
                    
                    


                    <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Mapa de clientes da rota
                        </div>        
                                      
                                    <div class="panel-body"> 

                                  
 <div id="location-map"></div>
    
    <script src="https://unpkg.com/leaflet@1.0.3/dist/leaflet.js" integrity="sha512-A7vV8IFfih/D732iSSKi20u/ooOfj/AGehOKq0f4vLT1Zr2Y+RX7C+w8A1gaSasGtRUZpF/NZgzSAu4/Gc41Lg==" crossorigin=""></script>

    <script type="text/javascript">
      var map = L.map('location-map').setView([	-22.7397, -43.6956], 12);
      mapLink = '<a href="https://openstreetmap.org">OpenStreetMap</a>';
      L.tileLayer(
        'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: 'Map data &copy; ' + mapLink,
          maxZoom: 20,
        }).addTo(map);
        




        var offline = L.icon({
    iconUrl: 'imagens/offline.png',
    iconSize:[20, 20],
});

var online = L.icon({
    iconUrl: 'imagens/online.png',
    iconSize:[20, 20],
});


var nuncaonline = L.icon({
    iconUrl: 'imagens/nuncaonline.png',
    iconSize:[20, 20],
});

<?php
$sql = "SELECT * FROM `pppoe` WHERE `ativo` = 1 AND `rota` = " . $idrota;
$result = $conn->query($sql);
if ($result->num_rows > 0) {while($row = $result->fetch_assoc()) {
    $usernamepppoe = $row["usuario"];
    $idcliente = $row["idcliente"];

    $sqll = "SELECT * FROM `usuarios` WHERE `id` = " . $idcliente;
    $resultt = $conn->query($sqll);
        
    if ($resultt->num_rows > 0) {
        // output data of each row
        while($roww = $resultt->fetch_assoc()) {
            $coordenadas = $roww["coordenadas"];
            $nome = $roww["nome"];
            $id = $roww["id"];
        }
    }

    $sqll = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usernamepppoe . "' ORDER BY `radacctid` DESC limit 1";
    $resultl = $connradius->query($sqll);
                if ($resultl->num_rows > 0) {
                    // output data of each row
                    while($rowl = $resultl->fetch_assoc()) {
                        $motivodesconect = $rowl["acctterminatecause"];
                        $stoptime = $rowl["acctstoptime"];
                        $starttime = $rowl["acctstarttime"];
                        
                        if(empty($motivodesconect)){
                            $desconectado = "0";
                        }else
                        {
                            $desconectado = "1";
                        }

                        if($desconectado == "1")
                        {
                            ?>
                            console.log("usuario: <?php echo $usernamepppoe; ?> desconectado localização: <?php echo $coordenadas; ?> status: <?php echo $motivodesconect; ?> stop time: <?php echo $stoptime; ?>");
                            var marker = L.marker([<?php echo $coordenadas;?>], {icon: offline}).addTo(map).bindPopup('usuario desconectado: <?php echo $nome; ?> <br>motivo: <?php echo $motivodesconect; ?>');
                            <?php
                        }

                        if($desconectado == "0")
                        {
                            ?>
                            console.log("usuario: <?php echo $usernamepppoe; ?> conectado localização: <?php echo $coordenadas; ?>");
                            var marker = L.marker([<?php echo $coordenadas;?>], {icon: online}).addTo(map).bindPopup('usuario conectado: <?php echo $nome; ?>');
                            <?php
                        }

                    }}


?>

<?php
}}
?>



</script>


									

                                    </div>
                    </div>
                    </div>



                            <?php
                            }
                        }
}
?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
