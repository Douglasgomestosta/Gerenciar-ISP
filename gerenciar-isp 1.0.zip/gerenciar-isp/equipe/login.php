<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE); 
require 'sistema/db.php'; 
if (!empty($_GET['redirect'])) {
    if (strpos($_GET['redirect'], 'http://') !== false) { exit();}
        if (strpos($_GET['redirect'], 'https://') !== false) { exit();}
            if (strpos($_GET['redirect'], 'www.') !== false) { exit();}
}
if($_SESSION['login'] == 1)
{
    if (empty($_GET['redirect'])) {
        header('Location: painel.php');
    }else
    {
        header('Location: ' . $_GET['redirect']);
    }



}
if($_POST['login'] == 1)
{
  require 'sistema/db.php';
  $email = $_POST['email'];
  $senha = $_POST['senha'];
  $senha = md5($senha);
	$email = filter_var($email, FILTER_SANITIZE_EMAIL);
  if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
  } else {
    exit();
exit();
  }


$sql = "SELECT * FROM `admins` WHERE `email` LIKE '" . $email . "' AND `senha` LIKE '" . $senha . "'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        if ($senha == $row["senha"])
        {
          $_SESSION['login'] = "1";
          $_SESSION['email'] = $email;
          $_SESSION['senha'] = $senha;
          $_SESSION['id'] = $row["id"];
          header('Location: painel.php');

        }else
        {
          exit();
        }
    }
} else {
    exit();
}
$conn->close();
  




  exit();
}
?>
<!DOCTYPE html>
<html>
    
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login no painel Data Web</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="css/bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css">
    <script src="https://apis.google.com/js/platform.js" async defer></script>
		<meta name="google-signin-client_id" content="445439223398-q0va4v6j61oc8q5k3fllabbnj6quib83.apps.googleusercontent.com">
</head>

<body>
    <section class="hero is-success is-fullheight">
        <div class="hero-body">
            <div class="container has-text-centered">
                <div class="column is-4 is-offset-4">
                    
<img class="default" alt="" src="https://i.imgur.com/y1XNdSJ.png">


                    <?php if($_GET['erro'] == "1"){?>
                    <div class="notification is-danger">
                      <p>Este e-mail não é valido, o seu email precisa conter usuario@servidor.com <br>ex: jailson23@gmail.com</p>
                    </div>
                <?php } ?>


                <?php if($_GET['erro'] == "2"){?>
                    <div class="notification is-danger">
                      <p>A senha digitada não é a correta ou não existe nenhum cliente com este e-mail e senha iguais <a tabindex="5" class="vst-advanced" href="reset.php">
                                                       Esqueceu sua senha?
                                                    </a></p>
                    </div>
                <?php } ?>
                    <div class="box">
                       




                    


<form method="post">
<input type="hidden" name="login" value="1">
                                    <table class="login-box">
                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                                E-mail
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="1" type="text" size="20px" style="width:240px;" name="email" class="input is-large">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
                                                Senha
                                                
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="2" type="password" size="20px"  style="width:240px;"  class="input is-large" name="senha" >
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Entrar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>



                               

                                		






                    </div>
                </div>
            </div>
        </div>
    </section>
    
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</body>

</html>