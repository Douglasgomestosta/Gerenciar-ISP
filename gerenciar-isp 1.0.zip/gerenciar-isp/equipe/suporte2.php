<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['usuariocomum'] == 1){exit();}
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `admins` WHERE `id` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $nivel = $row["nivel"];
        }
    }else
    {
        exit();
    }
}
else
{
    header('Location: login.php');
}

if (!empty($_GET['id'])) {
if (!is_numeric($_GET['id'])) {
  echo "Utilize somente numeros no campo suporte";
  exit();
}
$suporteaberto = "1";
}else
{
  $suporteaberto = "0";
}


?>
<html lang="en"><head>
<title>painel do funcionario | Data Web</title>




<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<link rel="icon" href="../files/assets/images/favicon.ico" type="image/x-icon">

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="csspanel/bootstrap.min.css">

<link rel="stylesheet" href="csspanel/waves.min.css" type="text/css" media="all">

<link rel="stylesheet" type="text/css" href="csspanel/feather.css">

<link rel="stylesheet" type="text/css" href="csspanel/font-awesome-n.min.css">

<link rel="stylesheet" href="csspanel/chartist.css" type="text/css" media="all">

<link rel="stylesheet" type="text/css" href="csspanel/style.css">
<link rel="stylesheet" type="text/css" href="csspanel/widget.css">


<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


</style>
</head>
<body themebg-pattern="theme1">

<div class="loader-bg" style="display: none;">
<div class="loader-bar"></div>
</div>

<div id="pcoded" class="pcoded iscollapsed" nav-type="st2" theme-layout="vertical" vertical-placement="left" vertical-layout="wide" pcoded-device-type="desktop" vertical-nav-type="expanded" vertical-effect="shrink" vnavigation-view="view1" fream-type="theme1" layout-type="light">
<div class="pcoded-overlay-box"></div>
<div class="pcoded-container navbar-wrapper">

<img class="default" alt="" src="https://i.imgur.com/y1XNdSJ.png">

<div>

<div class="page-header card">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">

<div class="d-inline">
</div>
</div>
</div>
<div class="col-lg-4">
<div class="page-header-breadcrumb">

</div>
</div>
</div>
</div>

<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-body">

<div class="row">

<div class="col-md-12 col-xl-8">
<div class="card sale-card">
<div class="card-header">
<h5>Bem Vindo, <?php echo $nome; ?></h5>
</div>
<div class="card-block">
<?php
if($suporteaberto == "1")
{
$idsuporte = $_GET['id'];
  
if($_GET['status'] == "1"){
  $sql = "UPDATE `suporte` SET `status` = '1', `atendente` = '" . $id . "' WHERE `suporte`.`id` = " . $_GET['id'] . ";";

  
  if ($conn->query($sql) === TRUE) {}}


  if($_POST['status'] == "2"){
      $sql = "UPDATE `suporte` SET `status` = '2', `Resposta` = '" . $_POST['comentario'] . "' WHERE `suporte`.`id` = '" . $_GET['id'] . "';";
      
      if ($conn->query($sql) === TRUE) {}

      $sql = "INSERT INTO `notificacoes` (`id`, `idusuario`, `texto`, `conteudo`, `exibido`, `data`) VALUES (NULL, '" . $_POST['idcliente'] . "', 'Seu pedido de suporte foi respondido!', 'O tecnico " . $nome . " respondeu pelo seu pedido de suporte <br> " . $_POST['comentario'] . "', '0', CURRENT_TIMESTAMP);";
      if ($conn->query($sql) === TRUE) {}
    
    }


$sql = "SELECT * FROM `suporte` WHERE `id` LIKE '" . $_GET['id'] . "' ORDER BY `data` DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $nome = $row["nome_cliente"];
        $problema = $row["problema"];
        $rua = $row["Rua"];
        $status = $row["status"];
        $idsuporte = $row["id"];
        $log = $row["Log"];
        $resposta = $row["Resposta"];
        $idcliente = $row["idcliente"];
        $respostacliente = $row["respostacliente"];
        $atendente = $row["atendente"];
    }
}
if($atendente == "0"){} else
{
    $sql = "SELECT * FROM `admins` WHERE `id` = " . $atendente;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $nomeadmin = $row["nome"];
    }
}
?>
<h4>Funcionario responsavel por este pedido de suporte: <?php echo $nomeadmin; ?></h4>
<?php
}
$sql = "SELECT * FROM `usuarios` WHERE `id` = " . $idcliente;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $email = $row["email"];
        $velocidade = $row["velocidade"];
        $cep = $row["cep"];
        $numero = $row["numero"];
        $coordenadas = $row["coordenadas"];
        $idusuario = $row["id"];
    }
}
if($status == "0") { $status = "Aguardando...";}
if($status == "1") { $status = "Em andamento";}
if($status == "2") { $status = "Encerrado";}
?>
Nome do Cliente: <?php echo $nome;?> <br>
Problema: <?php echo $problema; ?> <br>
Rua: <?php echo $rua; ?> <br>
Cep: <?php echo $cep; ?> <br>
Numero da casa: <?php echo $numero; ?> <br>
Status: <?php echo $status; ?><br>
Log do relatorio: <?php echo $log; ?> <br>
Email do cliente: <?php echo $email; ?><br>
Velocidade Contratada: <?php echo $velocidade; ?>MB<br>
Resposta do cliente: <?php echo $respostacliente; ?>
<br><br><br>
<a href="https://www.google.com.br/maps/search/<?php echo $coordenadas; ?>" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Ver endereço no Google Maps</a><br><br>

<?php if($status == "Encerrado")
{
    ?>
<h5>Resposta do atendente: <?php echo $resposta; ?>
<?php
}
if($status == "Aguardando...")
{
?>
<a href="suporte.php?id=<?php echo $idsuporte; ?>&status=1&idcliente=<?php echo $idcliente;?>">
<button type="button" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">Marcar como em Andamento</button>
</a>
<?php
}

if($status == "Em andamento")
{
?>
<form class="md-float-material form-material" method="post" name="formulario">
<input type="hidden" name="status" value="2">
<input type="hidden" name="idcliente" value="<?php echo $idcliente; ?>">
<input type="text" name="comentario" class="form-control" required="">


</div>
</div>
<div class="row m-t-30">
<div class="col-md-12">
<input type="submit" name="enviar" value="Marcar como encerrado" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">  
</div>
</div>
</div>
</div>
</form>


</a>
<?php
}

}


if($suporteaberto == "0")
{
  if($_POST['parte'] == "2")
  {
    if($_POST['problema'] == "1") { $sql = "SELECT * FROM `suporte` WHERE `status` LIKE '0' ORDER BY `data` ASC"; }
    if($_POST['problema'] == "2") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '1' AND `status` LIKE '0' ORDER BY `data` ASC"; }
    if($_POST['problema'] == "3") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '2' AND `status` LIKE '0' ORDER BY `data` ASC"; }
    if($_POST['problema'] == "4") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '3' AND `status` LIKE '0' ORDER BY `data` ASC"; }
    if($_POST['problema'] == "5") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '4' AND `status` LIKE '0' ORDER BY `data` ASC"; }
    if($_POST['problema'] == "6") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '5' AND `status` LIKE '0' ORDER BY `data` ASC"; }
    if($_POST['problema'] == "7") { $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '6' AND `status` LIKE '0' ORDER BY `data` ASC"; }
    ?>
<div class="card-header-right">


</div>
</div>
<div class="card-block p-b-0">
<div class="table-responsive">
<table class="table table-hover m-b-0">
<thead>
<tr>
<th>Categoria</th>
<th>Problema</th>
<th>///</th>
<th>Status</th>
</tr>
</thead>
<tbody>
<?php

    $result = $conn->query($sql);
    $temsuportes = "0";
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $temsuportes = "1";
            $problema = $row["problema"];
            $categoria = $row["categoria"];
            $idsuporte = $row["id"];
            $status = $row["status"];
            if($categoria == 1){$categoria = "Estou sem internet";}
            if($categoria == 2){$categoria = "Minha conexão a internet está lenta";}
            if($categoria == 3){$categoria = "Estou com problemas de perda de pacotes ou alta latencia";}
            if($categoria == 4){$categoria = "Estou com pronlemas relacionado ao pagamento da minha conta";}
            if($categoria == 5){$categoria = "Tenho perguntas";}
            if($categoria == 6){$categoria = "Outros assuntos";}

            $sqll = "SELECT * FROM `usuarios` WHERE `id` = " . $row["idcliente"];
    $resultt = $conn->query($sqll);
    if ($resultt->num_rows > 0) {
        // output data of each row
        while($roww = $resultt->fetch_assoc()) { $cep = $roww["cep"]; }}

        $sqll = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "'";
    $resultt = $conn->query($sqll);
    if ($resultt->num_rows > 0) {
        // output data of each row
        while($roww = $resultt->fetch_assoc()) { $cidade = $roww["cidade"]; }}
if($_POST['cidade'] == "1" || $_POST['cidade'] == $cidade)
{
            ?>
<tr>
<td> <a href="?id=<?php echo $idsuporte; ?>"><?php echo $categoria; ?></a></td> 
<td><?php echo $problema; ?></td>
<td>0</td>
<?php
if($status == 0)
{
    ?>
<td><label class="label label-danger">Aguardando...</label></td>
<?php
}
if($status == 1)
{
    ?>
<td><label class="label label-danger">Em analise...</label></td>
<?php
}
if($status == 2)
{
    ?>
<td><label class="label label-success">Resolvido</label></td>
<?php
}
?>
</tr>
            <?php
}
        }
    }
    
?>



    
        















</tbody>
</table>
</div>
</div>
</div>
</div>


<br><br><br>
<a href="suporte.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar ao menu</a><br><br>


<?php


    exit();
  }
?>
<form method="post">
    <input type="hidden" name="parte" value="2">
                                    <table class="login-box">
                                        <h3>Tipo de problema </h3>
                                    <select id="ordenacao" name="problema">
                                    <option value="1">Todos</option>
                                    <option value="2">Estou sem internet</option>
                                    <option value="3">Minha conexão a internet está lenta</option>
                                    <option value="4">Estou com problemas de perda de pacotes ou alta latência </option>
                                    <option value="5">Estou com problemas relacionado ao pagamento da minha conta</option>
                                    <option value="6">Tenho perguntas, perguntas que precisam ser respondidas!</option>
                                    <option value="7">Outros assuntos</option>
                                    </select>
<br>
<H3>Cidade </h3>
<select id="ordenacao" name="cidade">
                                    <option value="1">Todos</option>
                                    <option value="seropedica">Seropedica</option>
                                    <option value="Paracambi">Paracambi</option>
                                    
                                    </select>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
<?php
}
?>
<br><br><br>
<a href="painel.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar ao inicio</a><br><br>

<script type="text/javascript" src="jspanel/jquery-ui.min.js"></script>
<script type="text/javascript" src="jspanel/popper.min.js"></script>
<script type="text/javascript" src="jspanel/bootstrap.min.js"></script>

<script src="jspanel/waves.min.js" type="text/javascript"></script>

<script type="text/javascript" src="jspanel/jquery.slimscroll.js"></script>

<script src="jspanel/jquery.flot.js" type="text/javascript"></script>
<script src="jspanel/jquery.flot.categories.js" type="text/javascript"></script>
<script src="jspanel/curvedLines.js" type="text/javascript"></script>
<script src="jspanel/jquery.flot.tooltip.min.js" type="text/javascript"></script>

<script src="jspanel/chartist.js" type="text/javascript"></script>

<script src="jspanel/amcharts.js" type="text/javascript"></script>
<script src="jspanel/serial.js" type="text/javascript"></script>
<script src="jspanel/light.js" type="text/javascript"></script>

<script src="jspanel/pcoded.min.js" type="text/javascript"></script>
<script src="jspanel/vertical-layout.min.js" type="text/javascript"></script>
<script type="text/javascript" src="jspanel/custom-dashboard.min.js"></script>
<script type="text/javascript" src="jspanel/script.min.js"></script>




<div class="flotTip" style="display: none; position: absolute; background: rgb(255, 255, 255); z-index: 1040; padding: 0.4em 0.6em; border-radius: 0.5em; font-size: 0.8em; border: 1px solid rgb(17, 17, 17); white-space: nowrap;"></div></body></html>