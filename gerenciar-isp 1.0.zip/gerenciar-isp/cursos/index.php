﻿<?php
session_start();
//error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
require '../sistema/FUNCTIONS.php'; 



// Create connection
$connn = new mysqli($servername, $username, $password, "datawebeduca");
// Check connection
if ($connn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$connn->set_charset('utf8');


if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $cep = $row["cep"];
            $ativo = $row["ativo"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
            $velocidade = $row["velocidade"];
            $velocidademinima = $row["velocidademinima"];
        }
    }
    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
            $ssidwifi = $row["ssidwifi"];
           
        }
    }





}
else
{
    header('Location: ../login.php?redirect=causas');
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>

<script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php
                    $sql = "SELECT * FROM `usuarios` WHERE `idinternet` = " . $id;
                    $result = $connn->query($sql);
                    $cont = mysqli_num_rows($result);
                    ?>
            

<h2>Aprenda conteudos para a sua vida com a Data Web</h2>
<h3>Com a Data Web você tem acesso a diversos conteudos de auto-aprendizado para melhorar a sua vida.</h3>

<a href="../datawebeduca" class="btn btn-primary btn-lg">Acessar Data Web Educa.</a> 
<?php
if($cont < 3)
{
?>
<a href="criar.php" class="btn btn-success btn-lg">Criar novo usuario.</a>
<?php
}else{
    ?>
    <a href="#" class="btn btn-danger btn-lg">Você atingiu o limite de usuarios.</a>
    <?Php
}
?>
<div class="panel panel-default">
                       <h4>Estes são os seus usuarios do Data Web Educa.</h4>
                        
                        
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Editar perfil</th>
                                            <th>Nome</th>
                                            <th>Email</th>
                                        </tr>
                                    </thead>
                                    <tbody>




<?php
$sql = "SELECT * FROM `usuarios` WHERE `idinternet` = " . $id;
$result = $connn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $nome = $row["nome"]." ".$row["sobrenome"];
        $email = $row["email"];
        $idcurso = $row["id"];
       ?>
                                     <tr class="<?php echo $cor; ?>">
       <td><a href="editar.php?id=<?php echo $idcurso; ?>">Editar</a></td>
                                            <td><?php echo $nome; ?></td>
                                            <td><?php echo $email; ?></td>

                                            </tr>
       <?php
    }
}else{
    echo "<h4>Você ainda não tem nenhuma conta criada na Data Web Educa, você pode criar até 3 contas para você e seus familiares no botão verde acima. </h4>";
}
?>


</tbody>
                                </table>
                            </div>
                        </div>
                    </div>




                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
   
    
   
</body>
</html>
