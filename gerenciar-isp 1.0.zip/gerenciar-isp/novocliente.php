﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
            $desativado = $row["desativado"];
        }
    }


    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
           
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            
        }
    }
}
else
{
    header('Location: login.php');
    exit();
}

$sql = "SELECT * FROM `cancelamentos` WHERE `idcliente` LIKE '" . $id . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $idcliente = $row["idcliente"];
        $andamento = $row["andamento"];
        if($id == $idcliente)
        {
            header('Location: cancelar.php');
        }
    }
}



$iphone = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
$ipad = strpos($_SERVER['HTTP_USER_AGENT'],"iPad");
$android = strpos($_SERVER['HTTP_USER_AGENT'],"Android");
$palmpre = strpos($_SERVER['HTTP_USER_AGENT'],"webOS");
$berry = strpos($_SERVER['HTTP_USER_AGENT'],"BlackBerry");
$ipod = strpos($_SERVER['HTTP_USER_AGENT'],"iPod");
$symbian = strpos($_SERVER['HTTP_USER_AGENT'],"Symbian");
$windowsphone = strpos($_SERVER['HTTP_USER_AGENT'],"Windows Phone");
if ($iphone || $ipad || $android || $palmpre || $ipod || $berry || $symbian || $windowsphone == true) { $mobile = "1";}else { $mobile = "0";} 
if($mobile == "1"){
$tamanhoplay = "50%";
}else{
  $tamanhoplay = "18%";
}

$sql = "UPDATE `usuarios` SET `jalogou` = '1' WHERE `usuarios`.`id` = " . $id . ";";
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
<?php
$array=explode(" ",$nome);
$nome = $array[0];

?>

<h3>BEM VINDO A DATA WEB, <?php echo $nome; ?></h3>
<h4>Estamos super empolgados com a sua chegada e para começar que tal eu apresentar a você as funcionalidades que tem disponivel em seu painel do assinante? </h4>





<div class="col-md-7">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

                  


<h4> <img src="../imagens/semconexao.png" width="52px">Suporte técnico 24 horas.</h4>
  <h5>Com o painel do assinante Data Web você pode fazer pedidos de suporte técnico 24 horas por dia, 7 dias por semana, incluindo feriados! e sem precisar falar com um atendente, se o sistema constatar que o problema é possivelmente interno, você inclusive já consegue marcar o horário que o técnico vai até a sua casa, tudo rápido e na palma da sua mão!</h5>        
                </div>
            </div>
                          </div>




                          <div class="col-md-5">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

                  


<h4> <img src="../imagens/plano.png" width="52px">Faça alterações no seu serviço</h4>
<h5>Você pode cancelar, trocar de endereço e até mudar o seu plano de internet sem precisar falar com um atendente, sem precisar esperar na fila de espera. </h5>
    
                   
                </div>
            </div>
                          </div>





                          <div class="col-md-7">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

                  


<h4> <img src="../imagens/money.png" width="52px">Pague suas faturas de internet com facilidade</h4>
  <h5>Pague suas faturas de maneira super fácil no seu painel do assinante, nós aceitamos diversas formas de pagamento como o antigo Boleto, pagamento na lotérica, pagamento com cartão de crédito, PIX e até saldo em conta MercadoPago!</h5>        
                </div>
            </div>
                          </div>




                          <div class="col-md-5">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

                  


<h4> <img src="../imagens/notification-flat.png" width="52px">Receba notificações sobre o serviço(app)</h4>
<h5>Se você estiver utilizando o nosso aplicativo, você receberá notificações sobre o seu serviço, como notificações de pagamento de fatura, falhas no serviço, falhas em grandes serviços(como facebook e youtube) e muito mais, na Data Web você não fica desinformado sobre problemas que afetam você.</h5>
    
                   
                </div>
            </div>
                          </div>












<br>
<p>.</p>
                          <h3>Além disso, esperamos de coração que você tenha uma boa experiencia usando os novos serviços e sinta-se livre para reclamar e elogiar qualquer coisa que você achar necessario, a opinião de nossos clientes é extremamente importante para manter a qualidade de nosso serviço. </h3>

                          <center> <a href="painel.php" class="btn btn-primary btn-lg">Obrigado!</a></center>

<br>
                          <div class="">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

                  


<h4>Baixe nosso aplicativo para Android</h4>
<h5>Se você ainda não baixou o nosso aplicativo para Android, recomendamos fortemente que você baixe, já que com o nosso aplicativo você recebe notificações, e tem mais opções e informações pelo app.</h5>
    
<center><a href="https://play.google.com/store/apps/details?id=site.datawebtelecom.dataweb" target="_blank"> <img src="imagens/googleplay.png" width="<?php echo $tamanhoplay;?>"> </a></center>
                   
                </div>
            </div>
                          </div>

<p>Painel de administração exclusivo Data Web, Versão <?php echo $versao; ?> </p>
                     
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   

    <div vw class="enabled">
    <div vw-access-button class="active"></div>
    <div vw-plugin-wrapper>
      <div class="vw-plugin-top-wrapper"></div>
    </div>
  </div>
  <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
  <script>
    new window.VLibras.Widget('https://vlibras.gov.br/app');
  </script>
</body>
</html>
