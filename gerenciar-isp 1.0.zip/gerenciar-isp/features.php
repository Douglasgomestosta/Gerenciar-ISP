﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
require 'sistema/FUNCTIONS.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
            $senha = $row["senha"];
            $cpf = $row["cpf"];
            $cepantigo = $row["cep"];
            $numeroantigo = $row["numero"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
        }
    }


    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
            $senhapppoe = $row["senha"];
            $ip = $row["ip"];
            $roteador = $row["roteador"];
            $mac = $row["mac"];
            $ativopppoe = $row["ativo"];
            $servidor = $row["servidor"];

        }
    }
}
else
{
    header('Location: login.php');
}



?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />



<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


</style>


   <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">

                    <a href="?add=1" class="btn btn-primary btn-lg">Criar uma feature</a>


                    <?php
                    
                    if($_GET['add'] == "1")
{
  ?>
  <h2>Estamos prontos para ouvir o seu ponto de vista, <?php echo $nome; ?> </h2>


  <form method="post" action="?add=2">



                                    <table class="login-box">
                                        
                                    


                                    <tr>
                                            <td style="padding: 12px 0 0 2px;">
Qual o nome do seu feature?                                               
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            
                                                <input tabindex="2" type="text" size="100px"  style="width:480px;"  class="input is-large" name="titulo"   maxlength="60"> 

                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
Diga-nos mais sobre a sua feature, seja o mais especifico possivel para que possamos entender a sua ideia                                             
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            
                                                <input tabindex="2" type="text" size="100px"  style="width:480px;"  class="input is-large" name="sobre"   maxlength="250"> 

                                            </td>
                                        </tr>
                                       
                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
que categoria a sua feature melhor se encaixa?                                          
                                            </td>
                                        </tr>
                                       

                                     <tr>
                                     <td>

                                     <select id="ordenacao" name="categoria">
                                    <option value="1">é uma sugestão</option>
                                    <option value="2">é uma reclamação</option>
                                    <option value="3">é um elogio</option>
                                    </select>


                                     </tr>
                                     </td>


                                        <tr>
                                        </tr>
<br><br>

                                        <tr>

                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>



  <?php
exit();
}


if($_GET['add'] == "2")
{
$titulo = $_POST['titulo'];
$sobre = $_POST['sobre'];
$categoria = $_POST['categoria'];

$titulo = antipalavroes($titulo, "1");
$sobre = antipalavroes($sobre, "1");
$titulo = sqlinjection($titulo);
$sobre = sqlinjection($sobre);
if($categoria == 1 || $categoria == 3 || $categoria == 3)
{
    $categoria = $_POST['categoria'];
}

echo $titulo . "<BR>";
echo $sobre . "<BR>";
echo $categoria . "<BR>";


$sql = "INSERT INTO `features` (`id`, `userid`, `nome`, `sobre`, `categoria`, `solucionado`, `data`, `resposta`) VALUES (NULL, '$id', '$titulo', '$sobre', '$categoria', '0', CURRENT_TIMESTAMP, '');";
$result = $conn->query($sql);

?>
<head>
<meta http-equiv="refresh" content=0;url="?criado=1">
</head>
<?php
exit();
}



if($_GET['criado'] == "1")
{
    ?><br><center>
    <img src="imagens/ok.webp" width="100">
<h1 style="font-size: 25px; color: black;">Pronto! </h1>
<h2 style="font-size: 19px; color: black;">A sua feature já foi registrada e será analisada em breve, obrigado por ajudar-nos a melhorar nosso serviço!</h2>
<br><br><br>
<a href="../features.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar a pagina de features</a><br><br>
    <?php
    exit();
}

                    if($_GET['id'] >= "1")
{
  $sql = "SELECT * FROM `features` WHERE `id` = " . $_GET['id'];
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
      // output data of each row
      while($row = $result->fetch_assoc()) {
          $nome = $row["nome"];
          $id = $row["id"];
          $status = $row["solucionado"];
          $sobre = $row["sobre"];
          $resposta = $row["resposta"];
     echo "<h2> $nome </h2>";
     echo "<h3> $sobre </h3>";
     if($status == "0")
     {
       echo '<h4>Esta feature ainda não foi visualizada pela Data Web e sera analisada em breve... </h4>';
     }

     if($status == "1")
     {
       echo '<h4 style="color:green;">Esta feature foi aceita pela Data Web e será implantada em breve, obrigado! </h4>';
       echo "<br>Respondemos: <h4> $resposta </h4>";
     }

     if($status == "2")
     {
       echo '<h4 style="color:red;">Esta feature não foi aceita pela Data Web, veja o porque: </h4>';
       echo "<br>Respondemos: <h4> $resposta </h4>";
     }

        }
    }

    ?>
            <br><br><br>
<a href="../features.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar a pagina de features</a><br><br>
    <?php
exit();
}
                    
                    ?>
                    <h2>Queremos saber a sua opinião! </h2>
                    <h3>A Data Web não existiria se não fosse por seus clientes! é por isso que valorizamos a opinião de cada um, suas dicas, elogios e criticas são sempre bem-vindas na Data Web. </h3>


<div class="panel panel-default">
                        <div class="panel-heading">
                        Features dos usuarios
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <div id="dataTables-example_wrapper" class="dataTables_wrapper form-inline" role="grid"><div class="row"><div class="col-sm-6"><div class="dataTables_length" id="dataTables-example_length"><label></label></div></div><div class="col-sm-6"><div id="dataTables-example_filter" class="dataTables_filter"></div></div></div><table class="table table-striped table-bordered table-hover dataTable no-footer" id="dataTables-example" aria-describedby="dataTables-example_info">
                                    <thead>
                                        <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column ascending" style="width: 161px;">Abrir</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" style="width: 235px;">Feature</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending" style="width: 218px;">//</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending" style="width: 137px;">Status</th></tr>
                                    </thead>
                                    <tbody>




<?php

$sql = "SELECT * FROM `features` ORDER BY `data` DESC LIMIT 60";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $nome = $row["nome"];
        $id = $row["id"];
        $status = $row["solucionado"];
?>
<tr class="gradeA odd">
                                            <td class="sorting_1"><a href="?id=<?php echo $id; ?>"> Abrir </a></td>
                                            <td class=" "><?php echo $nome; ?></td>
                                            <td class=" ">////</td>
<?php


if($status == 0)
{
    ?>
<td><label class="label label-danger">Em analise...</label></td>
<?php
}
if($status == 2)
{
    ?>
<td><label class="label label-danger">Não aceito.</label></td>
<?php
}
if($status == 1)
{
    ?>
<td><label class="label label-success">Aceito</label></td>
<?php
}


    }
}

?>


</tbody>
                                </table><div class="row"><div class="col-sm-6"></div><div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate"></div></div></div></div>
                            </div>
                            
                        </div>
                    </div>


<br>
<p>Painel de administração exclusivo Data Web, Versão BETA 1.0 </p>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
