﻿<?php
    header('Location: ../faturas');
