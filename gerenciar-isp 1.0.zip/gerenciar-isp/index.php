<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE); 
if($_SESSION['login'] == 1)
{
    header('Location: painel.php');

}
else
{
    header('Location: login.php');
}
