<?php
require '../sistema/db.php'; 

    $sql = "SELECT * FROM `usuarios` LIMIT 1";
    $result = $conn->query($sql);
if ($result->num_rows > 0) {

?>
    {"funcionando": "1"}
    <?Php
}else{
    ?>
    {"funcionando": "0"}
    <?Php
}
?>

