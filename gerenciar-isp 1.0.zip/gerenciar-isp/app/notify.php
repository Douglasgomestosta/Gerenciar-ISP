<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE); 
require '../sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
}else{
    echo "0";
}
$data = date("Y-m");
    $sql = "SELECT * FROM `notificacoes` WHERE `idusuario` = " . $id . " AND `exibido` = 0 AND `data` LIKE '%" . $data . "%'";

    $result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        ?><head>
        <meta charset="utf-8"/>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        </head>
        <body onload='Android.notificacao(<?php echo $row["id"]; ?>, "<?php echo $row["texto"]; ?>", "<?php echo $row["conteudo"]; ?>")'>
        
        <?php
$idnotify = $row["id"];

    }

}

$sqll = "UPDATE `notificacoes` SET `exibido` = '1' WHERE `notificacoes`.`id` = " . $idnotify . ";";
$result = $conn->query($sqll);
$conn->close();
      

?>

