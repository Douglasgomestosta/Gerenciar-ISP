<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE); 
require '../sistema/db.php'; 
$data = date("Y-m");
if (!is_numeric($_POST['id'])) {
exit();
}
$id = $_POST['id'];
$cpf = $_POST['cpf'];
if(empty($id)){
exit();
}
if(empty($cpf)){
    exit();
    }
    if($_POST['token'] == "suruba-de-anões"){}else
    {
exit();
    }
    $sql = "SELECT * FROM `notificacoes` WHERE `idusuario` = " . $id . " AND `exibido` = 0 AND `data` LIKE '%" . $data . "%' LIMIT 1";

    $result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        if(empty($row["url"])){
        $row["url"] = "http://painel.datawebtelecom.site";
        }
        ?>
        {"notificacao": "1", "texto": "<?php echo $row["texto"]; ?>", "conteudo": "<?php echo $row["conteudo"]; ?>", "url": "<?php echo $row["url"]; ?>", "id": <?php echo $row["id"]; ?>}
        <?php
        $idnotify = $row["id"];
    }

}else{
    ?>
    {"notificacao": "0", "texto": " ", "conteudo": " ", "url": " ", "id": 0}
    <?Php
}

$sqll = "UPDATE `notificacoes` SET `exibido` = '1' WHERE `notificacoes`.`id` = " . $idnotify . ";";
$result = $conn->query($sqll);
$conn->close();
      

?>

