<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE); 
require '../sistema/db.php'; 

$id = $_POST['id'];
    $senha = $_POST['senha'];
    $senha = md5($senha);
    if (!is_numeric($id)) {
        ?>
        <head>
    <title>0</title>
    </head>
    
        <?php
        exit();
        }

        if (empty($id)) {
            ?>
            <head>
        <title>0</title>
        </head>
        
            <?php
            exit();
            }



    $sql = "SELECT * FROM `usuarios` WHERE `id` LIKE '" . $id . "' AND `senha` LIKE '" . $senha . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        if ($senha == $row["senha"])
        {
          $_SESSION['login'] = "1";
          $_SESSION['email'] = $email;
          $_SESSION['senha'] = $senha;
          $_SESSION['id'] = $row["id"];
          $_SESSION['usuariocomum'] = "1";
          $_SESSION['nome_completo'] = $row["nome"];
          //salva o log de login
          $id = $row["id"];
          $ip = $_SERVER['HTTP_CLIENT_IP'];
          $navegador = $_SERVER['HTTP_USER_AGENT'];
          $sql = "INSERT INTO `autenticacoes` (`id`, `idcliente`, `data`, `navegador`, `ip`) VALUES (NULL, '" . $id . "', CURRENT_TIMESTAMP, '" . $navegador . "', '" . $ip . "');";
$resultt = $conn->query($sql);

echo "1";
?>
    <head>
<title>1</title>
</head>
<body onload='Android.logindados(<?php echo $row["id"]; ?>)'>

    <?php



        }else
        {
            echo "0";
            ?>
    <head>
<title>0</title>
</head>
    <?php
        }
    }
} else {
    echo "0";
    ?>
    <head>
<title>0</title>
</head>
    <?php
}
$conn->close();
      

?>

