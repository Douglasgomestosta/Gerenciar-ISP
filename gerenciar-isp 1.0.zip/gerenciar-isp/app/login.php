<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE); 
require '../sistema/db.php'; 

$id = $_POST['id'];
    $senha = $_POST['senha'];
    $senha = md5($senha);
    if (!is_numeric($id)) {
        ?>
{"sucesso": "0", "nome": "", "id":"0"}
        <?php
        exit();
        }

        if (empty($id)) {
            ?>
{"sucesso": "0", "nome": "", "id":"0"}
            <?php
            exit();
            }



            $sql = "SELECT * FROM `usuarios` WHERE `id` LIKE '" . $id . "' AND `senha` LIKE '" . $senha . "'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    if ($senha == $row["senha"])
                    {
                      $_SESSION['login'] = "1";
                      $_SESSION['email'] = $email;
                      $_SESSION['senha'] = $senha;
                      $_SESSION['id'] = $row["id"];
                      $_SESSION['usuariocomum'] = "1";
                      $_SESSION['nome_completo'] = $row["nome"];
                      //salva o log de login
                      $id = $row["id"];
                      $ip = $_SERVER['HTTP_CLIENT_IP'];
                      $navegador = $_SERVER['HTTP_USER_AGENT'];
                      $sql = "INSERT INTO `autenticacoes` (`id`, `idcliente`, `data`, `navegador`, `ip`) VALUES (NULL, '" . $id . "', CURRENT_TIMESTAMP, '" . $navegador . "', '" . $ip . "');";
            $resultt = $conn->query($sql);
            
            $token = rand(1000, 9999999);
            $rand = rand(1,5);
             if($rand == "1"){$token = $token . "a";}
              if($rand == "2"){$token = $token . "b";}
            if($rand == "3"){$token = $token . "c";}
            if($rand == "4"){$token = $token . "d";}
             if($rand == "5"){$token = $token . "e";}
             if($rand == "6"){$token = $token . "r";}
             if($rand == "7"){$token = $token . "k";}
             if($rand == "8"){$token = $token . "z";}
             if($rand == "9"){$token = $token . "m";}
             if($rand == "10"){$token = $token . "q";}
             $token = $token . rand(1,5000);
            $sql = "INSERT INTO `autologin` (`id`, `token`, `idcliente`, `validade`) VALUES (NULL, '" . $token . "', '" . $id . "', NULL);";
            $resultt = $conn->query($sql);

            ?>
            {"sucesso": "1", "nome": "<?php echo $row["nome"]; ?>", "id":"<?php echo $row["id"]; ?>", "cpf":"<?php echo $row["cpf"]; ?>", "token":"<?php echo $token; ?>"}
                <?php
            
            
            
                    }else
                    {
                        ?>
            {"sucesso": "0", "nome": "", "id":"0"}
                        
                <?php
                    }
                }
            } else {
                ?>
            {"sucesso": "0", "nome": "", "id":"0"}
                <?php
            }
            $conn->close();
                  
            
            ?>

