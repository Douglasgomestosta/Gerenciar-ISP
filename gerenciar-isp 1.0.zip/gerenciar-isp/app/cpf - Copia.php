<?php
require '../sistema/db.php'; 
if (!is_numeric($_GET['cpf'])) {
    exit();
    }
    $cpf = $_GET['cpf'];
    if(empty($cpf)){
    exit();
    }
    $sql = "SELECT * FROM `usuarios` WHERE `cpf` LIKE '" . $cpf . "'";

    $result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $nome = explode(" ",$row["nome"]);
        ?>
        {"sucesso": "1", "nome": "<?php echo $nome[0]; ?>", "id": "<?php echo $row["id"]; ?>"}
        <?php
    }

}else{
    ?>
    {"sucesso": "0", "nome": " ", "id":"0"}
    <?Php
}
?>

