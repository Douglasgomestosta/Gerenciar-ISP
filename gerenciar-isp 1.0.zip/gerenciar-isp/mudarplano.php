﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
            $senha = $row["senha"];
            $cpf = $row["cpf"];
            $cep = $row["cep"];
            $caixa = $row["caixa"];
            $asaasid = $row["asaasid"];
            $asaasassinaturaid = $row["asaasassinaturaid"];
        }
    }


    $sql = "SELECT * FROM `caixas` WHERE `id` LIKE '" . $caixa . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $velocidadecaixa = $row["Tamanho"];
        }
    }
    $velocidadecaixa = $velocidadecaixa - 50;

    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
        }
    }


    $sql = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $capacidade = $row["capacidade"];

        }
    }


    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
            $senhapppoe = $row["senha"];
            $ip = $row["ip"];
            $roteador = $row["roteador"];
            $mac = $row["mac"];
            $ativopppoe = $row["ativo"];
            $servidor = $row["servidor"];

        }
    }


}
else
{
    header('Location: login.php?redirect=mudarplano.php');
}



?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


</style>



<script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>



</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php


if($_GET['atualizado'] == "1")
{
    ?>
    <center> <img src="imagens/ok.webp" width="100">
<h1 style="font-size: 25px; color: black;">Pronto! </h1>
<h3>Seu plano de internet foi alterado com exito e você já está recebendo a sua nova velocidade de internet!</h3>
<h5>Caso sua velocidade de entrega não esteja sendo entregue ainda, por favor experimente reiniciar seu roteador wifi </h5>
<br>
<h6>Você pode fazer testes de velocidade pelas próximas 24 horas para ver se a velocidade pode ser alcançada, caso sua infraestrutura não suporte a sua nova velocidade, entre em contato conosco para fazer a sua atualização </h6>
<br>
            <a href="painel.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar ao inicio</a><br><br>
    
    <?php
    exit();
}


$mes = date("m");
$ano = date("Y");
$datasemdia = "/" . $mes . "/" . $ano;
$sql = "SELECT * FROM `trocardeplanos` WHERE `usuarioid` = " . $id . " AND `data` LIKE '%" . $datasemdia . "%'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            ?>
            <center>
            <h2 style="color:red;">Troca de plano indisponivel</h2>
<h3>Você não pode trocar de plano nesse momento, pois já trocou o seu plano de internet nos últimos 2 meses, por favor espere 2 meses desde a ultima troca de plano para atualizar seu plano de internet novamente.</h3>
            <h4>Vocẽ trocou seu plano de internet no dia: <?php echo $row["data"]; ?></h4>
            <br>
            <a href="painel.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar ao inicio</a><br><br>

  <br>

  <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Precisando de ajuda?
                        </div>        
                                      
                                    <div class="panel-body"> 

<h3>Se você está precisando de alguma ajuda sobre o seu plano, você pode abrir um pedido de suporte na categoria "outros" </h3>

<center> <a href="/suporte/outrosassuntos.php" class="btn btn-primary btn-lg">Criar um novo pedido de suporte.</a></center>

                                       <div style="margin-top: 10px;">
											
														
									

                                        </div>
                                    </div>
                    </div>
                    </div>

            <?php
            exit();

        }
    }





    $mes = date("m") - 1;
    $mes = "0" . $mes;
$ano = date("Y");
if($mes == "0"){$mes = "12"; $ano = $ano -1;}
$datasemdia = "/" . $mes . "/" . $ano;
$sql = "SELECT * FROM `trocardeplanos` WHERE `usuarioid` = " . $id . " AND `data` LIKE '%" . $datasemdia . "%'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            ?>
            <center>
            <h2 style="color:red;">Troca de plano indisponivel</h2>
<h3>Você não pode trocar de plano nesse momento, pois já trocou o seu plano de internet nos últimos 2 meses, por favor espere 2 meses desde a ultima troca de plano para atualizar seu plano de internet novamente.</h3>
            <h4>Vocẽ trocou seu plano de internet no dia: <?php echo $row["data"]; ?></h4>
            <br>
            <a href="painel.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar ao inicio</a><br><br>


<br>

<div class="">
                    <div class="panel panel-default">
                      <div class="panel-heading">
                          Precisando de ajuda?
                      </div>        
                                    
                                  <div class="panel-body"> 

<h3>Se você está precisando de alguma ajuda sobre o seu plano, você pode abrir um pedido de suporte na categoria "outros" </h3>

<center> <a href="/suporte/outrosassuntos.php" class="btn btn-primary btn-lg">Criar um novo pedido de suporte.</a></center>

                                     <div style="margin-top: 10px;">
                                          
                                                      
                                  

                                      </div>
                                  </div>
                  </div>
                  </div>
            <?php
            exit();

        }
    }


///Pagamentos

$sql = "SELECT * FROM `pagamentos` WHERE `idusuario` = " . $id . " ORDER BY `id` DESC LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        if($row['pago'] == "1")
        {}else{
            $atrasadas = "1";
        }
    }
}else{
    $novocliente = "1";
}



if($atrasadas == 1){
    ?> <center>
    <h2 style="color:red;">Faturas pendentes </h2>
    <h3>A sua última fatura ainda está pendente! Pague sua fatura atual para fazer a atualização do seu plano de internet.</h3>
     <br> <a href="/faturas" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Ver Faturas</a>
  <a href="painel.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar ao inicio</a><br><br>
    </center>



    <br>

<div class="">
                    <div class="panel panel-default">
                      <div class="panel-heading">
                          Precisando de ajuda?
                      </div>        
                                    
                                  <div class="panel-body"> 

<h3>Se você está precisando de alguma ajuda sobre o seu plano, você pode abrir um pedido de suporte na categoria "outros" </h3>

<center> <a href="/suporte/outrosassuntos.php" class="btn btn-primary btn-lg">Criar um novo pedido de suporte.</a></center>

                                     <div style="margin-top: 10px;">
                                          
                                                      
                                  

                                      </div>
                                  </div>
                  </div>
                  </div>
    <?php
exit();
}




if($novocliente == 1){
    ?> <center>
    <h2 style="color:red;">Você ainda não pode atualizar seu plano de internet</h2>
    <h3>Você ainda não tem nenhuma fatura de internet, antes de atualizar seu plano de internet por favor pague pelo menos 1 mês de serviço no seu plano de internet atual.</h3>
     <br> <a href="/faturas" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Ver Faturas</a>
  <a href="painel.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar ao inicio</a><br><br>
    </center>




    <br>

<div class="">
                    <div class="panel panel-default">
                      <div class="panel-heading">
                          Precisando de ajuda?
                      </div>        
                                    
                                  <div class="panel-body"> 

<h3>Se você está precisando de alguma ajuda sobre o seu plano, você pode abrir um pedido de suporte na categoria "outros" </h3>

<center> <a href="/suporte/outrosassuntos.php" class="btn btn-primary btn-lg">Criar um novo pedido de suporte.</a></center>

                                     <div style="margin-top: 10px;">
                                          
                                                      
                                  

                                      </div>
                                  </div>
                  </div>
                  </div>
    <?php
exit();
}


if($_GET['parte'] == "2")
{

    if (!is_numeric($_POST['plano'])) {
        echo "Caracteres invalidos no campo 'plano'";
        exit();
    }
    $senhadados = $_POST['senha'];
    $motivo = $_POST['motivo'];


    $data = date('d/m/Y');
$novoplano = $_POST['plano'];

$sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $_POST['plano'] . "' AND visivel = 1;";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
            $velocidade = $row["velocidade"];
            $planoencontrado = "1";
        }
    }
    if($planoencontrado == "0")
    {
        echo "Plano não encontrado no sistema!";
        exit();
    }




$sql = "INSERT INTO `trocardeplanos` (`id`, `usuarioid`, `planoanterior`, `novoplano`, `data`) VALUES (NULL, '" . $id . "', '" . $plano . "', '" . $novoplano . "', '" . $data . "');";
$result = $conn->query($sql);








$sql = "UPDATE `usuarios` SET `plano` = '" . $novoplano . "' WHERE `usuarios`.`id` = " . $id . ";";
$result = $conn->query($sql);


$sql = "UPDATE `pppoe` SET `plano` = '" . $novoplano . "' WHERE `pppoe`.`idcliente` = " . $id . ";";
$result = $conn->query($sql);

//atualizar velocidade no firewall
$sql = "SELECT * FROM `servidores` WHERE `id` =" . $servidor;
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $ipservidor = $row['ippublico'];
        $secret = $row["secret"];
    }
}
$sql = "SELECT * FROM `planos` WHERE `id` = '" . $novoplano . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $velocidade = $row['velocidade'];
        $velocidade = $velocidade . "000/" . $velocidade . "000";
    }
}
shell_exec('echo "User-Name=' . $usuariopppoe . ',Filter-Id=' . $velocidade .  '" | radclient ' . $ipservidor . ':3799 coa ' . $secret);
//fim atualizar velocidade no firewall



header('Location: ?atualizado=1');
?>
<head>
<meta http-equiv="refresh" content="0; URL='?atualizado=1'"/>

</head>
<?php
exit();
}


if($_GET['parte'] == "1")
{
    if (!is_numeric($_GET['plano'])) {
        echo "Caracteres invalidos no campo 'plano'";
        exit();
    }
    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $_GET['plano'] . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
            $velocidade = $row["velocidade"];

            ?>
<div class="">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        <?php echo $row["nome"]; ?>
                        </div>        
                                      
                                    <div class="panel-body"> 

<?php
                                    if($_GET['error'] == "1")
{
echo '<h4 style="color:red;">CPF invalido, por favor tente novamente ou entre em contato com o nosso suporte ao cliente. </h4>';
}
?>

                    <h3>Aqui estão as informações de seu novo plano de internet.</h3>

                    <H4>Upload: até <?php echo $velocidade; ?> Megas</h4>
<H4>Download: até <?php echo $velocidade; ?> Megas</h4>
                    
                    <h5>Lembre-se que é possivel que seu roteador ou infraestrutura não suporte a velocidade maxima suportada, experimente por 1 dia e caso não receba a sua nova velocidade entre em contato conosco. </h5>

                   
                    <H3>Preço: <a style="color:green;">R$<?php echo $preco; ?>,00</a> </h3>
<center
<br>
<h3>Você deseja atualizar para o seu novo plano?</h3>
                    <form method="POST" action="/mudarplano.php?parte=2">
<input type="hidden" name="parte" value="2">
<input type="hidden" name="plano" value="<?php echo $_GET['plano']; ?>">
                                    <table class="login-box">
                                        
                                      


                                        
                                     
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Sim!" class="button is-block is-link is-large is-fullwidth" style="width: 200%;">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
</center>

                </div>
            </div>
                          </div>
            <?php
        }
    }

?> 








<?php
    exit();
}
?>
<h3>Chegou a hora de escolhemos um novo plano de internet para você.</h3>
<center><h4>Quais destes planos você mais gostou? </h4> </center>
<?php
 $sql = "SELECT * FROM `planos` WHERE `tecnologia` LIKE 'utp' AND `visivel` = 1";
 $result = $conn->query($sql);
 if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         $preco = $row["preco"];
         $velocidade = $row["velocidade"];

         ?>
<div class="col-md-4 col-sm-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <?php echo $row["nome"]; ?>
                        </div>
                        <div class="panel-body">
                            <p><?php echo $row["descricao"]; ?></p>
                        </div>
                        <div class="panel-footer">
                        <?php
 if($plano == $row["id"])
 {
     ?>
     <center> <h4>Seu plano atual</h4></center>
     <?php
 }else{
 ?>
                        <a href="?parte=1&plano=<?php echo $row["id"]; ?>" class="btn btn-success btn-lg">Quero esse plano.</a>
                        <?php
     }
                        ?>
                        </div>
                    </div>
                </div>

         <?php
     }
 }
?>


                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->

    
   
</body>
</html>
