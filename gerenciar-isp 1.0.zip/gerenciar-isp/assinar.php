<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
$sql = "SELECT * FROM `configs`";
$result = $conn->query($sql);
$disponivel = "0";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        if($row["novasadesao"] == "0")
        {
            $novasadesao = 0;
        }else
        {
            $novasadesao = 1;
        }
    }
}


if (!is_numeric($_GET['plano'])) {
    echo "Utilize somente numeros no campo plano";
    exit();
}


    $plano = "1";
    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $_GET['plano'] . "'";
$result = $conn->query($sql);
$disponivel = "0";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $nome = $row["nome"];
        $velocidade = $row["velocidade"];
        $velocidademinima = $row["velocidademinima"];
        $preco = $row["preco"];
        $tecnologia = $row["tecnologia"];
    }
}else
{
    header('Location: http://datawebtelecom.site/internet-residencial/');
    exit();
}



?>
<!DOCTYPE html>
<html>
    
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bem Vindo a Data Web</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="css/bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css">
    <script src="https://apis.google.com/js/platform.js" async defer></script>
		<meta name="google-signin-client_id" content="445439223398-q0va4v6j61oc8q5k3fllabbnj6quib83.apps.googleusercontent.com">



<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>


</head>

<body>
    <section class="hero is-success is-fullheight">
        <div class="hero-body">
            <div class="container has-text-centered">
                <div class="column is-4 is-offset-4">
                    
<!--- <img class="default" alt="" src="https://i.imgur.com/y1XNdSJ.png"> !--->
<img src="https://i.imgur.com/jEBZ0LZ.png" height="220" width="220">


                    
                    <div class="box">
                       

<?php
if($_GET['pronto'] == "1")
{
?>
<center>
<img src="imagens/ok.webp" width="100">
<h1 style="font-size: 25px; color: black;">Pronto! </h1>
<h2 style="font-size: 19px;">Sua assinatura já está feita, e em até 2 dias uteis estaremos em sua casa para fazer a instação da sua Ultrainternet ;) </h2>
<h2 style="font-size: 17px;">Você pode ver o status da sua adesão <a href="statusadesao.php?id=<?php echo $_GET['id']?>">clicando aqui </a></h2>
<h4 style="font-size: 10px;">A Data Web tem o direito de cancelar sua adesão em caso de inviabilidade, neste casso você recebera uma mensagem em seu whatsapp e e-mail avisando sobre o ocorrido </h4>

<?php
exit();
}
if($novasadesao == 0)
{
?>
<img src="imagens/false.png" width="100">
<h1 style="font-size: 25px; color: black;">Adesão indisponivel</h1>
<h2 style="font-size: 19px;">Infelizmente a Data Web não está aceitando novas adesões nesse momento ;\ você pode voltar mais tarde?</h2>

<?php
    exit();
}
if(empty($_POST['parte']))
{
    ?>
    <h2 style="font-size: 20px;">Olá! bem vindo ao assistente de adesão da Data Web </h2>
    <H3>Agora, vamos começar a preencher seus dados para que possamos iniciar sua assinatura em nosso serviço? não se preocupe, não leva mais que 5 minutos :)</h3>
    <form method="post" method="get" action="?plano=<?php echo $plano;?>">
<input type="hidden" name="parte" value="9000">
                                   
                                        
                                       
                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>

    <?php
}

if($_POST['parte'] == "9000")
{
?>


                   <h3 style="font-size: 20px;"> Onde você mora? </h3>
                   <h4>Vamos verificar se sua rua já tem nosso serviço disponivel</h4>

                   


<form method="post" method="get" action="?plano=<?php echo $plano;?>">
<input type="hidden" name="parte" value="1">
                                    <table class="login-box">
                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                                Cep
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="1" type="text" size="20px" style="width:240px;" name="cep" class="input is-large" required="" placeholder="ex: 23822-150">
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
                                                Numero da casa
                                               
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="2" type="text" size="20px"  style="width:240px;"  class="input is-large" name="numero" required="" placeholder="ex: 8">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>



                               

                                		
<?php
}
//erro esta abaixo


if($_POST['parte'] == "1")
{
$cep = trim($_POST['cep']);
if (strpos($cep, 'AND') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, ';') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, "'") !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, '"') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}

if (strpos($cep, '-') == false) {
$cep = substr_replace($cep, '-', -3, 0);
}

if (!is_numeric($_POST['numero'])) {
    echo "Utilize somente numeros no campo numero da casa";
    exit();
}
$sql = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "' AND `disponivel` LIKE '1'";
$result = $conn->query($sql);
$disponivel = "0";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    $disponivel = "1";
    $rua = $row["rua"];
    }
}
$sql = "SELECT * FROM `caixas` WHERE `cep` LIKE '" . $cep . "' AND `tecnologia` LIKE '" . $tecnologia . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    if ($tecnologia == $row["tecnologia"])
    {
        $disponivel = "1";
    }else
    {
    $disponivel = "0";
    }
}
    
}else
{
    $disponivel = "0";
}



    if($disponivel == "1")
    {
        ?>
        <h2 style="font-size: 20px;">A <?php echo $rua; ?> já tem o melhor serviço de internet!</h2>
<h4>Agora vamos ver sobre seu plano de internet, equipamentos e instalação? </h4>


        
<form method="post" method="get" action="?plano=<?php echo $plano;?>">
<input type="hidden" name="parte" value="2">
<input type="hidden" name="cep" value="<?php echo $cep; ?>">
<input type="hidden" name="numero" value="<?php echo $_POST['numero']; ?>">
                                   
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
        <?php
    }
    if($disponivel == "0")
    {

        $sql = "SELECT * FROM `caixas` WHERE `cep` LIKE '" . $cep . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
   $tecnologia = $row["tecnologia"];
if($tecnologia == "fibra")
{
    ?>
    <h2  style="font-size: 20px;">Outra tecnologia disponivel em sua rua</h2>
    <h3>Infelizmente a tecnologia escolhida por você não está disponivel, porém a tecnologia de Fibra optica está disponivel, por favor escolha os planos de Fibra optica que se adapta as suas necessidades </h3>
   <form action="http://datawebtelecom.site/internet-fibra-optica/"> 
   <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
   </form>
    <?php
}

if($tecnologia == "utp")
{
    ?>
    <h2  style="font-size: 20px;">Outra tecnologia disponivel em sua rua</h2>
    <h3>Infelizmente a tecnologia escolhida por você não está disponivel, porém a tecnologia de cabo metalico está disponivel, por favor escolha os planos de internet via cabo metalico que se adapta as suas necessidades </h3>
   <form action="http://datawebtelecom.site/internet-utp/"> 
   <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
   </form>
    <?php
}


if($tecnologia == "radio")
{
    ?>
    <h2  style="font-size: 20px;">Outra tecnologia disponivel em sua rua</h2>
    <h3>Infelizmente a tecnologia escolhida por você não está disponivel, porém a tecnologia de internet via rádio está disponivel, por favor escolha os planos de internet via rádio que se adapta as suas necessidades </h3>
   <form action="http://datawebtelecom.site/internet-via-radio/"> 
   <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
   </form>
    <?php
}

    
}
}else{
        ?>
        <h2 style="font-size: 20px;" >Poxa... sua rua ainda não tem nosso serviço</h2>
        <h3>Infelizmente não podemos atender você</h3>
       
        <?php
}    
}
?>


                

                   





                               

                                		
<?php
}
//erro está mais abaixo

if($_POST['parte'] == "2")
{
    ?>
    
    <h1 style="font-size: 20px;"> Agora vamos escolher o seu roteador </h1>
    <h2>Não se preocupe, a instalação é de graça! você só paga pelo seu roteador </h2> 
    <form method="post" method="get" action="?plano=<?php echo $plano;?>">
    <input type="hidden" name="parte" value="3">
<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
<input type="hidden" name="numero" value="<?php echo $_POST['numero']; ?>">
                                    <table class="login-box">
                                        
                                    <select id="ordenacao" name="roteador">
                                    <option value="4">Wifi Premium(R$300,00)</option>
                                    <option value="3">WifiPro(R$90,00)</option>
                                    <option value="2">Economic Wifi(R$60,00)</option>
                                    <option value="1">Já tenho um roteador(R$0,00)</option>
                                                                        </select>
<br>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
    <?php
}
if($_POST['parte'] == "3")
{
    $roteador = "666";
    if($_POST['roteador'] == "1") {$roteador = "0";}
    if($_POST['roteador'] == "2") {$roteador = "60";}
    if($_POST['roteador'] == "3") {$roteador = "90";}
    if($_POST['roteador'] == "4") {$roteador = "300";}
    if($roteador == "666") {exit();}
    $instalacao = $roteador;
?>
<h3  style="font-size: 20px;">Ótima escolha!</h3>
<h4>O pagamento do roteador de R$<?php echo $instalacao; ?> deve ser entregue ao tecnico responsavel no dia da instalação, pagando a vista ou cartão de credito em até 3x</h4>
<form method="post" method="get" action="?plano=<?php echo $plano;?>">
    <input type="hidden" name="parte" value="4">
<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
<input type="hidden" name="numero" value="<?php echo $_POST['numero']; ?>">
<input type="hidden" name="roteador" value="<?php echo $_POST['roteador']; ?>">
                                    <table class="login-box">
                                    <!----
                                    <select id="ordenacao" name="pagamento">
                                    <option value="0">Boleto bancario mensal(R$<?php echo $preco; ?>)</option>
                                    <option value="1">Cartão de credito mensal(R$<?php echo $preco; ?>)</option>
                                    </select> --->
<br>
<center>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
<?php
}
if($_POST['parte'] == "4")
{
    $_POST['pagamento'] = "0";
?>
<h3  style="font-size: 20px;" >Chegou a hora de conhecer você </h3>
<form method="post" method="get" action="?plano=<?php echo $plano;?>">
<input type="hidden" name="parte" value="5">
<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
<input type="hidden" name="numero" value="<?php echo $_POST['numero']; ?>">
<input type="hidden" name="roteador" value="<?php echo $_POST['roteador']; ?>">
<input type="hidden" name="pagamento" value="<?php echo $_POST['pagamento']; ?>">

                                    <table class="login-box">
                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                                Seu nome completo
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="1" type="text" size="20px" style="width:240px;" name="nome" class="input is-large" required="" placeholder="ex: Douglas Gomes Tosta">
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
                                                E-mail
                                               
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="2" type="text" size="20px"  style="width:240px;"  class="input is-large" name="email" required="" placeholder="ex: seunome@gmail.com">
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
                                                Whatsapp
                                               
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="2" type="text" size="20px"  style="width:240px;"  class="input is-large" name="whatsapp" required="" placeholder="ex: 21 96658-9046">
                                            </td>
                                        </tr>







                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
                                                CPF
                                               
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="2" type="text" size="20px"  style="width:240px;"  class="input is-large" name="cpf" required="" placeholder="ex: 000.000.000-00">
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
                                                Detalhes da sua casa para identificação
                                               
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="2" type="text" size="20px"  style="width:240px;"  class="input is-large" name="sobreacasa" required="" placeholder="ex: Casa amarela">
                                            </td>
                                        </tr>



                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
                                                Senha para uso no seu painel
                                               
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="2" type="text" size="20px"  style="width:240px;"  class="input is-large" name="senha" required="" placeholder="ex: 437238dh4">
                                            </td>
                                        </tr>






                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>

<?php
}
if($_POST['parte'] == "5")
{
if(strlen($_POST['nome']) < 4) {echo "Por favor, digite seu nome completo no campo Nome Completo";exit();}
$_POST['email'] = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {}else{echo("Você não digitou um email valido"); exit();}
$_POST['whatsapp'] = trim($_POST['whatsapp']);
if (!is_numeric($_POST['whatsapp'])) {echo "Utilize somente numeros no campo Whatsapp"; exit();}
if (!is_numeric($_POST['whatsapp'])) {echo "Utilize somente numeros no campo Whatsapp"; exit();}
if(strlen($_POST['cpf']) == 14) {} else { echo "Digite o seu CPF completo";exit();}
if(strlen($_POST['senha']) < 6) { echo "Sua senha precisa de pelo menos 6 caracteres";exit();}
if($_POST['senha'] == "123456") {echo "Sua senha está facil demais, lembre-se que você podera ser hackeado se usar uma senha muito facil."; exit(); }
if($_POST['senha'] == "1234567") {echo "Sua senha está facil demais, lembre-se que você podera ser hackeado se usar uma senha muito facil."; exit(); }
$roteador = "666";
if($_POST['roteador'] == "1") {$roteador = "0";}
if($_POST['roteador'] == "2") {$roteador = "60";}
if($_POST['roteador'] == "3") {$roteador = "90";}
if($_POST['roteador'] == "4") {$roteador = "300";}
if($roteador == "666") {exit();}
$pagamento = "666";
if($_POST['pagamento'] == "0") {$pagamento = "0";}
if($_POST['pagamento'] == "1") {$pagamento = "1";}
if($pagamento == "666") {exit();}

?>
<h3 style="font-size: 20px;">Já temos tudo em mãos, agora precisamos que você revise tudo com cuidado </h3>
<h4>Caso esteja tudo certo, aperte em "Assinar" para fazer o pedido de adesão </h4><br>
<h6>Cep <?php echo $_POST['cep']; ?> Numero <?php echo $_POST['numero']; ?></h6>
<h6><?php echo $velocidade; ?> Megas Upload e Download </h6>
<h6>nome: <?php echo $_POST['nome']; ?> </h6>
<h6>E-mail: <?php echo $_POST['email']; ?> </h6>
<h6>Whatsapp: <?php echo $_POST['whatsapp']; ?> </h6>
<h6>CPF: <?php echo $_POST['cpf']; ?> </h6>
<h6>Detalhes da casa: <?php echo $_POST['sobreacasa']; ?> </h6>
<h6>Senha escolhida: <?php echo $_POST['senha']; ?> </h6>
<?php
$instalacao = 20 + $roteador;
?>
<h6> Roteador: R$<?php echo $instalacao; ?>,00 </h6>
<?php
if($_POST['pagamento'] == "0") { $pagamento = "Boleto bancario";}
if($_POST['pagamento'] == "1") { $pagamento = "Cartão de credito mensal";}
?>
<h6>Assinatura mensal de R$<?php echo $preco; ?> pago via <?php echo $pagamento; ?> com primeiro mês Grátis </h6>


<br>
<h5>Em que horas você prefere que seja feita a instalação? </h5>
<form method="post" method="get" action="?plano=<?php echo $plano;?>">
<select id="ordenacao" name="horario" style="width: 250px; height: 40px; border:1px solid #ddd;">
                                    <option value="1">De manhã</option>
                                    <option value="2">De tarde</option>
                                    <option value="3">De noite</option>
                                    </select>

    <input type="hidden" name="parte" value="6">
<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
<input type="hidden" name="numero" value="<?php echo $_POST['numero']; ?>">
<input type="hidden" name="roteador" value="<?php echo $_POST['roteador']; ?>">
<input type="hidden" name="pagamento" value="<?php echo $_POST['pagamento']; ?>">
<input type="hidden" name="nome" value="<?php echo $_POST['nome']; ?>">
<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
<input type="hidden" name="whatsapp" value="<?php echo $_POST['whatsapp']; ?>">
<input type="hidden" name="cpf" value="<?php echo $_POST['cpf']; ?>">
<input type="hidden" name="senha" value="<?php echo $_POST['senha']; ?>">
<input type="hidden" name="sobreacasa" value="<?php echo $_POST['sobreacasa']; ?>">
                                    <table class="login-box">
                                 
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Assinar!" style="width:240px;" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>


    <?php
}
if($_POST['parte'] == "6")
{
    //Verifica todos os dados
    if(strlen($_POST['nome']) < 4) {echo "Por favor, digite seu nome completo no campo Nome Completo";exit();}
    $_POST['email'] = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {}else{echo("Você não digitou um email valido"); exit();}
    $_POST['whatsapp'] = trim($_POST['whatsapp']);
    if (!is_numeric($_POST['whatsapp'])) {echo "Utilize somente numeros no campo Whatsapp"; exit();}
    $_POST['cpf'] = trim($_POST['cpf']);
    if(strlen($_POST['cpf']) == 14) {} else { echo "Digite o seu CPF completo";exit();}
    if(strlen($_POST['senha']) < 6) { echo "Sua senha precisa de pelo menos 6 caracteres";exit();}
    if($_POST['senha'] == "123456") {echo "Sua senha está facil demais, lembre-se que você podera ser hackeado se usar uma senha muito facil."; exit(); }
    if($_POST['senha'] == "1234567") {echo "Sua senha está facil demais, lembre-se que você podera ser hackeado se usar uma senha muito facil."; exit(); }
    $roteador = "666";
    if($_POST['roteador'] == "1") {$roteador = "0"; $roteadorpreco = "0";}
    if($_POST['roteador'] == "2") {$roteador = "2"; $roteadorpreco = "60";}
    if($_POST['roteador'] == "3") {$roteador = "3"; $roteadorpreco = "75";}
    if($_POST['roteador'] == "4") {$roteador = "4"; $roteadorpreco = "310";}
    if($roteador == "666") {exit();}
    $pagamento = "666";
    if($_POST['pagamento'] == "0") {$pagamento = "0";}
    if($_POST['pagamento'] == "1") {$pagamento = "1";}
    if($pagamento == "666") {exit();}

    $horario = "666";
    if($_POST['horario'] == "1") {$horario = "1";}
    if($_POST['horario'] == "2") {$horario = "2";}
    if($_POST['horario'] == "3") {$horario = "3";}
    if($horario == "666") {exit();}

    
    if (strpos($_POST['nome'], '"') !== false) {echo "Nome invalido";exit();}
    if (strpos($_POST['nome'], "'") !== false) {echo "Nome invalido";exit();}
    if (strpos($_POST['nome'], ';') !== false) {echo "Nome invalido";exit();}
    if (strpos($_POST['nome'], ',') !== false) {echo "Nome invalido";exit();}
    if (strpos($_POST['nome'], '*') !== false) {echo "Nome invalido";exit();}
    if (strpos($_POST['nome'], '`') !== false) {echo "Nome invalido";exit();}
    if (strpos($_POST['nome'], '=') !== false) {echo "Nome invalido";exit();}
    if (strpos($_POST['nome'], '.') !== false) {echo "Nome invalido";exit();}

    if (strpos($_POST['email'], '"') !== false) {echo "Email invalido";exit();}
    if (strpos($_POST['email'], "'") !== false) {echo "Email invalido";exit();}
    if (strpos($_POST['email'], ';') !== false) {echo "Email invalido";exit();}
    if (strpos($_POST['email'], ',') !== false) {echo "Email invalido";exit();}
    if (strpos($_POST['email'], '*') !== false) {echo "Email invalido";exit();}
    if (strpos($_POST['email'], '`') !== false) {echo "Email invalido";exit();}
    if (strpos($_POST['email'], '=') !== false) {echo "Email invalido";exit();}
    if (strpos($_POST['email'], '@') !== false) {} else {echo "Email invalido";exit();}
    if (strpos($_POST['email'], '.') !== false) {} else {echo "Email invalido";exit();}
    
if (strpos($_POST['whatsapp'], '"') !== false) {echo "Whatsapp invalido";exit();}
if (strpos($_POST['whatsapp'], "'") !== false) {echo "Whatsapp invalido";exit();}
if (strpos($_POST['whatsapp'], ';') !== false) {echo "Whatsapp invalido";exit();}
if (strpos($_POST['whatsapp'], ',') !== false) {echo "Whatsapp invalido";exit();}
if (strpos($_POST['whatsapp'], '*') !== false) {echo "Whatsapp invalido";exit();}
if (strpos($_POST['whatsapp'], '`') !== false) {echo "Whatsapp invalido";exit();}
if (strpos($_POST['whatsapp'], '=') !== false) {echo "Whatsapp invalido";exit();}
if (strpos($_POST['whatsapp'], '.') !== false) {echo "Whatsapp invalido";exit();}
if (strpos($_POST['cpf'], '"') !== false) {echo "CPF invalido";exit();}
if (strpos($_POST['cpf'], "'") !== false) {echo "CPF invalido";exit();}
if (strpos($_POST['cpf'], ';') !== false) {echo "CPF invalido";exit();}
if (strpos($_POST['cpf'], ',') !== false) {echo "CPF invalido";exit();}
if (strpos($_POST['cpf'], '*') !== false) {echo "CPF invalido";exit();}
if (strpos($_POST['cpf'], '`') !== false) {echo "CPF invalido";exit();}
if (strpos($_POST['cpf'], '=') !== false) {echo "CPF invalido";exit();}
if (strpos($_POST['cpf'], '.') !== false) {} else {echo "CPF invalido";exit();}
if (strpos($_POST['cpf'], '-') !== false) {} else {echo "CPF invalido";exit();}

if (strpos($_POST['senha'], '"') !== false) {echo "Senha invalida";exit();}
if (strpos($_POST['senha'], "'") !== false) {echo "Senha invalida";exit();}
if (strpos($_POST['senha'], ';') !== false) {echo "Senha invalida";exit();}
if (strpos($_POST['senha'], ',') !== false) {echo "Senha invalida";exit();}
if (strpos($_POST['senha'], '*') !== false) {echo "Senha invalida";exit();}
if (strpos($_POST['senha'], '`') !== false) {echo "Senha invalida";exit();}
if (strpos($_POST['senha'], '=') !== false) {echo "Senha invalida";exit();}
if (strpos($_POST['senha'], '.') !== false) {echo "Senha invalida";exit();}

if (strpos($_POST['sobreacasa'], '"') !== false) {echo "Detalhes da casa invalido";exit();}
if (strpos($_POST['sobreacasa'], "'") !== false) {echo "Detalhes da casa invalido";exit();}
if (strpos($_POST['sobreacasa'], ';') !== false) {echo "Detalhes da casa invalido";exit();}
if (strpos($_POST['sobreacasa'], ',') !== false) {echo "Detalhes da casa invalido";exit();}
if (strpos($_POST['sobreacasa'], '*') !== false) {echo "Detalhes da casa invalido";exit();}
if (strpos($_POST['sobreacasa'], '`') !== false) {echo "Detalhes da casa invalido";exit();}
if (strpos($_POST['sobreacasa'], '=') !== false) {echo "Detalhes da casa invalido";exit();}
if (strpos($_POST['sobreacasa'], '.') !== false) {echo "Detalhes da casa invalido";exit();}
$cep = trim($_POST['cep']);
if (strpos($cep, 'AND') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, ';') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, "'") !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, '"') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, '`') !== false) {echo "Utilize somente numeros no campo CEP.";exit();}
if (!is_numeric($_POST['numero'])) {
    echo "Utilize somente numeros no campo numero da casa";
    exit();
}
if($_POST['numero'] > 5000) { echo "Numero da casa invalido";exit();}
//


//Verifica se já tem uma adesão com os dados
$jaexiste = "0";
$sql = "SELECT * FROM `adesao` WHERE `email` LIKE '" . $_POST['email'] . "'";
$result = $conn->query($sql);
$disponivel = "0";
if ($result->num_rows > 0) {while($row = $result->fetch_assoc()) { $jaexiste = "1";}}

$sql = "SELECT * FROM `adesao` WHERE `cpf` LIKE '" . $_POST['cpf'] . "'";
$result = $conn->query($sql);
$disponivel = "0";
if ($result->num_rows > 0) {while($row = $result->fetch_assoc()) { $jaexiste = "1";}}

if($jaexiste == "1")
{
    ?>
    <h4>Ops... parece que já existe um pedido de adesão com o mesmo CPF ou Email informado.... em breve entraremos em contato por email, whatsapp ou ligação</h4> 
    <?php
    exit();
}
//




//Verifica se o CEP está disponivel
$sql = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "' AND `disponivel` LIKE '1'";
$result = $conn->query($sql);
$disponivel = "0";
if ($result->num_rows > 0) {while($row = $result->fetch_assoc()) { $disponivel = "1";}}
if($disponivel == "0"){echo "CEP Invalido"; exit();}
//

//Cria o pedido de adesão no mysql
$id = rand(1,999999999);
$data = date('y-m-d');
$sql = "INSERT INTO `adesao` (`id`, `email`, `nome`, `senha`, `cep`, `numero`, `sobreacasa`, `plano`, `cpf`, `pagamentosfatura`, `roteador`, `pagamentoroteador`, `fatura`, `whatsapp`, `datapedido`, `pago`, `andamento`, `tecnico`, `cancelado`, `resposta`, `horario`) VALUES ('" . $id . "', '" . $_POST['email'] . "', '" . $_POST['nome'] . "', '" . $_POST['senha'] . "', '" . $cep . "', '" . $_POST['numero'] . "', '" . $_POST['sobreacasa'] . "', '" . $plano . "', '" . $_POST['cpf'] . "', '" . $pagamento . "', '" . $roteador . "', '" . $roteadorpreco . "', '0', '" . $_POST['whatsapp'] . "', '" . $data . "', '0', '0', '0', '0', '', '" . $horario . "');";
$result = $conn->query($sql);
//


header('Location: ?plano=1&pronto=1&id=' . $id);
}
?>





                    </div>
                </div>
            </div>
        </div>
    </section>
    
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</body>

</html>