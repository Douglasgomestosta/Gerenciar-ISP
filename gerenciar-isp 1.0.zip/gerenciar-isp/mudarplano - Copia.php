﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
            $senha = $row["senha"];
            $cpf = $row["cpf"];
            $cep = $row["cep"];
            $caixa = $row["caixa"];
            $asaasid = $row["asaasid"];
            $asaasassinaturaid = $row["asaasassinaturaid"];
        }
    }


    $sql = "SELECT * FROM `caixas` WHERE `id` LIKE '" . $caixa . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $velocidadecaixa = $row["Tamanho"];
        }
    }
    $velocidadecaixa = $velocidadecaixa - 50;

    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
        }
    }


    $sql = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $capacidade = $row["capacidade"];

        }
    }


    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
            $senhapppoe = $row["senha"];
            $ip = $row["ip"];
            $roteador = $row["roteador"];
            $mac = $row["mac"];
            $ativopppoe = $row["ativo"];
            $servidor = $row["servidor"];

        }
    }


}
else
{
    header('Location: login.php?redirect=mudarplano.php');
}



?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


</style>



<script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>



</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php


if($_GET['atualizado'] == "1")
{
    ?>
    <center> <img src="imagens/ok.webp" width="100">
<h1 style="font-size: 25px; color: black;">Pronto! </h1>
<h3>Seu plano de internet já foi alterado com exito, em até 1 hora sua nova velocidade já estará disponivel para você, suas faturas novas e pendentes já estáo com o novo valor</h3>
    
<br>
            <a href="painel.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar ao inicio</a><br><br>
    
    <?php
    exit();
}


$mes = date("m");
$ano = date("Y");
$datasemdia = "/" . $mes . "/" . $ano;
$sql = "SELECT * FROM `trocardeplanos` WHERE `usuarioid` = " . $id . " AND `data` LIKE '%" . $datasemdia . "%'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            ?>
            <center>
            <h2 style="color:red;">Troca de plano indisponivel</h2>
<h3>Você não pode trocar de plano nesse momento, pois já trocou o seu plano de internet nos ultimos 2 meses, por favor espere 2 meses desde a ultima troca de plano para atualizar seu plano de internet novamente </h3>
            <h4>Vocẽ trocou seu plano de internet no dia: <?php echo $row["data"]; ?></h4>
            <br>
            <a href="painel.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar ao inicio</a><br><br>
            <?php
            exit();

        }
    }





    $mes = date("m") - 1;
    $mes = "0" . $mes;
$ano = date("Y");
if($mes == "0"){$mes = "12"; $ano = $ano -1;}
$datasemdia = "/" . $mes . "/" . $ano;
$sql = "SELECT * FROM `trocardeplanos` WHERE `usuarioid` = " . $id . " AND `data` LIKE '%" . $datasemdia . "%'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            ?>
            <center>
            <h2 style="color:red;">Troca de plano indisponivel</h2>
<h3>Você não pode trocar de plano nesse momento, pois já trocou o seu plano de internet nos ultimos 2 meses, por favor espere 2 meses desde a ultima troca de plano para atualizar seu plano de internet novamente </h3>
            <h4>Vocẽ trocou seu plano de internet no dia: <?php echo $row["data"]; ?></h4>
            <br>
            <a href="painel.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar ao inicio</a><br><br>
            <?php
            exit();

        }
    }


///Pagamentos

$sql = "SELECT * FROM `pagamentos` WHERE `idusuario` = " . $id . " ORDER BY `id` DESC LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $vencido = $row["vencido"];
                                            $status = $row["pago"];

    }
}
$pendentes = 0;
$atrasadas = "0";
if(!$status == "1")
{
    $atrasadas = "1";
}

if($vencido == "1")
{
    $atrasadas = "1";
}


if($atrasadas == 1){
    ?> <center>
    <h2 style="color:red;">Faturas pendentes </h2>
    <h3>A sua última fatura foi ou está atrasada! Pague sua fatura e espere o próximo mês para fazer a troca do seu plano de internet.</h3>
     <br> <a href="faturas.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Ver Faturas</a>
  <a href="painel.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar ao inicio</a><br><br>
    </center>
    <?php
exit();
}



if($_GET['error'] == "1")
{
echo '<h4 style="color:red;">CPF ou Senha invalidos, por favor tente novamente ou entre em contato com o nosso suporte ao cliente. </h4>';
}



if($_POST['parte'] == "2")
{

    if (!is_numeric($_POST['plano'])) {
        echo "Caracteres invalidos no campo 'plano'";
        exit();
    }
    $cpfdados = $_POST['cpf'];
    $senhadados = $_POST['senha'];
    $motivo = $_POST['motivo'];
    $senhadados = md5($senhadados);
    if($senha == $senhadados){} else { header('Location: ?error=1'); exit();}
    if($cpfdados == $cpf){} else {header('Location: ?error=1'); exit();}
    $data = date('d/m/Y');
$novoplano = $_POST['plano'];

$sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $_POST['plano'] . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
            $velocidade = $row["velocidade"];
            $planoencontrado = "1";
        }
    }
    if($planoencontrado == "0")
    {
        echo "Plano não encontrado no sistema!";
        exit();
    }




$sql = "INSERT INTO `trocardeplanos` (`id`, `usuarioid`, `planoanterior`, `novoplano`, `data`) VALUES (NULL, '" . $id . "', '" . $plano . "', '" . $novoplano . "', '" . $data . "');";
$result = $conn->query($sql);








$sql = "UPDATE `usuarios` SET `plano` = '" . $novoplano . "' WHERE `usuarios`.`id` = " . $id . ";";
$result = $conn->query($sql);


$sql = "UPDATE `pppoe` SET `plano` = '" . $novoplano . "' WHERE `pppoe`.`idcliente` = " . $id . ";";
$result = $conn->query($sql);

header('Location: ?atualizado=1');
?>
<head>
<meta http-equiv="refresh" content="0; URL='?atualizado=1'"/>

</head>
<?php
exit();
}


if($_POST['parte'] == "1")
{
    if (!is_numeric($_POST['plano'])) {
        echo "Caracteres invalidos no campo 'plano'";
        exit();
    }
    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $_POST['plano'] . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
            $velocidade = $row["velocidade"];
        }
    }

?> 
<h3>Estas são as informações do seu novo plano </h3>
<H4>Upload: até <?php echo $velocidade; ?> Megas</h4>
<H4>Download: até <?php echo $velocidade; ?> Megas</h4>
<H4>Preço: R$<?php echo $preco; ?>,00 </h4>
<h4>Lembre-se que para velocidades acima de 50 megas, tanto o seu roteador como o cabo de rede utilizado precisa ser adequado para tal velocidade, caso você não esteja recebendo a sua velocidade contratada, por favor abra um pedido de suporte para que possamos atualizar seus equipamentos para a nova velocidade contratada. </h4>
<h5>Para todos os planos, a velocidade entre o horário de 10:00 as 22:00 pode chegar a até no mínimo 40% da velocidade contratada, de acordo com a Anatel.</h5>


<form method="post">
<input type="hidden" name="parte" value="2">
<input type="hidden" name="plano" value="<?php echo $_POST['plano']; ?>">
                                    <table class="login-box">
                                        
                                        

                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                               Digite seu CPF
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="1" type="text" size="20px" style="width:240px;" name="cpf" class="input is-large" required="" minlength="6" maxlength="80">
                                            </td>
                                        </tr>


                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                               Digite sua senha
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <input tabindex="1" type="password" size="20px" style="width:240px;" name="senha" class="input is-large" required="" minlength="5" maxlength="80">
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>




<?php
    exit();
}
?>
<h3>Aqui estão os planos disponiveis a você</h3>
<form method="post" action="?erro=0">
    <input type="hidden" name="parte" value="1">
                                    <table class="login-box">
                                        
                                    <select id="ordenacao" name="plano">
                                    <option value="1">25 Megas</option>
                                    <option value="2">35 Megas</option>
                                    <option value="3">50 Megas</option>
                                    <?php
                                     if($capacidade >= "500")
                                    {
                                        ?>
                                   <!--- <option value="3">100 Megas</option> --->
                                    <?php
                                    }else{$planoindisponivel = "1";}
                                    ?>
                                    </select>
<br>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>

                                <?php
                                if($planoindisponivel == 1)
                                {
                                    ?>
                                    <h5 style="color:red;">Infelizmente os planos de internet com mais de 50 Megas estão indisponiveis para a sua rua</h5>

                                    <?php
                                }
                                ?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->

    
   
</body>
</html>
