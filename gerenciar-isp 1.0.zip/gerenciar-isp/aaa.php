﻿<?php
$texto = "teste' and delete all from = teste;";
$texto = str_replace(';', ' ', $texto);
    $texto = str_replace("'", ' ', $texto);
    $texto = str_replace('.', ' ', $texto);
    $texto = str_replace('*', ' ', $texto);
    $texto = str_replace('`', ' ', $texto);
    $texto = str_replace('=', ' ', $texto);

    echo $texto;