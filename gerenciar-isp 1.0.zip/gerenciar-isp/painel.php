﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
            $desativado = $row["desativado"];
            $jalogou = $row["jalogou"];
        }
    }

    //ver se é a primeira vez do cliente no painel, se for redireciona para a pagina de bem vindo
    if(empty($jalogou)){
        header('Location: novocliente.php');
    }

    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
           
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            
        }
    }
}
else
{
    header('Location: login.php');
    exit();
}

$sql = "SELECT * FROM `cancelamentos` WHERE `idcliente` LIKE '" . $id . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $idcliente = $row["idcliente"];
        $andamento = $row["andamento"];
        if($id == $idcliente)
        {
            header('Location: cancelar.php');
        }
    }
}



?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">



<h4>Em que podemos ajudar você, <?php echo $nome; ?>? </h4>



<?php
//ver se o cliente está desativado
if(empty($desativado)){}else{
    if($desativado == "1"){ $motivo = "Falta de pagamento";}
    if($_GET['faturarecuperada'] == "1")
    {
        $sql = "SELECT * FROM `pagamentos` WHERE `idusuario` = " . $id . " AND `pago` IS NULL AND `vencido` IS NULL AND `restaurarservico` IS NOT NULL ORDER BY `id` DESC";

        $sql = "INSERT INTO `pagamentos` (`id`, `idusuario`, `vencimento`, `pago`, `pagodata`, `vencido`, `valor`, `checkout`, `checkoutid`, `descricao`, `restaurarservico`) VALUES (NULL, '1', '2020-11-10', NULL, NULL, NULL, '25', NULL, NULL, 'Fatura do mês 08 com acréscimo dos dias utilizados antes do vencimento da fatura por restabelecimento do serviço', '1');";
    }
?>
<div class="panel panel-default">
                        <div class="panel-heading">
                        Seu serviço foi suspenso
                        </div>
                        <div class="panel-body">
                        <center><img src="imagens/yellow.png" width="100">
<h3>Seu serviço de internet foi suspenso por <?php echo $motivo; ?></h3>
<?php

if($desativado == "1")
{
    $dia = date("d");
    $vencimentofalta = $vencimento - $dia;
    if($vencimentofalta <= 5)
    {
        if($vencimentofalta <= -1){ echo "já passou!";}else{}
        
        }
    if($pequenoatraso == "1")
    {

    }else
    {
?>
<h4>Para que você possa reativar seu serviço de internet, por favor, abra um pedido de suporte na categoria "outros" no sistema de ajuda, ou entre em contato conosco pelo Facebook </h4>
<center> <a href="suporte/novo.php" class="btn btn-primary btn-lg">Preciso de ajuda!</a> </center>
<br>
<center> <a href="https://messenger.com/t/datawebbrasil" class="btn btn-primary btn-lg">Messenger</a> </center>
<?php
    }
}
?>
                      </div>


                    </div>
                </div>












                <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Precisando de algo?
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <div class="col-md-5">

<a href="/suporte/novo.php" style="font-size:20px;"> <img src="imagens/ajuda.png" style="border-radius: 200px; width: 10%;"> Preciso de ajuda </a>
</div>

<div class="col-md-7">
<a href="/suporte" style="font-size:20px;"> <img src="imagens/support-icon.png" style="border-radius: 200px; width: 10%;"> Meus pedidos de suporte</a>
</div>



<div class="col-md-5">
<a href="cancelar.php" style="font-size:20px;"> <img src="imagens/false.png" style="border-radius: 200px; width: 10%;"> Não quero mais o serviço</a>
</div>

<div class="col-md-7">
<a href="/faturas" style="font-size:20px;"> <img src="imagens/money.png" style="border-radius: 200px; width: 10%;">Minhas faturas</a>
</div>


<div class="col-md-5">
<a href="meuplano.php" style="font-size:20px;"> <img src="imagens/plano.png" style="border-radius: 200px; width: 10%;">Meu plano de internet</a>
</div>

                                       <div style="margin-top: 10px;">
											
														
									

                                        </div>
                                    </div>
                    </div>
                    </div>










                 <!-- /. ROW  -->
                 <hr />
               



















    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   

    <div vw class="enabled">
    <div vw-access-button class="active"></div>
    <div vw-plugin-wrapper>
      <div class="vw-plugin-top-wrapper"></div>
    </div>
  </div>
  <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
  <script>
    new window.VLibras.Widget('https://vlibras.gov.br/app');
  </script>
</body>
</html>


<?php
exit();
}
//fim ver se o cliente está desativado
?>
                    <div class="col-md-7">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Suas faturas
                        </div>        
                                      
                                    <div class="panel-body"> 
<?php
                                    ///Pagamentos
$pendentes = 0;
$atrasadas = 0;
$data = date("Y-m");
$dia = date("d");
$outrodia = $dia - 4;
$datafim = $data . "-" . $outrodia;
$sql = "SELECT * FROM `pagamentos` WHERE `idusuario` = " . $id . " AND `vencimento` > '" . $datafim . "' ORDER BY `id` DESC LIMIT 12";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {



        $vencido = $row["vencido"];
                                            $status = $row["pago"];

if($vencido == "1")
{
    
    $atrasadas = "1";
}

if(!$status == "1")
{
    $pendentes = "1";
}else{
    //$pendentes = "0";
    //$atrasadas = "0";
}

    }
}





///
if($atrasadas == 0)
{
if($pendentes == 0)
    {
?>
    <div class="alert alert-danger" style="background-color:green; color:white;">
    Todas as suas faturas estão em dia, Obrigado!
</div>


<?php    }else{
    $sql = "SELECT * FROM `pagamentos` WHERE `idusuario` = " . $id . " AND `pago` IS NULL ORDER BY `vencimento` DESC";
    $result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $vencimento = $row["vencimento"];
    }
}
$array=explode("-",$vencimento);
$mes = $array[1];
$dia = $array[2];
$ano = $array[0];
$vencimento =  "$dia/$mes";
    ?>
    <div class="alert alert-danger" style="background-color:green; color:white;">
Você tem uma fatura em aberto com vencimento em <?php echo $vencimento; ?>
</div>

<?php
}
}else{
    ?>
<div class="alert alert-danger" style="background-color:red; color:white;">
Você tem faturas vencidas! seu serviço corre o risco de ser suspenso.
</div>


<?php
}
?>

<center><a href="/faturas" class="btn btn-primary btn-lg">Minhas faturas</a></center>
                   
                </div>
            </div>
                          </div>



                          <div class="col-md-5">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                           Seu serviço
                        </div>        
                                      
                                    <div class="panel-body"> 
                                         <?php

    //Ver se usuario está conectado
require 'sistema/logadopppoe.php'; 

if($desconectado == 1){
    ?>
        <div class="alert alert-danger" style="background-color:red; color:white;">
 Seu roteador está DESCONECTADO a internet, você foi desconectado as <?php echo $stoptime; ?> pelo motivo: <?php echo $motivodesconect; ?>
</div>
<?php
}
else
{
    if($nuncaconectou == "1")
    {
?>
    <div class="alert alert-danger" style="background-color:green; color:white;">
   Seu roteador ainda não se conectou ao nosso sistema!
</div>
<?php
    }else
    {
    ?>
    <div class="alert alert-danger" style="background-color:green; color:white;">
    Seu roteador está CONECTADO a internet, conexão realizada em <?php echo $starttime; ?> 
</div>
<?php
}
}
//


                                         ?>
                                       <div style="margin-top: 10px;">
											
                                            <?php
$sql = "SELECT * FROM `suporte` WHERE `status` LIKE '0' AND `idcliente` LIKE '" . $id . "' OR `status` LIKE '1' AND `idcliente` LIKE '" . $id . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    ?>
       <center> <a href="/suporte" class="btn btn-primary btn-lg">Meus pedidos de suporte.</a></center>
        <?php
}else
{
?>
<center><a href="/suporte/novo.php" class="btn btn-primary btn-lg">Preciso de ajuda!</a></center>
<?php
}
                                            ?>
                                       
														
									

                                        </div>
                                    </div>
                    </div>
                    </div>
                    
                    <br>
                    <a>.</a>
                    <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Precisando de algo?
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <div class="col-md-5">

<a href="/suporte/novo.php" style="font-size:20px;"> <img src="imagens/ajuda.png" style="border-radius: 200px; width: 10%;"> Preciso de ajuda </a>
</div>

<div class="col-md-7">
<a href="/suporte" style="font-size:20px;"> <img src="imagens/support-icon.png" style="border-radius: 200px; width: 10%;"> Meus pedidos de suporte</a>
</div>

<div class="col-md-5">
<a href="firewall.php" style="font-size:20px;"> <img src="imagens/firewall.png" style="border-radius: 200px; width: 10%;"> Quero configurar meu Firewall</a>
</div>

<div class="col-md-7">
<a href="mudanca.php" style="font-size:20px;"> <img src="imagens/map.svg" style="border-radius: 200px; width: 10%;"> Quero trocar de endereço</a>
</div>

<div class="col-md-5">
<a href="mudarplano.php" style="font-size:20px;"> <img src="imagens/ethernet.png" style="border-radius: 200px; width: 10%;"> Quero trocar meu plano de internet</a>
</div>

<div class="col-md-7">
<a href="cancelar.php" style="font-size:20px;"> <img src="imagens/false.png" style="border-radius: 200px; width: 10%;"> Não quero mais o serviço</a>
</div>

<div class="col-md-5">
<a href="/faturas" style="font-size:20px;"> <img src="imagens/money.png" style="border-radius: 200px; width: 10%;">Minhas faturas</a>
</div>


<div class="col-md-7">
<a href="meuplano.php" style="font-size:20px;"> <img src="imagens/plano.png" style="border-radius: 200px; width: 10%;">Meu plano de internet</a>
</div>

                                       <div style="margin-top: 10px;">
											
														
									

                                        </div>
                                    </div>
                    </div>
                    </div>





                    <div class="">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 
                                    <center>
<img src="../imagens/causas.jpg" style=" width: 10%;">
 <h3>Conheça a Data Web Causas.</h3>
 <h4>A Data Web Causas utiliza 50 centavos de cada uma de suas faturas pagas para fazer campanhas beneficentes para a sociedade brasileira.
</h4>
 <a href="/causas" class="btn btn-primary btn-lg">Saiba Mais.</a>

                </div>
            </div>
                          </div>



                          <div class="">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 
<center>
<img src="../imagens/cursos.jpg" style=" width: 10%;">
 <h3>Cursos para você e sua familia.</h3>
 <h4>Na Data Web Educa você tem acesso a cursos de auto-conecimentos para melhorar a sua vida pessoal e profissional, você pode ter até 3 contas, para membros da sua familia.</h4>
 <a href="/cursos" class="btn btn-primary btn-lg">Saiba Mais.</a>

                </div>
            </div>
                          </div>




<p>Painel de administração exclusivo Data Web, Versão <?php echo $versao; ?> </p>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   

    <div vw class="enabled">
    <div vw-access-button class="active"></div>
    <div vw-plugin-wrapper>
      <div class="vw-plugin-top-wrapper"></div>
    </div>
  </div>
  <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
  <script>
    new window.VLibras.Widget('https://vlibras.gov.br/app');
  </script>
</body>
</html>
