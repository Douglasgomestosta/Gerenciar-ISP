﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
            $senha = $row["senha"];
            $cpf = $row["cpf"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
        }
    }
}
else
{
    header('Location: login.php');
}

if($_POST['cancelar'] == 1)
{
$cpfdados = $_POST['cpf'];
$senhadados = $_POST['senha'];
$motivo = $_POST['motivo'];
$senhadados = md5($senhadados);
if($senha == $senhadados){} else { header('Location: ?error=1'); exit();}
if($cpfdados == $cpf){} else {header('Location: ?error=1'); exit();}
if (strpos($motivo, ';') !== false) { header('Location: ?error=1'); exit();}
    if (strpos($motivo, "'") !== false) { header('Location: ?error=1'); exit();}
    if (strpos($motivo, '"') !== false) { echo "Digite um motivo validoo"; exit();}
    if (strpos($motivo, '@') !== false) {header('Location: ?error=1'); exit();}
    if (strpos($motivo, '`') !== false) {header('Location: ?error=1');exit();}
    $data = date('y-m-d');
    if(strlen($_POST['motivo']) > 200) {header('Location: ?error=1'); exit();}

    $sql = "INSERT INTO `cancelamentos` (`idcliente`, `data`, `motivo`, `andamento`) VALUES ('" . $id . "', '" . $data . "', '" . $motivo . "', '0');";
$result = $conn->query($sql);
}

if($_GET['cancelar'] == 2)
{
    $sql = "DELETE FROM `cancelamentos` WHERE `cancelamentos`.`idcliente` = " . $id;
$result = $conn->query($sql);
header('Location: painel.php');
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   

<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


</style>


<script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php
$sql = "SELECT * FROM `cancelamentos` WHERE `idcliente` LIKE '" . $id . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $idcliente = $row["idcliente"];
        $andamento = $row["andamento"];
        if($id == $idcliente)
        {
            $cancelado = 1;
        }
    }
}
if($andamento == 0)
{
    $andamento = "Aguardando um técnico";
}
if($andamento == 1)
{
    $andamento = "Um técnico está realizando a desinstalação";
}
if($andamento == 2)
{
    $andamento = "A desinstalação já foi realizada";
}
if($cancelado == 1)
{
    ?>
<h2>Cancelamento efetuado com exito</h1>
<h3>Em até 4 dias uteis estaremos em sua residência para fazer a remoção de nossos equipamentos, lembre-se que o roteador é seu equipamento e por esse motivo será entregue a você no fim da remoção.</h3>
<h4>Caso você receba um sms/email do pagamento da sua fatura, por favor desconsidere.</h4>
<h5>O status do seu pedido de cancelamento atual é: <?php echo $andamento; ?>.</h5>
    <?php
    if($andamento == "Aguardando um técnico")
    {
        ?>
        <center> <h4>Se arrependeu? </h4>
        <a href="?cancelar=2" style="font-size: 20px;">Suspender cancelamento do serviço</a><br> </center>
        <?php
    }
}
else
{
?>
<center><img src="imagens/triste.png" width="100">
<h1>Poxa, tem certeza? </h1>
<h3>Passamos bons momentos juntos, e sempre trabalhamos duros para dar o melhor serviço e a melhor experiencia para você, mas se deseja nós abandonar... tudo bem... </h3>
<h4>Vamos tentar nos reconciliar? Abra um pedido de suporte, nós informando que deseja nós abandonar, para que possamos resolver seu problema e até lhe dar um bônus para que você fique conosco.</h4>
<br>
<h3>Ainda quero cancelar minha internet </h3>
<form method="post">
<input type="hidden" name="cancelar" value="1">
                                    <table class="login-box">
                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                               Escreva-nos o que resultou esse rompimento?
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="1" type="text" size="20px" style="width:240px;" name="motivo" class="input is-large" required="" minlength="4" maxlength="80">
                                            </td>
                                        </tr>
                                        

                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                               Digite seu CPF
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="1" type="text" size="20px" style="width:240px;" name="cpf" class="input is-large" required="" minlength="6" maxlength="80">
                                            </td>
                                        </tr>


                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                               Digite sua senha
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <input tabindex="1" type="password" size="20px" style="width:240px;" name="senha" class="input is-large" required="" minlength="5" maxlength="80">
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>

                                <?php
}
?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->

    
   
</body>
</html>
