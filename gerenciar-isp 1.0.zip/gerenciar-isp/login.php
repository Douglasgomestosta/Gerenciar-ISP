<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE); 
require 'sistema/db.php'; 
require 'sistema/FUNCTIONS.php'; 
if (!empty($_GET['redirect'])) {
    if (strpos($_GET['redirect'], 'http://') !== false) { exit();}
        if (strpos($_GET['redirect'], 'https://') !== false) { exit();}
            if (strpos($_GET['redirect'], 'www.') !== false) { exit();}
}
if($_SESSION['login'] == 1)
{
    if(!$_GET['sucesso'] == "1"){
    
    if (empty($_GET['redirect'])) {
        header('Location: painel.php');
    }else
    {
        header('Location: ' . $_GET['redirect']);
    }


    }
}

if($_POST['login'] == "1")
{

    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $senha = md5($senha);
      //$email = filter_var($email, FILTER_SANITIZE_EMAIL);
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $tipo = "email";

    } else {

        $email = sqlinjection($email);
        $email = trim($email);
        $email = str_replace('.', '', $email);
        $email = str_replace('-', '', $email);
        $cpfnumero = strlen($email);
        if($cpfnumero < 11 || $cpfnumero > 11){ header('Location: ?erro=1'); exit();}
        if (!is_numeric($email)) { header('Location: ?erro=1'); exit();}
$tipo = "cpf";

        //header('Location: ?erro=1');
  //exit();

    }
    if (strpos($email, ';') !== false) { header('Location: ?erro=1'); exit();}
    if (strpos($email, "'") !== false) { header('Location: ?erro=1'); exit();}
    if (strpos($email, '"') !== false) { header('Location: ?erro=1'); exit();}
    if (strpos($email, '`') !== false) { header('Location: ?erro=1'); exit();}


    $sql = "SELECT * FROM `usuarios` WHERE `" . $tipo . "` LIKE '" . $email . "' AND `senha` LIKE '" . $senha . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        if ($senha == $row["senha"])
        {
          $_SESSION['login'] = "1";
          $_SESSION['email'] = $email;
          $_SESSION['senha'] = $senha;
          $_SESSION['id'] = $row["id"];
          $_SESSION['usuariocomum'] = "1";
          $_SESSION['nome_completo'] = $row["nome"];
          //salva o log de login
          $id = $row["id"];
          $ip = $_SERVER['HTTP_CLIENT_IP'];
          $navegador = $_SERVER['HTTP_USER_AGENT'];
          $sql = "INSERT INTO `autenticacoes` (`id`, `idcliente`, `data`, `navegador`, `ip`) VALUES (NULL, '" . $id . "', CURRENT_TIMESTAMP, '" . $navegador . "', '" . $ip . "');";
$resultt = $conn->query($sql);

//redireciona o usuario
          if (empty($_GET['redirect'])) {
            header('Location: login.php?sucesso=1');
        }else
        {
            header('Location: ' . $_GET['redirect']);
        }



        }else
        {
            header('Location: ?erro=2');
        }
    }
} else {
    header('Location: ?erro=2');
}
$conn->close();


}
?>
<!DOCTYPE html>
<html>
    
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login no painel Data Web</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="css/bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css">
    <script src="https://apis.google.com/js/platform.js" async defer></script>
		<meta name="google-signin-client_id" content="1google api">
</head>

<body>
    <section class="hero is-success is-fullheight">
        <div class="hero-body">
            <div class="container has-text-centered">
                <div class="column is-4 is-offset-4">
                    
<img class="default" alt="" src="/imagens/logo.png" style="width: 250px; margin: 0px;">


                    <?php if($_GET['erro'] == "1"){?>
                    <div class="notification is-danger">
                      <p>E-mail ou CPF Invalido!</p>
                    </div>
                <?php } ?>


                <?php if($_GET['erro'] == "2"){?>
                    <div class="notification is-danger">
                      <p>A senha digitada não é a correta ou não existe nenhum cliente com este e-mail/CPF e senha iguais <a tabindex="5" class="vst-advanced" href="reset.php">
                                                       Esqueceu sua senha?
                                                    </a></p>
                    </div>
                <?php } ?>
                    <div class="box">
                       

                    <?php if($_GET['sucesso'] == "1"){?>
                    
                        <img alt="" src="imagens/loading.gif"  style="width: 90px; margin: 0px;">
                        <h3 style="font-size: 30px;">Bem Vindo, <?php echo $_SESSION['nome_completo']; ?></h3>
                        <head>
                        <meta http-equiv="refresh" content="5; URL='/painel.php'"/>
                        </head>
                <?php exit();} ?>


                    <center><h5>Entre pela sua conta Google </h5> <div class="g-signin2" data-onsuccess="onSignIn"></div> </center>

                    <p id='msg'></p>
                    <script>
		function onSignIn(googleUser) {
			var profile = googleUser.getBasicProfile();
			var userID = profile.getId(); 
			var userName = profile.getName(); 
			var userPicture = profile.getImageUrl(); 
			var userEmail = profile.getEmail(); 			 
			var userToken = googleUser.getAuthResponse().id_token; 
			
			//document.getElementById('msg').innerHTML = userEmail;
			if(userEmail !== ''){
				var dados = {
					userID:userID,
					userName:userName,
					userPicture:userPicture,
					userEmail:userEmail
				};
				$.post('valida.php', dados, function(retorna){
					if(retorna === '"erro"'){
						var msg = "Usuário não encontrado com esse e-mail";
                        document.getElementById('msg').innerHTML = msg;
                        window.location.href = "?erro=1";
                        var auth2 = gapi.auth2.getAuthInstance();
			auth2.signOut().then(function () {
			  console.log('User signed out.');
            });
            
					}else{
                        window.location.href = "?sucesso=1";
                        
                        var auth2 = gapi.auth2.getAuthInstance();
			auth2.signOut().then(function () {
			  console.log('User signed out.');
            });
            
					}
					
				});
			}else{
				var msg = "Usuário não encontrado!";
                document.getElementById('msg').innerHTML = msg;
                
                window.location.href = "?erro=1";
                var auth2 = gapi.auth2.getAuthInstance();
			auth2.signOut().then(function () {
			  console.log('User signed out.');
			});
			}
		}
        </script>
        		
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


<form method="post">
<input type="hidden" name="login" value="1">
                                    <table class="login-box">
                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                                E-mail ou CPF
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="1" type="text" size="20px" style="width:240px;" name="email" class="input is-large">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
                                                Senha
                                                <span style="padding:0 0 0 14px;">
                                                    <a tabindex="5" class="vst-advanced" href="reset.php">
                                                       Esqueci minha senha
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="2" type="password" size="20px"  style="width:240px;"  class="input is-large" name="senha" >
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Entrar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>



                               

                                		






                    </div>
                    <a href="http://datawebtelecom.site/internet-residencial/" style="color:#070707; font-size:16px;">Ainda não é nosso cliente? - <b>Então venha para a melhor!</b></a>
                </div>
            </div>
        </div>
    </section>
    
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</body>

</html>