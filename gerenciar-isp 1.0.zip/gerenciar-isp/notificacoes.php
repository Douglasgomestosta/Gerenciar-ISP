<?php
session_start();
$id = $_SESSION['id'];
?>
<head>
<meta http-equiv="refresh" content="30; URL='#'"/>
</head>
<?php
require 'sistema/db.php'; 


if($_SESSION['login'] == 1)
{
    $idnotificacao = 0;
    $sql = "SELECT * FROM `notificacoes` WHERE `idusuario` = " . $id . " AND `exibido` = 0";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $idnotificacao = $row["id"];

            $sqll = "UPDATE `notificacoes` SET `exibido` = '1' WHERE `notificacoes`.`id` = " . $idnotificacao . ";";
$resultt = $conn->query($sqll);
        
        
        }
    }

    ?>
    <head><title><?php echo $idnotificacao; ?></title></head>
    <?php
}
else
{
    ?>
    <head><title>0</title></head>
    <?php
}
?>
