﻿<?php
session_start();
//error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
require '../sistema/FUNCTIONS.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $cep = $row["cep"];
            $ativo = $row["ativo"];
            $desativado = $row["desativado"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
            $velocidade = $row["velocidade"];
            $velocidademinima = $row["velocidademinima"];
        }
    }
    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
            $ssidwifi = $row["ssidwifi"];
            $servidor = $row["servidor"];
           
        }
    }





}
else
{
    header('Location: ../login.php?redirect=suporte');
}

if(empty($_POST['parte']))
{
    $_POST['parte'] = "0";
}
//continuar teste mesmo sem estar conectado no mesmo wifi
if($_GET['continuarteste'] == "1")
{
    $_POST['parte'] = "1";
    $_POST['tipo'] = "2";
    $_SESSION['continuarwifinome'] = "1";
}
//trocar GET para POST
if($_GET['tipo'] > 0){
    $_POST['tipo'] = $_GET['tipo'];
    $_POST['parte'] = "1";
}
//fim
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>

<script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php
if($_GET['criado'] == 1)
{
    ?><center>
    <img src="../imagens/ok.webp" width="100">
<h1 style="font-size: 25px; color: black;">Pronto! </h1>
<h3>Seu pedido de suporte já foi registrado no sistema e em breve será respondido </h3>
<a href="index.php">Saiba Mais</a>
    <?php
    exit();
}

//parte 0
if($_POST['parte'] == 0)
{
    if(!empty($desativado))
        {
            ?>
            <h2>Ops... parece que seu serviço está inativo</h2>
            <h4>O seu serviço de internet pode ter sido desativado por falta de pagamento, descumprimento de contrato ou a pedido do cliente </h4>
            <h5>Vocẽ pode entrar em contrato conosco pedindo a reativação de seu serviço </h5>
            <br><br>
        <a href="../index.php" style="width: 100%;
          background-color: #4CAF50;
          color: white;
          padding: 14px 20px;
          margin: 8px 0;
          border: none;
          border-radius: 4px;
          cursor: pointer;">Voltar a pagina inicial</a><br><br>
            <?php
            exit();
        }


            //ver se cliente já criou outros suportes
$sql = "SELECT * FROM `suporte` WHERE `status` LIKE '0' AND `idcliente` LIKE '" . $id . "' AND `categoria` LIKE '2' OR `status` LIKE '1' AND `idcliente` LIKE '" . $id . "' AND `categoria` LIKE '2' LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data = $row["data"];
        $idagendamento = $row["id"];
        $array=explode("-",$data);
        $mes = $array[1];
        $dia = $array[2];
        $arrayy=explode(" ",$dia);
        $dia = $arrayy[0];
        $hora = $arrayy[1];
        $arrayy=explode(":",$hora);
        $hora = $arrayy[0] . ":" . $arrayy[1];
        $ano = $array[0];
        $data =  "$dia/$mes/$ano as $hora";
        if($row["data"] == "0")
        {
            $status = "Aguardando atendimento por um técnico.";
        }else{
            $status = "Um técnico está analisando ou resolvendo seu problema.";
        }
        $idsuporte = $row["id"];
?>
<div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Você já tem um pedido de suporte em aberto!
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    
<H3>Você já tem um pedido de suporte aberto em <?php echo $data; ?> com o status de "<?php echo $status; ?>" </h3>
<a href="index.php?id=<?php echo $idsuporte; ?>" class="btn btn-info btn-lg">Ver pedido de suporte.</a>
                                    </div>
                    </div>
                    </div>

<?php
    exit();
    }
}
    //fim cliente já criou outros suportes

        
        require '../sistema/logadopppoe.php';
        if($desconectado == 1)
        {
            ?>
            <H3>Você está desconectado a internet! </h3>
            <?php


if($desconectado == 1){
    ?>
    <h4>Atualmente, seu roteador está <a style="color:red;">DESCONECTADO</a> a internet, você foi desconectado as <?php echo $stoptime; ?> pelo motivo: <?php echo $motivodesconect; ?></h4>
<h4>Caso você esteja com problemas de conexão a internet, causada por uma total indisponibilidade do seu serviço, por favor abra um pedido de suporte como 'estou sem internet' </h4>


<form method="post" action="seminternet.php">

                                        <tbody><tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Abrir pedido de suporte como sem internet" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </form>





<br><br>
<a href="../index.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar a pagina inicial</a><br><br>

<?php
exit();
}
else
{
    ?>
<h4>Atualmente, seu roteador está <a style="color:green;">CONECTADO</a> a internet, conexão realizada em <?php echo $starttime; ?></h4>
<?php
}

        






        }



        if($_POST['datadownload'] == 0)
{
    $sql = "SELECT * FROM `problemas` WHERE `firewall` = " . $servidor;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $titulo = $row["titulo"];
            $sobre = $row["sobre"];
            ?>
            <div class="alert alert-danger">
<h2><?php echo $titulo;?> </h2>
<h4><?php echo $sobre; ?> </h4>
                            </div>
            <?php
           
        }
    }

        ?>
        
        
        <div class="col-md-12">
<div class="panel panel-default">
        <h3>Vamos fazer um teste de velocidade?</h3>
        <h4>Lembre-se que entre os horários de 10:00 a 22:00 você pode receber até no mínimo 40% da velocidade contratada de acordo com a Anatel, embora a Data Web utilize 60% como velocidade mínima.</h4>
        <h4>Para que o teste seja efetivo, você precisa está  perto do seu roteador, quanto mais longe do roteador a intensidade do sinal é pior e pode reduzir a velocidade de acesso do seu dispositivo </h4>
        <h4>Para aumentar a área de cobertura do seu roteador entre em contato com nossa equipe técnica na categoria "outros assuntos"</h4>
        <h4>Deseja começar o teste? </h4>
        <br><br>
        <center>
<a href="speedtest" style="width: 150%;
  background-color: #4CAF50;
  color: white;
  padding: 18px 24px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">COMEÇAR</a><br><br>
<center>
  </div>
  </div>
        <?php
}else
{
?>
<h4>Estes são os resultados finais... </h4>
<?php 
$hora = date('H');
if($hora >= 00 && $hora < 10 | $hora > 21)
{
    $velocidademinima = $velocidade - 5;
    echo '<h5> <a style="color:black;">| Você não está no horário de pico e por isso a velocidade minima é de até 99% da velocidade total |</a></h5>';
}else{
    echo '<h5> <a style="color:black;">| Você está no horario de pico da rede e sua velocidade minima é de até 60% da velocidade total |</a></h5>';
}
if($_POST['dataping'] < 12)
{echo '<h5 <a style="color:green;">Você está com uma boa latência'; $errolatencia = "0";} else {echo '<h5 <a style="color:red;">Você está com problemas de alta latência'; $errolatencia = "1";}

if($_POST['datadownload'] > $velocidademinima){echo '<h5 <a style="color:green;">Você está recebendo uma velocidade de Download maior do que o seu minimo'; $errodownload = "0";} else { echo '<h5 <a style="color:red;">Você está recebendo menos do que a sua velocidade minima de Download de ' . $velocidademinima . ' Megas'; $errodownload = "1";}

if($_POST['dataupload'] > $velocidademinima){echo '<h5 <a style="color:green;">Você está recebendo uma velocidade de Upload maior do que o seu minimo'; $erroupload = "0";} else { echo '<h5 <a style="color:red;">Você está recebendo menos do que a sua velocidade minima de Upload de ' . $velocidademinima . ' Megas'; $erroupload = "1";}
$instabilidade = clienteinstavel($usuariopppoe);

if($instabilidade < 5)
{
    echo '<h5 <a style="color:green;">Você não aparenta está  com oscilações na sua internet.</h5>';
}else{
    echo '<h5 <a style="color:red;">Você está  com instabilidade na sua conexão a internet, seu roteador já se reconectou ao servidor ' . $instabilidade . ' vezes.</h5>';
}

if($errolatencia == "1" | $errodownload == "1" | $erroupload == "1" | $instabilidade > 4)
{
    ?>
    <h2>Detectamos um problema na velocidade de sua conexão a internet! </h2>
    <h3>A qualidade do seu serviço não está  satisfatório, isso pode ocorrer por diversos fatores, como problemas no seu roteador, celular, ou sobrecarga em nossa rede.</h3>
    <h3>Você deseja abrir um pedido de ajuda para solucionar seu problema? </h3>

    <form method="post">
    <input type="hidden" name="parte" value="1">
    <input type="hidden" name="ping" value="<?php echo $_POST['dataping']; ?>">
    <input type="hidden" name="download" value="<?php echo $_POST['datadownload']; ?>">
    <input type="hidden" name="upload" value="<?php echo $_POST['dataupload']; ?>">
    <input type="hidden" name="instabilidade" value="<?php echo $instabilidade; ?>">
    <tr>
                                                <td style="padding: 12px 0 0 2px;">
    Deseja acrecentar algo?                                               
                                                </td>
                                            </tr>

                                            <td>

<textarea name="texto" class="form-control" id="texto" rows="3" style="height: 150px; width: 300px;" maxlength="250" placeholder="Adicione informações extras aqui para ajudar o técnico a solucionar o seu problema. (opcional)"></textarea>
</td>


                                        <tr>

                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Abrir pedido de suporte." class="btn btn-primary btn-lg">
                                            </td>
                                        </tr>
                                    </table>
                                </form>



    <?php
}else{
    ?>
    <br>
    <h2>Tudo ok com o seu serviço de conexão a internet </h2>
    <h3>Você está com uma boa latencia e recebendo a sua velocidade de download e upload minimo, também não aparenta está com instabilidade na sua conexão a internet. </h3>
    <h2>Você está com um problema especifico de um site ou aplicativo? </h2>
    <h4>é possivel que seu problema seja causado por uma falha de um aplicativo ou site, como uma sobrecarga no site especifico, uma manutenção, diversos serviços sofrem com problemas de instabilidades incluindo os maiores como Google e Facebook </h4>
    <h4>Você pode ver se o serviço está com problemas utilizando o site Downdetector </h4>
    <a href="https://downdetector.com.br" class="btn btn-primary btn-lg" target="_blank">Acessar Downdetector</a><br><br>
    <a href="../painel.php" class="btn btn-success btn-lg">Voltar a página inicial</a>
    <?php
}



?>

<?php

}



//fim parte 0
}


if($_POST['parte'] == 1)
    {
        if (!is_numeric($_POST['ping']) || !is_numeric($_POST['download']) || !is_numeric($_POST['upload'])  || !is_numeric($_POST['instabilidade'])) {
            exit();
        }

        $texto = $_POST['texto'];
        $texto = sqlinjection($texto);

        $log = "Ping: " . $_POST['ping'] . "ms<br>" . "Download: " . $_POST['download'] . "MB<br>" . "Upload: " . $_POST['upload'] . "MB<br> Cliente se desconectou " . $_POST['instabilidade'] . " vezes no mesmo dia.";
        $importancia = "2";
//nome, titulo do problema, categoria do suporte, log, id do cliente, texto do cliente, se é interno(0) ou externo(id do problema externo), importancia do suporte(1, 2 e 3)
criarsuporte($nome, 'Conexão a internet lenta', '2', $log, $id, $texto, '0', $importancia);
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
echo "Redirecionando...";

    }

    
    



?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
   
    
   
</body>
</html>
