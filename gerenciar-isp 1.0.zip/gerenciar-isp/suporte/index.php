﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
        }
    }
}
else
{
    header('Location: ../login.php');
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <link rel="stylesheet" href="../csspanel/waves.min.css" type="text/css" media="all">


   <link rel="stylesheet" type="text/css" href="../csspanel/widget.css">

   <script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../../index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="../../../exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php
if($_GET['id'] > "1")
{
    $sql = "SELECT * FROM `suporte` WHERE `id` = " . $_GET['id'] . " AND `idcliente` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        //marcar suporte como resolvido pelo cliente
        if($_GET['encerrar'] == "1"){
            $sql = "UPDATE `suporte` SET `status` = '2', `Resposta` = 'problema marcado como resolvido pelo cliente' WHERE `suporte`.`id` = " . $_GET['id'] . ";";
            $result = $conn->query($sql);

            $sql = "UPDATE `agendas` SET `tipo` = NULL, `idtipo` = NULL, `marcado` = NULL WHERE `agendas`.`idtipo` = " . $_GET['id'] . ";";
            $result = $conn->query($sql);
            ?>
            <head>
            <meta http-equiv="refresh" content="0; URL='?id=<?php echo $_GET['id']; ?>'"/>
</head>
            <?php
        }
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $problema = $row["problema"];
            $categoria = $row["categoria"];
            $status = $row["status"];
            $respostacliente = $row["respostacliente"];
            $resposta = $row["Resposta"];
            $atendente = $row["atendente"];


            if($categoria == 1){$categoria = "sem internet";}
            if($categoria == 2){$categoria = "conexão a internet está lenta";}
            if($categoria == 3){$categoria = "problemas de perda de pacotes ou alta latencia";}
            if($categoria == 4){$categoria = "pronlemas relacionado ao pagamento da minha conta";}
            if($categoria == 5){$categoria = "Perguntas";}
            if($categoria == 6){$categoria = "Outros assuntos";}
            if($status == 0){$status = "Aguardando resposta de um tecnico"; }
            if($status == 1){$status = "Um tecnico está analisando seu problema"; }
            if($status == 2){$status = "O tecnico já respondeu ou resolveu seu problema"; $cor = 'style="color:green;"';}
            if($resposta == "problema marcado como resolvido pelo cliente")
            {
                $status = "Você marcou o pedido de suporte como solucionado";
            }

            $sqll = "SELECT * FROM `admins` WHERE `id` = " . $atendente;
    $resultt = $conn->query($sqll);
    
    if ($resultt->num_rows > 0) {
        // output data of each row
        while($roww = $resultt->fetch_assoc()) {
            $tecnico = $roww["nome"];
        }
    }

            ?>
            <div class="col-md-7">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Sobre o pedido de suporte:
                        </div>        
                                      
                                    <div class="panel-body"> 
                    <h4>Seu problema: <?php echo $problema; ?></h4>
                    <h4>Categoria: <?php echo $categoria; ?></h4>
                    <h4 <?php echo $cor; ?>>Status do suporte: <?php echo $status; ?></h4>
                    <?php
                    if(!$respostacliente == "0")
                    {
                    ?>
                    <h4>Sua resposta: <?php echo $respostacliente; ?></h4>
                   <?php
                    }

                   ?>
                </div>
            </div>
                          </div>


                          <div class="col-md-5">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Sobre o técnico
                        </div>        
                                      
                                    <div class="panel-body"> 

                    <?php
                    if($atendente < 1)
                    {
                        if($resposta == "problema marcado como resolvido pelo cliente")
                        {
                            ?>
                            <h3>Você marcou o suporte como solucionado.</h3>
                        <?php
                        }else{
                            ?>
                            <h3>Nenhum técnico atendeu você ainda, iremos atender você o mais rápido possível. </h3>
                            
                            <?php
                        }


                    }else
                    {
                        ?><center>
                        <img class="imagem_artigo" src="../imagens/profile.png" alt="CSS3: Border-radius" style="border-radius: 200px; width: 25%;">
                        <h4><?php echo $tecnico; ?></h4>
                        <div class="alert alert-info">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. <a href="#" class="alert-link">Alert Link</a>.
                            </div>
                            
                        <?php
                    }
                    ?>
                    

                   
                </div>
            </div>
                          </div>
                          
            <?php
            
            
            
        
            

            $sql = "SELECT * FROM `agendas` WHERE `tipo` = 1 AND `idtipo` = " . $_GET['id'];
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $resolvido = $row["resolvido"];
            $array=explode("-",$row["data"]);
            $mes = $array[1];
            $dia = $array[2];
            $arrayy=explode(" ",$dia);
            $dia = $arrayy[0];
            $hora = $arrayy[1];
            $ano = $array[0];
            $horario =  "$dia/$mes/$ano as $hora";

            $array=explode("-",$row["resolvidodata"]);
            $mes = $array[1];
            $dia = $array[2];
            $arrayy=explode(" ",$dia);
            $dia = $arrayy[0];
            $hora = $arrayy[1];
            $ano = $array[0];
            $horarioterminado =  "$dia/$mes/$ano as $hora";
        if(!$resolvido == "1")
        {
        ?>.
        <br><br>
<div class="">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Agendamento do seu suporte
                        </div>
                        <div class="panel-body">
                            <p style="font-size: 25px;">Precisaremos entrar em sua residência para resolver seu problema, por isso o técnico <?php echo $tecnico; ?> agendou uma visita em sua residência para <?php echo $horario; ?>.</p>
                       
                        
                       
                        </div>
                        <div class="panel-footer"  style="font-size: 15px;">
                        É possível que condições externas desfavoráveis faça com que o técnico não cheque na sua casa na hora marcada, lembre-se que o horário é aproximado e não exato.
                        </div>
                    </div>
                </div>

<?php
        }else{
            ?>.
                   <br><br>
<div class="">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            Manutenção realizada com exito
                        </div>
                        <div class="panel-body">
                            <p style="font-size: 25px;">O agendamento do seu suporte as <?php echo $horario; ?> e foi resolvido as <?php echo $horarioterminado; ?></p>
                       
                        
                       
                        </div>
                        <div class="panel-footer"  style="font-size: 15px;">
                        </div>
                    </div>
                </div>
            <?php
        }
        }
    }
if($status == "Aguardando resposta de um tecnico")
{
?>

<div class="col-md-7">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Finalizar pedido de suporte.
                        </div>        
                                      
                                    <div class="panel-body"> 
                    <h4>Se o seu problema já foi solucionado, você pode encerrar o pedido de suporte.</h4>
                    <br>
                    <a href="?id=<?php echo $_GET['id'] ?>&encerrar=1" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Encerrar pedido de suporte.</a>
                                   </div>
            </div>
                          </div>
<?php
}
if($status == "O tecnico já respondeu ou resolveu seu problema" | $status == "Um tecnico está analisando seu problema")
{
?>
<div class="col-md-7">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Abrir uma reclamação sobre o atendimento.
                        </div>        
                                      
                                    <div class="panel-body"> 

<h5>Caso você tenha tido problemas com o atendimento prestado pela Data Web, você podderá abrir uma reclamação. </h5>

<br><br><br>
<a href="#" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Indisponivel no momento.</a><br><br>


                                    </div>
            </div>
                          </div>



<?php
}
?>

        <br><br><br>
<a href="../index.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar a pagina inicial</a><br><br>
        <?php
        
        exit();
        }



    }else
    {
        echo "Não encontrado";
    }
}
else
{

}
?>


<a href="novo.php" class="btn btn-primary btn-lg">Preciso de ajuda!</a>
<br><br>
<div class="panel panel-default">
                        <div class="panel-heading">
                        As suas faturas de internet
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <div id="dataTables-example_wrapper" class="dataTables_wrapper form-inline" role="grid"><div class="row"><div class="col-sm-6"><div class="dataTables_length" id="dataTables-example_length"><label></label></div></div><div class="col-sm-6"><div id="dataTables-example_filter" class="dataTables_filter"></div></div></div><table class="table table-striped table-bordered table-hover dataTable no-footer" id="dataTables-example" aria-describedby="dataTables-example_info">
                                    <thead>
                                        <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column ascending" style="width: 161px;">Categoria</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" style="width: 235px;">Problema</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending" style="width: 137px;">Status</th></tr>
                                    </thead>
                                    <tbody> <?php
                                    $sql = "SELECT * FROM `suporte` WHERE `idcliente` = " . $id . "  ORDER BY `data` DESC";
    $result = $conn->query($sql);
    $temsuportes = "0";
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $temsuportes = "1";
            $problema = $row["problema"];
            $categoria = $row["categoria"];
            $idsuporte = $row["id"];
            $status = $row["status"];
            if($categoria == 1){$categoria = "Estou sem internet";}
            if($categoria == 2){$categoria = "Minha conexão a internet está lenta";}
            if($categoria == 3){$categoria = "Estou com problemas de perda de pacotes ou alta latencia";}
            if($categoria == 4){$categoria = "Estou com pronlemas relacionado ao pagamento da minha conta";}
            if($categoria == 5){$categoria = "Tenho perguntas";}
            if($categoria == 6){$categoria = "Outros assuntos";}
            ?>
       <tr class="gradeA odd">
                                            <td class="sorting_1"><a href="?id=<?php echo $idsuporte; ?>"> <?php echo $categoria; ?> </a></td>
                                            <td class=" "><?php echo $problema; ?></td>
                                            
                                            
                                            <?php
if($status == 0)
{
    ?>
<td><label class="label label-danger">Aguardando...</label></td>
<?php
}
if($status == 1)
{
    ?>
<td><label class="label label-danger">Em analise...</label></td>
<?php
}
if($status == 2)
{
    ?>
<td><label class="label label-success">Resolvido</label></td>
<?php
}
?>
                                        </tr>
       <?php
        }

    } ?>
                                   </tbody>
                                </table><div class="row"><div class="col-sm-6"></div><div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate"></div></div></div></div>
                            </div>
                            
                        </div>
                    </div>


                    <?php

if($temsuportes == "0")
    {
        ?>
        <h6>Você ainda não criou nenhum pedido de suporte, você pode criar um pedido de suporte <a href="suporte.php">Aqui</a> </h6>
        <?php
    }

?>

                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    
    
   
</body>
</html>
