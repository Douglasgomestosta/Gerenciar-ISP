﻿<?php
session_start();
//error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
require '../sistema/FUNCTIONS.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $cep = $row["cep"];
            $ativo = $row["ativo"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
            $velocidade = $row["velocidade"];
            $velocidademinima = $row["velocidademinima"];
        }
    }
    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
            $ssidwifi = $row["ssidwifi"];
           
        }
    }





}
else
{
    header('Location: ../login.php?redirect=suporte');
}

if(empty($_POST['parte']))
{
    $_POST['parte'] = "0";
}
//trocar GET para POST
if($_GET['tipo'] > 0){
    $_POST['tipo'] = $_GET['tipo'];
    $_POST['parte'] = "1";
}
//fim





?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>

<script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php
if($_GET['criado'] == 1)
{
    ?><center>
    <img src="../imagens/ok.webp" width="100">
<h1 style="font-size: 25px; color: black;">Pronto! </h1>
<h3>Seu pedido de suporte já foi registrado no sistema e em breve será respondido </h3>
<a href="index.php">Saiba Mais</a>
    <?php
    exit();
}



//ver se cliente já criou outros suportes
$sql = "SELECT * FROM `suporte` WHERE `status` LIKE '0' AND `idcliente` LIKE '" . $id . "' AND `categoria` LIKE '4' OR `status` LIKE '1' AND `idcliente` LIKE '" . $id . "' AND `categoria` LIKE '4' LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data = $row["data"];
        $idagendamento = $row["id"];
        $array=explode("-",$data);
        $mes = $array[1];
        $dia = $array[2];
        $arrayy=explode(" ",$dia);
        $dia = $arrayy[0];
        $hora = $arrayy[1];
        $arrayy=explode(":",$hora);
        $hora = $arrayy[0] . ":" . $arrayy[1];
        $ano = $array[0];
        $data =  "$dia/$mes/$ano as $hora";
        if($row["data"] == "0")
        {
            $status = "Aguardando atendimento por um técnico.";
        }else{
            $status = "Um técnico está analisando ou resolvendo seu problema.";
        }
        $idsuporte = $row["id"];
?>
<div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Você já tem um pedido de suporte em aberto!
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    
<H3>Você já tem um pedido de suporte aberto em <?php echo $data; ?> com o status de "<?php echo $status; ?>" </h3>
<a href="index.php?id=<?php echo $idsuporte; ?>" class="btn btn-info btn-lg">Ver pedido de suporte.</a>
                                    </div>
                    </div>
                    </div>

<?php
    exit();
    }
}
    //fim cliente já criou outros suportes
if($_POST['parte'] == 0)
{
    $idfatura = $_GET['id'];


  
//caso usuario ainda não tenha selecionado uma fatura
  if(empty($idfatura))
  {

    $sql = "SELECT * FROM `pagamentos` WHERE `idusuario` = " . $id . " ORDER BY `id` DESC LIMIT 6";
$result = $conn->query($sql);

    ?>
    <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading" style="font-size:20px;">
                        Qual das ultimas 6 faturas você está tendo problemas?
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <div class="">



                                    <div class="col-md-4 col-sm-4">
<div class="panel panel-primary">
<div class="panel-heading">Nenhuma das anteriores</div>
<div class="panel-body">
<p>Estou tendo problemas com uma fatura que ainda não existe ou algo do tipo.</p>
</div>
<div class="panel-footer">
<a href="?id=00" class="btn btn-success" style="width: 200px;">Pedir ajuda.</a>                        </div>
</div>
</div>	
								
    <?php
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            
        
//echo "Valor:" . $valor->value . "<br>";
//echo "Status:" . $valor->status . "<br>";
$preco = $row["valor"];
$vencimento = $row["vencimento"];
$status = $row["pago"];
$idfatura = $row["id"];
$array=explode("-",$vencimento);
$mes = $array[1];
$dia = $array[2];
$ano = $array[0];
$vencimento =  "$dia/$mes/$ano";
if(!$row["pago"] == "1"){ 
$cor = "panel panel-warning";
$sobrefatura = '<label class="label label-danger">Não Pago</label>';
//$cor = "panel panel-danger";
}
if($row["vencido"] == "1"){
//$cor = "panel panel-warning";
$cor = "panel panel-danger";
$sobrefatura = '<label class="label label-danger">ATRASADA!</label>';
}
if($row["pago"] == "1") {
$cor = "panel panel-success";
$sobrefatura = '<label class="label label-success">Pago</label>';
}
?>


<div class="col-md-4 col-sm-4">
<div class="<?php echo $cor; ?>">
<div class="panel-heading">R$<?php echo $preco; ?>,00</div>
<div class="panel-body">
<p>Fatura no valor de R$<?php echo $preco; ?>,00 com vencimento em <?php echo $vencimento; ?><br> <?php echo $sobrefatura; ?></p>
</div>
<div class="panel-footer">
<a href="?id=<?php echo $idfatura; ?>" class="btn btn-success" style="width: 200px;">Pedir ajuda.</a>                        </div>
</div>
</div>



<?php

        }
}


?>


			
									

                                </div>
                                    </div>
                    </div>
                    </div>
<?php
    }else{
        if (!is_numeric($idfatura)) {
            exit;
            }
        //caso cliente ainda não tenha selecionado uma fatura
        if($idfatura == "00")
        {
            ?>
            <div class="">
                                  <div class="panel panel-default">
                                    <div class="panel-heading">
                                        Com problemas nessa fatura?
                                    </div>        
                                                  
                                                <div class="panel-body"> 
            
                                                <div class="">
            
                                                <form method="post">
                    <input type="hidden" name="parte" value="1">
                    <input type="hidden" name="idfatura" value="0">
                    
            
            
                
                                                    <h4>Que tipo de problema você está tendo com esse pagamento? </h3>
                                                    <select id="ordenacao" name="tipoproblema">
                                                    <option value="0">Outros problemas.</option>
                                                    </select>
            
                                                    <table class="login-box">
                                                  
                                                    <tbody><tr>
                                                            <td style="padding: 12px 0 0 2px;">
            <h4>Acrescente mais informações sobre o seu problema, seja bastante detalhista para que possamos solucionar seu problema. </h4>                                  
                                                            </td>
                                                        </tr>
                                                      
            
            
            
                                                        <tr><td>
            
                                                        <textarea name="texto" class="form-control" id="texto" rows="3" style="height: 150px; width: 300px;" maxlength="250" placeholder="Adicione informações extras aqui para ajudar o técnico a solucionar o seu problema."></textarea>
                                                        </td>
            
                                                        </tr><tr>
                                                        </tr>
                
                                                        <tr>
                                                        <td>
            
                <h4>Se nossa equipe não conseguir resolver o seu problema de imediato, entraremos em contato com você pelos meios de comunicação disponíveis para conseguimos solucionar o seu problema! </h4>
                </td>
            
                </tr>
            
                                                        <tr>
                
                                                            <td style="padding: 0 0 12px 0;">
                                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                                            </td>
            
            
                                                   <div style="margin-top: 10px;">
                                                        
                                                                    
                                                
            
                                                    </div>
                                                </div>
                                </div>
                                </div>
                       <?php
        }else
        {
        $sql = "SELECT * FROM `pagamentos` WHERE `id` = " . $idfatura . " AND `idusuario` = " . $id ;
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $preco = $row["valor"];
                                            $vencimento = $row["vencimento"];
                                            $status = $row["pago"];
                                            $pagodata = $row["pagodata"];
                                            $idfatura = $row["id"];
                                            $checkout = $row["checkout"];
                                            $checkoutid = $row["checkoutid"];
                                            $descricao = $row["descricao"];
                                            $array=explode("-",$vencimento);
                                            $mes = $array[1];
                                            $dia = $array[2];
                                            $ano = $array[0];
                                            $vencimento =  "$dia/$mes/$ano";
                                            $array=explode("-",$pagodata);
                                            $mes = $array[1];
                                            $dia = $array[2];
                                            $ano = $array[0];
                                            $pagodata =  "$dia/$mes/$ano";
                                            
           ?>
<div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Com problemas nessa fatura?
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <div class="">

                                    <form method="post">
        <input type="hidden" name="parte" value="1">
        <input type="hidden" name="idfatura" value="<?php echo $row['id']; ?>">
        


    
                                        <h4>Que tipo de problema você está tendo com esse pagamento? </h3>
                                        <select id="ordenacao" name="tipoproblema">
                                        <option value="0">Outros problemas.</option>
                                        </select>

                                        <table class="login-box">
                                      
                                        <tbody><tr>
                                                <td style="padding: 12px 0 0 2px;">
<h4>Acrescente mais informações sobre o seu problema, seja bastante detalhista para que possamos solucionar seu problema. </h4>                                  
                                                </td>
                                            </tr>
                                          



                                            <tr><td>

                                            <textarea name="texto" class="form-control" id="texto" rows="3" style="height: 150px; width: 300px;" maxlength="250" placeholder="Adicione informações extras aqui para ajudar o técnico a solucionar o seu problema."></textarea>
                                            </td>

                                            </tr><tr>
                                            </tr>
    
                                            <tr>
                                            <td>

    <h4>Se nossa equipe não conseguir resolver o seu problema de imediato, entraremos em contato com você pelos meios de comunicação disponíveis para conseguimos solucionar o seu problema! </h4>
    </td>

    </tr>

                                            <tr>
    
                                                <td style="padding: 0 0 12px 0;">
                                                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                                </td>


                                       <div style="margin-top: 10px;">
											
														
									

                                        </div>
                                    </div>
                    </div>
                    </div>
           <?php
            }
        }else{
            echo "<h2>Erro: Fatura não foi encontrada </h2>";
        }

    }

    }

}else{
    $texto = sqlinjection($_POST['texto']);
    if (is_numeric($_POST['tipoproblema'])) {}else{ exit();}
    $temtipoproblema = "0";
    if($_POST['tipoproblema'] == "0")
    {
        $problema = "Outros problemas com pagamentos";
        $temtipoproblema = "1";
    }


    if($temtipoproblema == "0"){ $problema = "Problemas com pagamentos";}
    if (is_numeric($_POST['idfatura'])) {}else{ exit();}
    $importancia = "2";
//nome, titulo do problema, categoria do suporte, log, id do cliente, texto do cliente, se é interno(0) ou externo(id do problema externo), importancia do suporte(1, 2 e 3)
//criarsuporte($nome, $problema, '4', '0', $id, $texto, "0", $importancia);
$log = $_POST['idfatura'];

    //nome, titulo do problema, categoria do suporte, log, id do cliente, texto do cliente, se é interno(0) ou externo(id do problema externo), importancia do suporte(1, 2 e 3)
    $criarsuporte = criarsuporte($nome, $problema, '4', $log, $id, $texto, '0', $importancia);
    ?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
}
?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
   
    
   
</body>
</html>
