﻿<?php
session_start();
//error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
require '../sistema/FUNCTIONS.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $cep = $row["cep"];
            $ativo = $row["ativo"];
            $desativado = $row["desativado"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
            $velocidade = $row["velocidade"];
            $velocidademinima = $row["velocidademinima"];
        }
    }
    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
            $ssidwifi = $row["ssidwifi"];
            $servidor = $row["servidor"];
            $rota = $row["rota"];
           
        }
    }


    $sql = "SELECT * FROM `servidores` WHERE `id` = " . $servidor;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $ipservidor = $row["ippublico"];
           
        }
    }



}
else
{
    header('Location: ../login.php?redirect=suporte');
}
if(empty($_POST['parte']))
{
    $_POST['parte'] = "0";
}


//fim
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>

<script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php
if($_GET['criado'] == 1)
{
    ?><center>
    <img src="../imagens/ok.webp" width="100">
<h1 style="font-size: 25px; color: black;">Pronto! </h1>
<h3>Seu pedido de suporte já foi registrado no sistema e em breve será respondido </h3>
<a href="index.php">Saiba Mais</a>
    <?php
    exit();
}

//parte 1
if($_POST['parte'] == "0")
{
    //serviço inativo
    if(!empty($desativado))
    {
        ?>
        <h2>Ops... parece que seu serviço esta inativo</h2>
        <h4>O seu serviço de internet pode ter sido desativado por falta de pagamento, descumprimento de contrato ou a pedido do cliente </h4>
        <h5>Vocẽ pode entrar em contrato conosco pedindo a reativação de seu serviço </h5>
        <br><br>
    <a href="../index.php" style="width: 100%;
      background-color: #4CAF50;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;">Voltar a pagina inicial</a><br><br>
        <?php
        exit();
    }

    //ver se cliente já criou outros suportes
$sql = "SELECT * FROM `suporte` WHERE `status` LIKE '0' AND `idcliente` LIKE '" . $id . "' AND `categoria` LIKE '1' OR `status` LIKE '1' AND `idcliente` LIKE '" . $id . "' AND `categoria` LIKE '1' LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data = $row["data"];
        $idagendamento = $row["id"];
        $array=explode("-",$data);
        $mes = $array[1];
        $dia = $array[2];
        $arrayy=explode(" ",$dia);
        $dia = $arrayy[0];
        $hora = $arrayy[1];
        $arrayy=explode(":",$hora);
        $hora = $arrayy[0] . ":" . $arrayy[1];
        $ano = $array[0];
        $data =  "$dia/$mes/$ano as $hora";
        if($row["data"] == "0")
        {
            $status = "Aguardando atendimento por um técnico.";
        }else{
            $status = "Um técnico está analisando ou resolvendo seu problema.";
        }
        $idsuporte = $row["id"];
?>
<div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Você já tem um pedido de suporte em aberto!
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    
<H3>Você já tem um pedido de suporte aberto em <?php echo $data; ?> com o status de "<?php echo $status; ?>" </h3>
<a href="index.php?id=<?php echo $idsuporte; ?>" class="btn btn-info btn-lg">Ver pedido de suporte.</a>
                                    </div>
                    </div>
                    </div>

<?php
    exit();
    }
}
    //fim cliente já criou outros suportes
            //Ver se usuario está conectado
            require '../sistema/logadopppoe.php'; 
            if($desconectado == 1){
         $conectado = "0";
         if($motivodesconect == "User-Request") {
            if($_GET['conectado'] == "1")
            {} else{
            ?>
            <h2>Que estranho... parece que você foi desconectado por requisição do seu roteador </h2>
            <h4>é possivel que um usuario de sua rede tenha acessado o painel de administração de seu roteador e requisitado que ele se desconecte de nosso sistema, com isso, causando indisponibilidade em seu serviço </h4>
            <h3>Não sabe o que pode ter sido? você ainda pode abrir um pedido de suporte </h3>
            <form method="post" action="?conectado=1">
        <input type="hidden" name="parte" value="1">
        <input type="hidden" name="tipo" value="1">
                                            <tr>
                                                <td style="padding: 0 0 12px 0;">
                                                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                                </td>
                                            </tr>
                                        </table>
                                    </form>
            <?php
            exit();
            }
             $motivodesconect = "Desconectado pelo usuario";
            }
        
        } else
    {
        $conectado = "1";
        if($_GET['conectado'] == "1")
        {} else{
        ?>
        <h2 style="font-size: 25px;">Você está conectado a internet?</h2>
        <h5>Status: <a style="color:green;">CONECTADO</a> Conexão realizada as: <?php echo $starttime; ?> </h5>
    <h4>De acordo com o nosso sistema, você está conectado a internet, mas essa informação pode ser falsa, se você está com sua conexão a internet lenta ou com perda de pacotes/alta latência, use as respectivas categorias para que possamos atender melhor você.</h4>
        <h5>Vocẽ pode saber mais sobre o que pode está causando a o seu problema de conexão em nosso blog ;) </h5>
        <a href="conexaolenta.php" class="btn btn-primary btn-lg">Estou com a minha conexão lenta</a>
        <br><br>
        <a href="pacotelatencia.php" class="btn btn-primary btn-lg">Estou com perda de pacotes ou alta latência</a>
        <h4>Se você acredita que isso é um erro, e que você realmente está sem conexão a internet, você pode ainda assim abrir um pedido de suporte </h4>
        <form method="post" action="?conectado=1">
                                            <tr>
                                                <td style="padding: 0 0 12px 0;">
                                                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                                </td>
                                            </tr>
                                        </table>
                                    </form>
        <?php
   exit();
        }
    }

    // fim ver se usuario está online


    
    //Ver se outros usuarios estão com problemas na rua
    $cont = 0;
    $desconectados = 0;
    $sql = "SELECT * FROM `usuarios` WHERE `cep` LIKE '" . $cep . "' AND `ativo` = 1";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $idcliente = $row["id"];
                $cont = $cont + 1;
    
                $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $idcliente;
                $resultl = $conn->query($sqll);
                
                if ($resultl->num_rows > 0) {
                    // output data of each row
                    while($rowl = $resultl->fetch_assoc()) {
                        $usuariopppoeoutro = $rowl["usuario"];
                        
    
    
                        
                        $sql = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usuariopppoeoutro . "' ORDER BY `acctstarttime` DESC LIMIT 1";
    $resultt = $connradius->query($sql);
    if ($resultt->num_rows > 0) {
        // output data of each row
        while($row = $resultt->fetch_assoc()) {
            $stoptimeoutro = $row["acctstoptime"];
            $motivodesconectoutro = $row["acctterminatecause"];
        }
    }
    if(isset($stoptimeoutro)){ if($usuariopppoeoutro == $usuariopppoe) {} else{
        if("Lost-Service" == $motivodesconectoutro)
        $desconectados = $desconectados + 1;
    }}
    if($desconectados >= 1)
    {
        $externo = "1";
    }
    
    
                    }
                }
    
    
    
    
            }
        }
    //

    $sql = "SELECT * FROM `problemas` WHERE `firewall` = " . $servidor;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $titulo = $row["titulo"];
            $sobre = $row["sobre"];
            $fechado = $row["fechar"];
            if($fechado == "1")
            {
                ?>
                <div class="alert alert-danger">
    <h1><?php echo $titulo;?> </h1>
    <h3><?php echo $sobre; ?> </h3>
                                </div>
                                <h2>Não é necessario abrir um pedido de suporte para solucionar esse problema!</h2>
                                <h3>Você receberá um aviso via e-mail e notificação quando o serviço se normalizar, caso você permaneça sem conexão a internet, por favor abra um novo pedido de suporte. </h3>
                                                <?php
                                exit();
            }else{
                ?>
                <div class="alert alert-danger">
    <h2><?php echo $titulo;?> </h2>
    <h4><?php echo $sobre; ?> </h4>
                                </div>
                <?php                
            }
           
        }
    }
           ?>
           <div class="">
<div class="panel panel-default">
           <h2 style="font-size: 25px;">Vamos criar o seu pedido de suporte?</h2>
           
           
                      <div class="">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Problemas encontrados.
                        </div>        
                                      
                                    <div class="panel-body"> 


                                    <?php
$problemaexterno = "0";
           if($conectado == "0")
           {
            $problema = "1";
               ?>
                       <h5>Atualmente, seu roteador está <a style="color:red;">DESCONECTADO</a> a internet, você foi desconectado as <?php echo $stoptime; ?> pelo motivo: <?php echo $motivodesconect; ?></h5>
    
               <?php
           }


           $instabilidade = clienteinstavel($usuariopppoe);
           if($instabilidade < 5)
           {}else
           {
            $problema = "1";
            ?>
            <h5 style="color:red;">Detectamos que você está com problema de oscilação na conexão, você foi reconectado no servidor <?php echo $vezesconectado; ?> Vezes no mesmo dia </h5>
            <?php
           }


           if($externo == "1")
           {
            $problema = "1";
               ?>
               <h5 style="color:red;">Detectamos que outros clientes em sua rua também estão sofrendo problemas de falta de conexão.</h5>
               <?php
               $problemaexterno = "1";
           }

           $clientesinstaveis = clientesruainstavel($cep);
           if($clientesinstaveis > 1){
            $problema = "1";
            ?>
            <h5 style="color:red;">Detectamos que outros clientes na mesma rua estão com instabilidades.</h5>
            <?php
            $problemaexterno = "1";
           }

if(!$problema == "1"){
    ?>
    <h5 style="color:green;">Maravilhoso! não detectamos nenhum problema no seu serviço de internet, mas se ainda assim você precisa de ajuda, ainda poderá abrir um pedido de suporte </h5>
    <?php
}

?>                   
                </div>
            </div>
                          </div>

 

           <h3>Você deseja abrir um pedido de suporte? </h3>
           <h4>Por favor preencha alguns dados para que possamos abrir um pedido de suporte </h4>
           
           <form method="post">
        <input type="hidden" name="parte" value="1">
        <input type="hidden" name="conectado" value="<?php echo $conectado; ?>">
        <input type="hidden" name="instabilidade" value="<?php echo $instabilidade; ?>">
        <input type="hidden" name="vezesconectado" value="<?php echo $vezesconectado; ?>">
        <input type="hidden" name="motivodesconect" value="<?php echo $motivodesconect; ?>">
        <input type="hidden" name="externo" value="<?php echo $externo; ?>">
        <input type="hidden" name="desconectados" value="<?php echo $desconectados; ?>">
        <input type="hidden" name="clientesinstaveis" value="<?php echo $clientesinstaveis; ?>">
        <input type="hidden" name="problemaexterno" value="<?php echo $problemaexterno; ?>">

    
                                        <table class="login-box">
                                            
                                        
    <select id="ordenacao" name="vento">
                                        <option value="0">Não houve ventos fortes nas ultimas 12 horas</option>
                                        <option value="1">Houve vento forte nas ultimas 12 horas</option>
                                        </select>
    <br><br>
    <select id="ordenacao" name="luz">
                                        <option value="0">Não houve quedas de energia nas ultimas 12 horas</option>
                                        <option value="1">Houve quedas de energia nas ultimas 12 horas</option>
                                        </select>
    <br><br>
    <select id="ordenacao" name="raios">
                                        <option value="0">Não houve raios nas ultimas 12 horas</option>
                                        <option value="1">Houve raios nas ultimas 12 horas</option>
                                        </select>
    
    
                                        <tr>
                                                <td style="padding: 12px 0 0 2px;">
    Deseja acrecentar algo?                                               
                                                </td>
                                            </tr>
                                          



                                            <td>

                                            <textarea name="texto" class="form-control" id="texto" rows="3" style="height: 150px; width: 300px;" maxlength="250" placeholder="Adicione informações extras aqui para ajudar o técnico a solucionar o seu problema."></textarea>
                                            </td>

                                            <tr>
                                            </tr>
    <br><br>
    
                                            <tr>
    
                                                <td style="padding: 0 0 12px 0;">
                                                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                                </td>
                                            </tr>
                                        </table>
                                    </form>
    </div>
    </div>
           <?php
}


//se o problema é externo ou interno cria um agendamento
if($_POST['parte'] == 1)
{
if($_POST['problemaexterno'] == "1")
{
    //é problema externo
    ?>
    <center>
    <div class="">
<div class="panel panel-default">
<div class="panel-heading">
Detectamos que seu problema é externo!
</div>
<div class="panel-body">
<h2>Detectamos que seu problema é externo.</h2>
<h3>Por esse mótivo não iremos agendar uma visita em sua casa, normalmente os pedidos de suporte marcados como externos são os primeiros a serem atendidos pela nossa equipe técnica.


<form method="post">
        <input type="hidden" name="parte" value="3">
        <input type="hidden" name="conectado" value="<?php echo $_POST['conectado']; ?>">
        <input type="hidden" name="instabilidade" value="<?php echo $_POST['instabilidade']; ?>">
        <input type="hidden" name="vezesconectado" value="<?php echo $_POST['vezesconectado']; ?>">
        <input type="hidden" name="motivodesconect" value="<?php echo $_POST['motivodesconect']; ?>">
        <input type="hidden" name="externo" value="<?php echo $_POST['externo']; ?>">
        <input type="hidden" name="desconectados" value="<?php echo $_POST['desconectados']; ?>">
        <input type="hidden" name="clientesinstaveis" value="<?php echo $_POST['clientesinstaveis']; ?>">
        <input type="hidden" name="problemaexterno" value="<?php echo $problemaexterno; ?>">

        <input type="hidden" name="vento" value="<?php echo $_POST['vento']; ?>">
        <input type="hidden" name="luz" value="<?php echo $_POST['luz']; ?>">
        <input type="hidden" name="raios" value="<?php echo $_POST['raios']; ?>">
        <input type="hidden" name="interno" value="0">
    
                                        <table class="login-box">
                                            
  
    
    
                                      
    <br><br>
    
                                            <tr>
    
                                                <td style="padding: 0 0 12px 0;">
                                                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                                </td>
                                            </tr>
                                        </table>
                                    </form>



</div>
</div>
</div>

    <?php
}else{
    //Não é problema externo
    ?>
        <center>
    <div class="">
<div class="panel panel-default">
<div class="panel-heading">
Seu problema é interno!
</div>
<div class="panel-body">
<h2>Detectamos que seu problema possivelmente é interno.</h2>
<h3>Por esse mótivo, vamos agendar uma visita técnica em sua casa para que possamos resolver o problema. </h3>
<?php
$hora = date('H') + 2;
$data = date("Y-m-d");
$sql = "SELECT * FROM `agendas` WHERE `data` > '" . $data . " " . $hora . ":00:00' AND `marcado` IS NULL";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $idadmin = $row["idadmin"];
        $data = $row["data"];
        $idagendamento = $row["id"];
        $array=explode("-",$data);
        $mes = $array[1];
        $dia = $array[2];
        $arrayy=explode(" ",$dia);
        $dia = $arrayy[0];
        $hora = $arrayy[1];
        $arrayy=explode(":",$hora);
        $hora = $arrayy[0] . ":" . $arrayy[1];
        $ano = $array[0];
        $data =  "$dia/$mes/$ano as $hora";


        $sqll = "SELECT * FROM `admins` WHERE `id` = " . $idadmin;
$resultt = $conn->query($sqll);
if ($resultt->num_rows > 0) {
    // output data of each row
    while($roww = $resultt->fetch_assoc()) {
$nomeadmin = $roww["nome"];
    }
}
       ?>
       <div class="col-md-4 col-sm-4">
<div class="panel panel-primary">
<div class="panel-heading"><?php echo $data; ?> Horas</div>
<div class="panel-body">
<p>Agendamento para <?php echo $data; ?> pelo técnico <?php echo $nomeadmin; ?></p>
</div>
<div class="panel-footer">
<form method="post">
        <input type="hidden" name="parte" value="2">
        <input type="hidden" name="conectado" value="<?php echo $_POST['conectado']; ?>">
        <input type="hidden" name="instabilidade" value="<?php echo $_POST['instabilidade']; ?>">
        <input type="hidden" name="vezesconectado" value="<?php echo $_POST['vezesconectado']; ?>">
        <input type="hidden" name="motivodesconect" value="<?php echo $_POST['motivodesconect']; ?>">
        <input type="hidden" name="externo" value="<?php echo $_POST['externo']; ?>">
        <input type="hidden" name="desconectados" value="<?php echo $_POST['desconectados']; ?>">
        <input type="hidden" name="clientesinstaveis" value="<?php echo $_POST['clientesinstaveis']; ?>">
        <input type="hidden" name="problemaexterno" value="<?php echo $problemaexterno; ?>">

        <input type="hidden" name="vento" value="<?php echo $_POST['vento']; ?>">
        <input type="hidden" name="luz" value="<?php echo $_POST['luz']; ?>">
        <input type="hidden" name="raios" value="<?php echo $_POST['raios']; ?>">
        <input type="hidden" name="interno" value="1">

        <input type="hidden" name="idagendamento" value="<?php echo $idagendamento; ?>">
    

                                                    <input tabindex="3" type="submit" value="Marcar horário." class="btn btn-success" style="width: 200px;">

                                    </form>



                               </div>
</div>
</div>
       <?php
    }

    ?>
     <div class="col-md-4 col-sm-4">
<div class="panel panel-primary">
<div class="panel-heading">Nenhuma das anteriores</div>
<div class="panel-body">
<p>Não quero nenhum dos horários anteriores</p>
<h6>Entraremos em contato com você para marcar um horário</h6>
</div>
<div class="panel-footer">
<form method="post">
        <input type="hidden" name="parte" value="3">
        <input type="hidden" name="conectado" value="<?php echo $_POST['conectado']; ?>">
        <input type="hidden" name="instabilidade" value="<?php echo $_POST['instabilidade']; ?>">
        <input type="hidden" name="vezesconectado" value="<?php echo $_POST['vezesconectado']; ?>">
        <input type="hidden" name="motivodesconect" value="<?php echo $_POST['motivodesconect']; ?>">
        <input type="hidden" name="externo" value="<?php echo $_POST['externo']; ?>">
        <input type="hidden" name="desconectados" value="<?php echo $_POST['desconectados']; ?>">
        <input type="hidden" name="clientesinstaveis" value="<?php echo $_POST['clientesinstaveis']; ?>">
        <input type="hidden" name="problemaexterno" value="<?php echo $problemaexterno; ?>">

        <input type="hidden" name="vento" value="<?php echo $_POST['vento']; ?>">
        <input type="hidden" name="luz" value="<?php echo $_POST['luz']; ?>">
        <input type="hidden" name="raios" value="<?php echo $_POST['raios']; ?>">
        <input type="hidden" name="interno" value="1">

        <input type="hidden" name="idagendamento" value="0">
    
    

                                                    <input tabindex="3" type="submit" value="Continuar." class="btn btn-success" style="width: 200px;">

                                    </form>



                               </div>
</div>
</div>
    <?php
}else{
    //não achou nenhum agendamento disponivel
    ?>
    <br>
    <div class="">
<div class="panel panel-default">
<div class="panel-heading">
Não existem horários agendados disponíveis
</div>
<div class="panel-body">

<h3>Infelizmente não existem horários agendados para os proximos dias.</h3>
<h4>Iremos abrir o seu pedido de suporte e assim que possivel, iremos ligar para você para agendar o seu suporte.</h4>

<form method="post">
        <input type="hidden" name="parte" value="3">
        <input type="hidden" name="conectado" value="<?php echo $_POST['conectado']; ?>">
        <input type="hidden" name="instabilidade" value="<?php echo $_POST['instabilidade']; ?>">
        <input type="hidden" name="vezesconectado" value="<?php echo $_POST['vezesconectado']; ?>">
        <input type="hidden" name="motivodesconect" value="<?php echo $_POST['motivodesconect']; ?>">
        <input type="hidden" name="externo" value="<?php echo $_POST['externo']; ?>">
        <input type="hidden" name="desconectados" value="<?php echo $_POST['desconectados']; ?>">
        <input type="hidden" name="clientesinstaveis" value="<?php echo $_POST['clientesinstaveis']; ?>">
        <input type="hidden" name="problemaexterno" value="<?php echo $problemaexterno; ?>">

        <input type="hidden" name="vento" value="<?php echo $_POST['vento']; ?>">
        <input type="hidden" name="luz" value="<?php echo $_POST['luz']; ?>">
        <input type="hidden" name="raios" value="<?php echo $_POST['raios']; ?>">
        <input type="hidden" name="interno" value="1">

        <input type="hidden" name="idagendamento" value="0">
    

                                                    <input tabindex="3" type="submit" value="Confirmar." class="btn btn-success" style="width: 200px;">

                                    </form>

</div>
</div>
</div>
    <?php
}
?>


</div>
</div>
</div>
    <?php
}

}

//confirmar agendamento
if($_POST['parte'] == 2)
{
    if (is_numeric($_POST['idagendamento'])) {}else{ exit();}
    $sql = "SELECT * FROM `agendas` WHERE `id` = " . $_POST['idagendamento'] . " AND `marcado` IS NULL";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $idadmin = $row["idadmin"];
        $data = $row["data"];
        $idagendamento = $row["id"];
        $array=explode("-",$data);
        $mes = $array[1];
        $dia = $array[2];
        $arrayy=explode(" ",$dia);
        $dia = $arrayy[0];
        $hora = $arrayy[1];
        $arrayy=explode(":",$hora);
        $hora = $arrayy[0] . ":" . $arrayy[1];
        $ano = $array[0];
        $data =  "$dia/$mes/$ano as $hora";
        $sqll = "SELECT * FROM `admins` WHERE `id` = " . $idadmin;
$resultt = $conn->query($sqll);
if ($resultt->num_rows > 0) {
    // output data of each row
    while($roww = $resultt->fetch_assoc()) {
$nomeadmin = $roww["nome"];
    }
}
    }
}
?>
<div class="">
<div class="panel panel-default">
<div class="panel-heading">
Agendamento de horário.
</div>
<div class="panel-body">
<h3>Você deseja agendar esse horário? </h3>
<h4>Horário: <?php echo $data; ?></h4>
<h4>Técnico responsavel pelo atendimento: <?php echo $nomeadmin; ?> </h4>
<h4>Lembre-se que é possível que o técnico se atrase em até 15 minutos por causa de Trânsito ou serviços que tenham demorado mais que o previsto, o técnico também pode agendar o suporte para outro dia nesses casos.</h4>
<form method="post">
        <input type="hidden" name="parte" value="3">
        <input type="hidden" name="conectado" value="<?php echo $_POST['conectado']; ?>">
        <input type="hidden" name="instabilidade" value="<?php echo $_POST['instabilidade']; ?>">
        <input type="hidden" name="vezesconectado" value="<?php echo $_POST['vezesconectado']; ?>">
        <input type="hidden" name="motivodesconect" value="<?php echo $_POST['motivodesconect']; ?>">
        <input type="hidden" name="externo" value="<?php echo $_POST['externo']; ?>">
        <input type="hidden" name="desconectados" value="<?php echo $_POST['desconectados']; ?>">
        <input type="hidden" name="clientesinstaveis" value="<?php echo $_POST['clientesinstaveis']; ?>">
        <input type="hidden" name="problemaexterno" value="<?php echo $problemaexterno; ?>">

        <input type="hidden" name="vento" value="<?php echo $_POST['vento']; ?>">
        <input type="hidden" name="luz" value="<?php echo $_POST['luz']; ?>">
        <input type="hidden" name="raios" value="<?php echo $_POST['raios']; ?>">
        <input type="hidden" name="interno" value="1">

        <input type="hidden" name="idagendamento" value="<?php echo $idagendamento; ?>">
    

                                                    <input tabindex="3" type="submit" value="Confirmar!" class="btn btn-success" style="width: 300px;">

                                    </form>


</div>
</div>
</div>
</div>
<?php
}

//enviar dados
if($_POST['parte'] == 3)
{
    $importancia = "2";
    if($_POST['conectado'] == "1"){$conectado = "Usuario PPPOE Conectado";} else {$conectado = "Usuario PPPOE Desconectado";}
    if($_POST['instabilidade'] == "1"){$instabilidade = "Usuario com instabilidade";} else {$instabilidade = "Sem instabilidade detectada";}
    if($_POST['externo'] == "1"){$externo = "Problema possivelmente externo, Outros " . $desconectados . " Clientes desconectados";} else {$externo = "Aparentemente não há outros clientes desconectados";}

    if (is_numeric($_POST['vezesconectado'])) {$vezesconectado = $_POST['vezesconectado'];} else {$vezesconectado = "0";}
    if (is_numeric($_POST['desconectados'])) {$desconectados = $_POST['desconectados'];} else {$desconectados = "0";}


    if (strpos($_POST['motivodesconect'], '"') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], "'") !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], ';') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], '*') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], '`') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], '=') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if(strlen($_POST['motivodesconect']) > 50) {echo "Houve um erro! tente novamente"; exit();}
$motivodesconect = $_POST['motivodesconect'];

if($_POST['vento'] == "1"){$vento = "Usuario relatou vento";} else {$vento = "Usuario não relatou vento";}
if($_POST['luz'] == "1"){$luz = "Usuario relatou Falta de luz nas ultimas 12 horas";} else {$luz = "Usuario não relatou falta de luz nas ultimas 12 horas";}
if($_POST['raios'] == "1"){$raios = "Usuario relatou raios";} else {$raios = "Usuario não relatou raios";}
if (is_numeric($_POST['clientesinstaveis'])) {}else{ exit();}
$clientesinstaveis = $_POST['clientesinstaveis'];
$log = $conectado . "<br>" . $instabilidade . "<br>" . $vezesconectado . " vezes conectado no mesmo dia <br>Motivo da desconexão: " . $motivodesconect . "<br> " . $externo . "<br>" . $vento . "<br>" . $luz . "<br>" . $raios . "<br>Outros clientes instaveis na rua: " . $clientesinstaveis;


    $texto = $_POST['texto'];
    if (strpos($_POST['texto'], '"') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], "'") !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], ';') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '*') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '`') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '=') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if(strlen($_POST['texto']) > 100) {echo "O seu texto pode ter no maximo 100 caracteres"; exit();}
if($_POST['interno'] == "1"){
//problema interno
if($_POST['idagendamento'] > 0)
{
    
    //tem agendamento
    if (is_numeric($_POST['idagendamento'])) {}else{ exit();}
    $sql = "SELECT * FROM `agendas` WHERE `id` = " . $_POST['idagendamento'] . " AND `marcado` IS NULL";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
        }
    }else{ echo "Esse horário não está mais disponivel, tente novamente com outro horário.";exit();}
//nome, titulo do problema, categoria do suporte, log, id do cliente, texto do cliente, se é interno(1) ou externo(0), importancia do suporte(1, 2 e 3)
    $criarsuporte = criarsuporte($nome, 'Sem conexão a internet', '1', $log, $id, $texto, "0", $importancia);
    $sql = "SELECT * FROM `suporte` WHERE `categoria` LIKE '1' AND `idcliente` LIKE '" . $id . "' ORDER BY `id` DESC LIMIT 1";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {$idsuporte = $row['id'];}}
        $sql = "UPDATE `agendas` SET `tipo` = '1', `idtipo` = '" . $idsuporte . "', `marcado` = '1' WHERE `agendas`.`id` = " . $_POST['idagendamento'] .";";
        if ($conn->query($sql) === TRUE) {
          //return "1";
        } else {
         // return $conn->error;
        }


}else{
    //não tem agendamento
//nome, titulo do problema, categoria do suporte, log, id do cliente, texto do cliente, se é interno(0) ou externo(id do problema externo), importancia do suporte(1, 2 e 3)
    $criarsuporte = criarsuporte($nome, 'Sem conexão a internet', '1', $log, $id, $texto, "0", $importancia);
}
}else{
//problema externo
$sql = "SELECT * FROM `problemasexternos` WHERE `rota` = " . $rota . " AND `datasolucionado` IS NULL ORDER BY `datasolucionado` DESC LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $idexterno = $row['id'];}
    }else{
$idexterno = "1";
$sql = "INSERT INTO `problemasexternos` (`id`, `rota`, `data`, `datasolucionado`) VALUES (NULL, '" . $rota . "', CURRENT_TIMESTAMP, NULL);";
$result = $conn->query($sql);
$denovo = "1";    
}
if($denovo == "1"){
    $sql = "SELECT * FROM `problemasexternos` WHERE `rota` = " . $rota . " AND `datasolucionado` IS NULL ORDER BY `datasolucionado` DESC LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $idexterno = $row['id'];}
    }
}
    //nome, titulo do problema, categoria do suporte, log, id do cliente, texto do cliente, se é interno(0) ou externo(id do problema externo), importancia do suporte(1, 2 e 3)
$criarsuporte = criarsuporte($nome, 'Sem conexão a internet', '1', $log, $id, $texto, $idexterno, $importancia);
}

//ver se o suporte foi criado corretamente
if($criarsuporte == "1")
{
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
echo "Redirecionando...";
}else{
    echo "Ocorreu um erro, não conseguimos abrir seu pedido de suporte";
    echo "DEBUG: " . $criarsuporte;
}
}
?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
   
    
   
</body>
</html>
