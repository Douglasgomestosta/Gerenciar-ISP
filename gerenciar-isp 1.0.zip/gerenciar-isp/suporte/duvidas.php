﻿<?php
session_start();
//error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
require '../sistema/FUNCTIONS.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $cep = $row["cep"];
            $ativo = $row["ativo"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
            $velocidade = $row["velocidade"];
            $velocidademinima = $row["velocidademinima"];
        }
    }
    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
            $ssidwifi = $row["ssidwifi"];
           
        }
    }





}
else
{
    header('Location: ../login.php?redirect=suporte');
}

if(empty($_POST['parte']))
{
    $_POST['parte'] = "0";
}
//trocar GET para POST
if($_GET['tipo'] > 0){
    $_POST['tipo'] = $_GET['tipo'];
    $_POST['parte'] = "1";
}
//fim
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>

<script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php
if($_GET['criado'] == 1)
{
    ?><center>
    <img src="../imagens/ok.webp" width="100">
<h1 style="font-size: 25px; color: black;">Pronto! </h1>
<h3>Seu pedido de suporte já foi registrado no sistema e em breve será respondido </h3>
<a href="index.php">Saiba Mais</a>
    <?php
    exit();
}
if($_POST['parte'] == 0)
{
    ?>
<h3>Temos uma página de perguntas frequentes em nosso site, talvez a sua dúvida já esteja respondida por lá. </h3>
<a href="http://datawebtelecom.site/ufaqs/" class="btn btn-primary btn-lg" target="_blank">Ver perguntas frequentes</a>
<br>
<h3>Não achou o que queria nas perguntas frequentes? entre em contato conosco</h3>
        <form method="post">
<input type="hidden" name="parte" value="2">
<input type="hidden" name="tipo" value="5">
                                    <table class="login-box">
                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                               Escreva sua dúvida abaixo
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>

                                            <textarea name="duvida" class="form-control" id="duvida" rows="3"  style="height: 150px; width: 300px;"  maxlength="250" minlength="25"></textarea>
                                            </td>
                                        </tr>
                                        
                                        
                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>

    <?php
}else{
    $texto = sqlinjection($_POST['duvida']);
    $importancia = "2";
//nome, titulo do problema, categoria do suporte, log, id do cliente, texto do cliente, se é interno(0) ou externo(id do problema externo), importancia do suporte(1, 2 e 3)

    criarsuporte($nome, 'Estou com dúvidas', '5', '0', $id, $texto, "0", $importancia);
    ?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
}
?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
   
    
   
</body>
</html>
