﻿<?php
session_start();
//error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
require '../sistema/FUNCTIONS.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $cep = $row["cep"];
            $ativo = $row["ativo"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
            $velocidade = $row["velocidade"];
            $velocidademinima = $row["velocidademinima"];
        }
    }
    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
            $ssidwifi = $row["ssidwifi"];
            $servidor = $row["servidor"];
           
        }
    }





}
else
{
    header('Location: ../login.php?redirect=suporte');
}
if(empty($_POST['parte']))
{
    $_POST['parte'] = "0";
}


//fim
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>

<script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php
if($_GET['criado'] == 1)
{
    ?><center>
    <img src="../imagens/ok.webp" width="100">
<h1 style="font-size: 25px; color: black;">Pronto! </h1>
<h3>Seu pedido de suporte já foi registrado no sistema e em breve será respondido </h3>
<a href="index.php">Saiba Mais</a>
    <?php
    exit();
}

//parte 1
if($_POST['parte'] == "0")
{
    if($ativo == 0)
    {
        ?>
        <h2>Ops... parece que seu serviço esta inativo</h2>
        <h4>O seu serviço de internet pode ter sido desativado por falta de pagamento, descumprimento de contrato ou a pedido do cliente </h4>
        <h5>Vocẽ pode entrar em contrato conosco pedindo a reativação de seu serviço </h5>
        <br><br>
    <a href="../index.php" style="width: 100%;
      background-color: #4CAF50;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;">Voltar a pagina inicial</a><br><br>
        <?php
        exit();
    }
            //Ver se usuario está conectado
            require '../sistema/logadopppoe.php'; 
            if($desconectado == 1){
         $conectado = "0";
         if($motivodesconect == "User-Request") {
            if($_GET['conectado'] == "1")
            {} else{
            ?>
            <h2>Que estranho... parece que você foi desconectado por requisição do seu roteador </h2>
            <h4>é possivel que um usuario de sua rede tenha acessado o painel de administração de seu roteador e requisitado que ele se desconecte de nosso sistema, com isso, causando indisponibilidade em seu serviço </h4>
            <h3>Não sabe o que pode ter sido? você ainda pode abrir um pedido de suporte </h3>
            <form method="post" action="?conectado=1">
        <input type="hidden" name="parte" value="1">
        <input type="hidden" name="tipo" value="1">
                                            <tr>
                                                <td style="padding: 0 0 12px 0;">
                                                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                                </td>
                                            </tr>
                                        </table>
                                    </form>
            <?php
            exit();
            }
             $motivodesconect = "Desconectado pelo usuario";
            }
        
        } else
    {
        $conectado = "1";
        if($_GET['conectado'] == "1")
        {} else{
        ?>
        <h2 style="font-size: 25px;">Você está conectado a internet?</h2>
        <h5>Status: <a style="color:green;">CONECTADO</a> Conexão realizada as: <?php echo $starttime; ?> </h5>
    <h4>De acordo com o nosso sistema, você está conectado a internet, mas essa informação pode ser falsa, se você está com sua conexão a internet lenta ou com perda de pacotes/alta latência, use as respectivas categorias para que possamos atender melhor você.</h4>
        <h5>Vocẽ pode saber mais sobre o que pode está causando a o seu problema de conexão em nosso blog ;) </h5>
        <a href="conexaolenta.php" class="btn btn-primary btn-lg">Estou com a minha conexão lenta</a>
        <br><br>
        <a href="pacotelatencia.php" class="btn btn-primary btn-lg">Estou com perda de pacotes ou alta latência</a>
        <h4>Se você acredita que isso é um erro, e que você realmente está sem conexão a internet, você pode ainda assim abrir um pedido de suporte </h4>
        <form method="post" action="?conectado=1">
                                            <tr>
                                                <td style="padding: 0 0 12px 0;">
                                                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                                </td>
                                            </tr>
                                        </table>
                                    </form>
        <?php
   exit();
        }
    }

    // fim ver se usuario está online


    
    //Ver se outros usuarios estão com problemas na rua
    $cont = 0;
    $desconectados = 0;
    $sql = "SELECT * FROM `usuarios` WHERE `cep` LIKE '" . $cep . "' AND `ativo` = 1";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $idcliente = $row["id"];
                $cont = $cont + 1;
    
                $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $idcliente;
                $resultl = $conn->query($sqll);
                
                if ($resultl->num_rows > 0) {
                    // output data of each row
                    while($rowl = $resultl->fetch_assoc()) {
                        $usuariopppoeoutro = $rowl["usuario"];
                        
    
    
                        
                        $sql = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usuariopppoeoutro . "' ORDER BY `acctstarttime` DESC LIMIT 1";
    $resultt = $connradius->query($sql);
    if ($resultt->num_rows > 0) {
        // output data of each row
        while($row = $resultt->fetch_assoc()) {
            $stoptimeoutro = $row["acctstoptime"];
            $motivodesconectoutro = $row["acctterminatecause"];
        }
    }
    if(isset($stoptimeoutro)){ if($usuariopppoeoutro == $usuariopppoe) {} else{
        if("Lost-Service" == $motivodesconectoutro)
        $desconectados = $desconectados + 1;
    }}
    if($desconectados >= 1)
    {
        $externo = "1";
    }
    
    
                    }
                }
    
    
    
    
            }
        }
    //

    $sql = "SELECT * FROM `problemas` WHERE `firewall` = " . $servidor;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $titulo = $row["titulo"];
            $sobre = $row["sobre"];
            ?>
            <div class="alert alert-danger">
<h2><?php echo $titulo;?> </h2>
<h4><?php echo $sobre; ?> </h4>
                            </div>
            <?php
           
        }
    }
           ?>
           <div class="col-md-12">
<div class="panel panel-default">
           <h2 style="font-size: 25px;">Vamos criar o seu pedido de suporte?</h2>
           <h3 style="font-size: 19px;">Diversos fatores podem fazer a sua internet ficar indisponivel, como rompimento de cabo em poste, manutenção, até mesmo problemas dentro da sua propria casa, você pode ver nosso post que explica sobre tudo o que pode fazer sua internet ficar lenta ou fora do ar ;) </h3>
                      <br><h4>Antes de abrir um pedido de suporte por indisponibilidade, por favor, experimente reinciar seu roteador</h4>
           
           
                      <div class="">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Problemas encontrados.
                        </div>        
                                      
                                    <div class="panel-body"> 


                                    <?php
           $pingservidor = servidorping("192.168.0.1008");
           if($pingservidor == "0")
           {
               ?>
        <h6 style="color:red;">Não conseguimos nos comunicar com o servidor ao qual você está conectado! caso o mesmo esteja com problemas, é provavel que nossa equipe JÁ esteja ciente e solucionando o problema.</h6>

               <?php
           }
           if($conectado == "0")
           {
               ?>
                       <h6>Atualmente, seu roteador está <a style="color:red;">DESCONECTADO</a> a internet, você foi desconectado as <?php echo $stoptime; ?> pelo motivo: <?php echo $motivodesconect; ?></h6>
    
               <?php
           }


           $instabilidade = clienteinstavel($usuariopppoe);
           if($instabilidade < 5)
           {}else
           {
            ?>
            <h6 style="color:red;">Detectamos que você está com problema de oscilação na conexão, você foi reconectado no servidor <?php echo $vezesconectado; ?> Vezes no mesmo dia </h6>
            <?php
           }


           if($externo == "1")
           {
               ?>
               <h6 style="color:red;">Detectamos que outros clientes em sua rua também estão sofrendo problemas de falta de conexão.</h6>
               <?php
           }




?>                   
                </div>
            </div>
                          </div>

           
           <?php

           if($conectado == "0")
           {
               ?>
                       <h6>Atualmente, seu roteador está <a style="color:red;">DESCONECTADO</a> a internet, você foi desconectado as <?php echo $stoptime; ?> pelo motivo: <?php echo $motivodesconect; ?></h6>
    
               <?php
           }else{
            ?>
            <h6 style="color:green;">Seu roteador aparenta está conectado a internet</h6>
            <?php   
           }
           //ver se usuario está com instabilidade
           $instabilidade = clienteinstavel($usuariopppoe);

           if($instabilidade < 5)
           {
            ?>
            <h6 style="color:green;">Você não aparenta ter problemas de oscilações de internet.</h6>
            <?php
           }else
           {
            ?>
            <h6 style="color:red;">Detectamos que você está com problema de oscilação na conexão, você foi reconectado no servidor <?php echo $vezesconectado; ?> Vezes no mesmo dia </h6>
            <?php
           }
    
           if($externo == "1")
           {
               ?>
               <h6 style="color:red;">Detectamos que outros clientes em sua rua também estão sofrendo problemas de falta de conexão.</h6>
               <?php
           }else{
            ?>
            <h6 style="color:green;">Não detectamos outros usuarios com problemas de conexão em sua rua</h6>
            <?php
           }
           ?>
           <h3>Você deseja abrir um pedido de suporte? </h3>
           <h4>Por favor preencha alguns dados para que possamos abrir um pedido de suporte </h4>
           
           <form method="post">
        <input type="hidden" name="parte" value="1">
        <input type="hidden" name="conectado" value="<?php echo $conectado; ?>">
        <input type="hidden" name="instabilidade" value="<?php echo $instabilidade; ?>">
        <input type="hidden" name="vezesconectado" value="<?php echo $vezesconectado; ?>">
        <input type="hidden" name="motivodesconect" value="<?php echo $motivodesconect; ?>">
        <input type="hidden" name="externo" value="<?php echo $externo; ?>">
        <input type="hidden" name="desconectados" value="<?php echo $desconectados; ?>">
    
    
                                        <table class="login-box">
                                            
                                        
    <select id="ordenacao" name="vento">
                                        <option value="0">Não houve ventos fortes nas ultimas 12 horas</option>
                                        <option value="1">Houve vento forte nas ultimas 12 horas</option>
                                        </select>
    <br><br>
    <select id="ordenacao" name="luz">
                                        <option value="0">Não houve quedas de energia nas ultimas 12 horas</option>
                                        <option value="1">Houve quedas de energia nas ultimas 12 horas</option>
                                        </select>
    <br><br>
    <select id="ordenacao" name="raios">
                                        <option value="0">Não houve raios nas ultimas 12 horas</option>
                                        <option value="1">Houve raios nas ultimas 12 horas</option>
                                        </select>
    
    
                                        <tr>
                                                <td style="padding: 12px 0 0 2px;">
    Deseja acrecentar algo?                                               
                                                </td>
                                            </tr>
                                          



                                            <td>

                                            <textarea name="texto" class="form-control" id="texto" rows="3" style="height: 150px; width: 300px;" maxlength="250" placeholder="Adicione informações extras aqui para ajudar o técnico a solucionar o seu problema."></textarea>
                                            </td>

                                            <tr>
                                            </tr>
    <br><br>
    
                                            <tr>
    
                                                <td style="padding: 0 0 12px 0;">
                                                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                                </td>
                                            </tr>
                                        </table>
                                    </form>
    </div>
    </div>
           <?php
}

//categoria sem internet
if($_POST['parte'] == 1)
{
    if($_POST['conectado'] == "1"){$conectado = "Usuario PPPOE Conectado";} else {$conectado = "Usuario PPPOE Desconectado";}
    if($_POST['instabilidade'] == "1"){$instabilidade = "Usuario com instabilidade";} else {$instabilidade = "Sem instabilidade detectada";}
    if($_POST['externo'] == "1"){$externo = "Problema possivelmente extero, Outros " . $desconectados . " Clientes desconectados";} else {$externo = "Aparentemente não há outros clientes desconectados";}

    if (is_numeric($_POST['vezesconectado'])) {$vezesconectado = $_POST['vezesconectado'];} else {$vezesconectado = "0";}
    if (is_numeric($_POST['desconectados'])) {$desconectados = $_POST['desconectados'];} else {$desconectados = "0";}


    if (strpos($_POST['motivodesconect'], '"') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], "'") !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], ';') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], '*') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], '`') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], '=') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if(strlen($_POST['motivodesconect']) > 50) {echo "Houve um erro! tente novamente"; exit();}
$motivodesconect = $_POST['motivodesconect'];

if($_POST['vento'] == "1"){$vento = "Usuario relatou vento";} else {$vento = "Usuario não relatou vento";}
if($_POST['luz'] == "1"){$luz = "Usuario relatou Falta de luz nas ultimas 12 horas";} else {$luz = "Usuario não relatou falta de luz nas ultimas 12 horas";}
if($_POST['raios'] == "1"){$raios = "Usuario relatou raios";} else {$raios = "Usuario não relatou raios";}


$log = $conectado . "<br>" . $instabilidade . "<br>" . $vezesconectado . " vezes conectado no mesmo dia <br>Motivo da desconexão: " . $motivodesconect . "<br> " . $externo . "<br>" . $vento . "<br>" . $luz . "<br>" . $raios;


    $texto = $_POST['texto'];
    if (strpos($_POST['texto'], '"') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], "'") !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], ';') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '*') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '`') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '=') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if(strlen($_POST['texto']) > 100) {echo "O seu texto pode ter no maximo 100 caracteres"; exit();}

//nome, titulo do problema, categoria do suporte, log, id do cliente, texto do cliente
criarsuporte($nome, 'Sem conexão a internet', '1', $log, $id, $texto);
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
echo "Redirecionando...";

}
?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
   
    
   
</body>
</html>
