﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
            $asaasassinaturaid = $row["asaasassinaturaid"];
            $asaasid = $row["asaasid"];
        }
    }


    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
           
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            
        }
    }
}
else
{
    header('Location: login.php');
}

$sql = "SELECT * FROM `cancelamentos` WHERE `idcliente` LIKE '" . $id . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $idcliente = $row["idcliente"];
        $andamento = $row["andamento"];
        if($id == $idcliente)
        {
            header('Location: cancelar.php');
        }
    }
}



//consumo dessa conexão
$upload = 0;
                    $download = 0;
                    $sql = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usuariopppoe . "' ORDER BY `radacctid` DESC limit 1";
                    $result = $connradius->query($sql);
                    if ($result->num_rows > 0) {
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            $upload = $row["acctinputoctets"];
                            $download = $row["acctoutputoctets"];
                            
                
                        }
                    }

                    $consumo = $upload + $download;
if ($consumo >= 1073741824)
{
    $consumo = number_format($consumo / 1073741824, 2) . ' GB';
}
elseif ($consumo >= 1048576)
{
    $consumo = number_format($consumo / 1048576, 2) . ' MB';
}
elseif ($consumo >= 1024)
{
    $consumo = number_format($consumo / 1024, 2) . ' KB';
}
elseif ($consumo > 1)
{
    $consumo = $consumo . ' byte';
}
elseif ($consumo == 1)
{
    $consumo = $consumo . ' byte';
}
else
{
    $consumo = '0 bytes';
}


//fim consumo
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Bem Vindo, <?php echo $nome; ?></h2>   
                        


                     <h3>Está com alguma dúvida ou problema? <a href="suporte/novo.php" style="font-size: 25px;">Peça ajuda</a> | <a href="suporte" style="font-size: 25px;">Pedidos de suporte</a></h3><br>
<?php
if($ativo == 0)
{
    ?>
<div class="alert alert-danger">
    Seu serviço de conexão a internet está INATIVO! entre em contato com nossa equipe de suporte para a reativação <a href="suporte/novo.php" class="alert-link">Suporte</a>.
                            </div>
                            
                                <?php
}
//Ver se usuario está conectado
require 'sistema/logadopppoe.php'; 

    if($desconectado == 1){
        ?>
        <h4>Atualmente, seu roteador está <a style="color:red;">DESCONECTADO</a> a internet, você foi desconectado as <?php echo $stoptime; ?> pelo motivo: <?php echo $motivodesconect; ?></h4>
<?php
    }
    else
    {
        ?>
<h4>Atualmente, seu roteador está <a style="color:green;">CONECTADO</a> a internet, conexão realizada em <?php echo $starttime; ?> você já consumiu <?php echo $consumo;?> desde a ultima desconexão </h4>
    <?php
    }
//

///Pagamentos
$sql = "SELECT * FROM `pagamentos` WHERE `idusuario` = " . $id . " ORDER BY `id` DESC LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $vencido = $row["vencido"];
                                            $status = $row["pago"];

    }
}
$pendentes = 0;
$atrasadas = "0";
if(!$status == "1")
{
    $pendentes = "1";
}

if($vencido == "1")
{
    $atrasadas = "1";
}


///
if($atrasadas == 0)
{
if($pendentes == 0)
    {
?>
<div class="alert alert-info">
                               Todas as suas faturas estão em dia, Obrigado!
                            </div>

<?php    }else{?>
    <div class="alert alert-warning">
                                Você tem uma ou mais faturas aguardando pagamento. <a href="faturas.php" class="alert-link">Ver faturas</a>.
                            </div>

<?php
}
}else{
    ?>
    <div class="alert alert-danger">
    Você tem faturas que estão atrasadas! seu serviço corre o risco de ser cancelado por falta de pagamento. <a href="faturas.php" class="alert-link">Ver faturas</a>.
                            </div>

<?php
}
?>


<div class="">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Simple Buttons Examples
                        </div>        
                                      
                                    <div class="panel-body"> 

                    <h4>Default Button</h4>
                    <a href="#" class="btn btn-default">default</a>
                    <a href="#" class="btn btn-primary">primary</a>
                    <a href="#" class="btn btn-danger">danger</a>
                    <a href="#" class="btn btn-success">success</a>
                    <a href="#" class="btn btn-info">info</a>
                    <a href="#" class="btn btn-warning">warning</a>

                   
                    <h4>Mini Button</h4>
                    <a href="#" class="btn btn-default btn-xs">default</a>
                    <a href="#" class="btn btn-primary btn-xs">primary</a>
                    <a href="#" class="btn btn-danger btn-xs">danger</a>
                    <a href="#" class="btn btn-success btn-xs">success</a>
                    <a href="#" class="btn btn-info btn-xs">info</a>
                    <a href="#" class="btn btn-warning btn-xs">warning</a>

                  
                    <h4>Small Button</h4>
                    <a href="#" class="btn btn-default btn-sm">default</a>
                    <a href="#" class="btn btn-primary btn-sm">primary</a>
                    <a href="#" class="btn btn-danger btn-sm">danger</a>
                    <a href="#" class="btn btn-success btn-sm">success</a>
                    <a href="#" class="btn btn-info btn-sm">info</a>
                    <a href="#" class="btn btn-warning btn-sm">warning</a>

                   
                    <h4>Large Button</h4>

                    <a href="#" class="btn btn-default btn-lg">default</a>
                    <a href="#" class="btn btn-primary btn-lg">primary</a>
                    <a href="#" class="btn btn-danger btn-lg">danger</a>
                    <a href="#" class="btn btn-success btn-lg">success</a>
                    <a href="#" class="btn btn-info btn-lg">info</a>

                   
                </div>
            </div>
                          </div>


<p>Painel de administração exclusivo Data Web, Versão BETA 1.0 </p>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
