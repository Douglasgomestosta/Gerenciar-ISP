<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 


$cep = trim($_POST['cep']);
if (strpos($cep, 'AND') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, ';') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, "'") !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, '"') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}

if (strpos($cep, '-') == false) {
$cep = substr_replace($cep, '-', -3, 0);
}


$sql = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "'";
$result = $conn->query($sql);
$disponivel = "0";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $rua = $row["rua"];

        header('Location: http://datawebtelecom.site/disponibilidade/?rua=' . $rua);

    }
}else{
    header('Location: http://datawebtelecom.site/semdisponibilidade/');
}





 ?>
