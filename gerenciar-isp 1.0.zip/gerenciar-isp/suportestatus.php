﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
        }
    }
}
else
{
    header('Location: login.php');
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <link rel="stylesheet" href="csspanel/waves.min.css" type="text/css" media="all">


   <link rel="stylesheet" type="text/css" href="csspanel/widget.css">

   <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php
if($_GET['id'] > "1")
{
    $sql = "SELECT * FROM `suporte` WHERE `id` = " . $_GET['id'];
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $problema = $row["problema"];
            $categoria = $row["categoria"];
            $status = $row["status"];
            $respostacliente = $row["respostacliente"];
            $resposta = $row["Resposta"];
            if($categoria == 1){$categoria = "Estou sem internet";}
            if($categoria == 2){$categoria = "Minha conexão a internet está lenta";}
            if($categoria == 3){$categoria = "Estou com problemas de perda de pacotes ou alta latencia";}
            if($categoria == 4){$categoria = "Estou com pronlemas relacionado ao pagamento da minha conta";}
            if($categoria == 5){$categoria = "Perguntas";}
            if($categoria == 6){$categoria = "Outros assuntos";}
            if($status == 0){$status = "Aguardando resposta de um tecnico";}
            if($status == 1){$status = "Um tecnico está analisando seu problema";}
            if($status == 2){$status = "O tecnico já respondeu ou resolveu seu problema"; $cor = 'style="color:green;"';}
            echo "<h3>Seu problema: " . $problema . "</h3><br>";
            echo "<h3>Categoria: " . $categoria . "</h3><br>";
            echo "<h3 $cor >Status do suporte: " . $status . "</h3><br>";
            echo "<h3>Sua resposta: " . $respostacliente . "</h3><br>";
            if($resposta == "0"){
                echo "<h3>Nenhum técnico ainda de respondeu, aguarde mais um pouquinho que logo você sera atendido ;)";
            }else
            {
            echo "<h3>Nós respondemos: " . $resposta . "</h3><br>";
            }
        
        ?>
        <h6>Não foi bem atendido? Ocorreu algum caso desagradável com este pedido de suporte? Você pode abrir uma denúncia ou reclamação sobre o técnico responsável </h6>
        
        <a href="#.php">Esta função ainda está indisponivel :\ desculpe</a>


        <br><br><br>
<a href="../index.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar a pagina inicial</a><br><br>
        <?php
        
        exit();
        }



    }else
    {
        echo "Não encontrado";
    }
}
else
{

}
?>


<a href="suporte.php" class="btn btn-primary btn-lg">Abrir novo pedido de suporte</a>

<div class="panel panel-default">
                        <div class="panel-heading">
                        As suas faturas de internet
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <div id="dataTables-example_wrapper" class="dataTables_wrapper form-inline" role="grid"><div class="row"><div class="col-sm-6"><div class="dataTables_length" id="dataTables-example_length"><label></label></div></div><div class="col-sm-6"><div id="dataTables-example_filter" class="dataTables_filter"></div></div></div><table class="table table-striped table-bordered table-hover dataTable no-footer" id="dataTables-example" aria-describedby="dataTables-example_info">
                                    <thead>
                                        <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column ascending" style="width: 161px;">Categoria</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" style="width: 235px;">Problema</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending" style="width: 218px;">//</th><th class="sorting" tabindex="0" aria-controls="dataTables-example" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending" style="width: 137px;">Status</th></tr>
                                    </thead>
                                    <tbody> <?php
                                    $sql = "SELECT * FROM `suporte` WHERE `idcliente` = " . $id . "  ORDER BY `data` DESC";
    $result = $conn->query($sql);
    $temsuportes = "0";
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $temsuportes = "1";
            $problema = $row["problema"];
            $categoria = $row["categoria"];
            $idsuporte = $row["id"];
            $status = $row["status"];
            if($categoria == 1){$categoria = "Estou sem internet";}
            if($categoria == 2){$categoria = "Minha conexão a internet está lenta";}
            if($categoria == 3){$categoria = "Estou com problemas de perda de pacotes ou alta latencia";}
            if($categoria == 4){$categoria = "Estou com pronlemas relacionado ao pagamento da minha conta";}
            if($categoria == 5){$categoria = "Tenho perguntas";}
            if($categoria == 6){$categoria = "Outros assuntos";}
            ?>
       <tr class="gradeA odd">
                                            <td class="sorting_1"><a href="?id=<?php echo $idsuporte; ?>"> <?php echo $categoria; ?> </a></td>
                                            <td class=" "><?php echo $problema; ?></td>
                                            <td class=" ">////</td>
                                            
                                            <?php
if($status == 0)
{
    ?>
<td><label class="label label-danger">Aguardando...</label></td>
<?php
}
if($status == 1)
{
    ?>
<td><label class="label label-danger">Em analise...</label></td>
<?php
}
if($status == 2)
{
    ?>
<td><label class="label label-success">Resolvido</label></td>
<?php
}
?>
                                        </tr>
       <?php
        }

    } ?>
                                   </tbody>
                                </table><div class="row"><div class="col-sm-6"></div><div class="col-sm-6"><div class="dataTables_paginate paging_simple_numbers" id="dataTables-example_paginate"></div></div></div></div>
                            </div>
                            
                        </div>
                    </div>


                    <?php

if($temsuportes == "0")
    {
        ?>
        <h6>Você ainda não criou nenhum pedido de suporte, você pode criar um pedido de suporte <a href="suporte.php">Aqui</a> </h6>
        <?php
    }

?>

                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    
    
   
</body>
</html>
