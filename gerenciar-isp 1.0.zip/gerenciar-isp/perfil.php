﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
require 'sistema/FUNCTIONS.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $email = $row["email"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
            $asaasassinaturaid = $row["asaasassinaturaid"];
            $asaasid = $row["asaasid"];
            $telefone = $row["whatsapp"];
        }
    }


    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
           
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            
        }
    }
}
else
{
    header('Location: login.php');
}





if($_POST['parte'] == "2")
{
$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$nome_social = sqlinjection($nome_social);
$email = sqlinjection($email);
$telefone = sqlinjection($telefone);

$sql = "UPDATE `usuarios` SET `email` = '" . $email . "', `nome` = '" . $nome . "', `whatsapp` = '" . $telefone . "' WHERE `usuarios`.`id` = " . $id . ";";

$result = $conn->query($sql);
//echo "nome:" . $nome . "<br>Email: " . $email . "<br>Telefone: " . $telefone;
$_SESSION['email'] = $email;
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />



<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


</style>


   <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    



                    <form method="post">
    <input type="hidden" name="parte" value="2">
                                    

    <tr>
                                            <td style="padding: 12px 0 0 2px;">
Nome completo:                                             
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            
                                                <input tabindex="2" type="text" size="50px" style="width:240px;" class="input is-large" name="nome" maxlength="200" value="<?php echo $nome; ?>"> 

                                            </td>
                                        </tr>
                                        <tr>
                                        </tr>


<h6>Você pode trocar seu nome para o nome de casamento, nome de solteiro, ou seu nome social.</h6>



<br>


                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
Email:                                             
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            
                                                <input tabindex="2" type="text" size="50px" style="width:240px;" class="input is-large" name="email" maxlength="200" value="<?php echo $email; ?>"> 

                                            </td>
                                        </tr>
                                        <tr>
                                        </tr>







                                        <br>


<tr>
    <td style="padding: 12px 0 0 2px;">
Número de telefone:(utilize somente numeros com DDD)                                             
    </td>
</tr>


<tr>

    <td>

    
        <input tabindex="2" type="text" size="50px" style="width:240px;" class="input is-large" name="telefone" maxlength="200" value="<?php echo $telefone; ?>"> 

    </td>
</tr>
<tr>
</tr>



<h6>Senha: ******<a href="trocarsenha.php" class="btn btn-primary btn-sm">Trocar minha senha de acesso</a></h6>



                                        <tr>

                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="salvar dados" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </form>




                                <div class="">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

 <h3>Quais dados a Data Web tem sobre mim?</h3>
 <h4>Estes são todos os dados que a Data Web tem sobre você, lembre-se que valorizamos a sua privacidade e só armazenamos tudo o que é necessario para fornecer um serviço de qualidade para você.</h4>
<h5>Dados armazenados: </h5>
<h6>Seu e-mail fornecido por você</h6>
<h6>Seu nome completo fornecido por você</h6>
<h6>Seu nome social se houver e fornecido por você</h6>
<h6>Sua senha fornecida por você e criptografada em mão unica(impossivel descriptografar-la)</h6>
<h6>Seu numero de telefone fornecido por você</h6>
<h6>Seu cep e numero da casa fornecido por você</h6>
<h6>Seu plano de internet escolhido por você</h6>
<h6>Seu CPF ou CNPJ fornecido por você</h6>
<h6>Suas faturas de internet e outros serviços fornecidos pela Data Web</h6>
<h6>Se você é um idoso</h6>
<h6>A sua cidade fornecida por você</h6>
<h6>As coordenadas da sua casa</h6>
<h6>O nome da sua mâe fornecido por você</h6>
<h6>A sua data de nascimento fornecido por você</h6>
<h6>A sua cidade de nascimento fornecido por você</h6>
<h6>O seu RG fornecido por você</h6>
<h6>O historico de pedidos de suportes criados por você</h6>
<h6>O nome de usuario do seu serviço PPPOE</h6>
<h6>A sua senha do serviço PPPOE(não criptografada porém apenas para uso do seu roteador, diferente da senha principal)</h6>
<h6>O seu endereço ipv4 e ipv6</h6>
<h6>O modelo do seu roteador</h6>
<h6>O seu endereço MAC do roteador</h6>
<h6>bloqueio contra virus e sites adultos</h6>
<h6>nome da rede wifi</h6>
<h6>senha da rede wifi(escolhida pela Data Web, caso escolhida pelo usuario a senha não é salva)</h6>
<h6>modelo da onu se houver</h6>
<h6>Suas notificações</h6>
<h6>seu historico de mudanças do serviço Data Web</h6>
<h6>Suas features postadas na Data Web Features</h6>
<h6>Suas doações mensais a Data Web Causas</h6>
<h6>Os emails enviados a você</h6>
<h6>Os descontos fornecidos a você</h6>
<h6>Seu cancelamento de serviço se houver</h6>
<h6>Suas autenticações ao painel do assinante junto com a data, o navegador e o ip</h6>
<h6>As agendas de manutenções em sua residencia feitas pelos nossos técnicos em caso de necessidae</h6>
<h6>As informações do servidor RADIUS sobre suas conexões ao serviço PPPOE tais como data de inicio, fim, ip, consumo de dados, etc...(função radacct)</h6>
<h6>As informações sobre autenticações ao serviço PPPOE usando Radius tais como username, status da tentativa, senha da tentativa e data</h6>







                </div>
            </div>
                          </div>



<p>Painel de administração exclusivo Data Web, Versão <?php echo $versao; ?> </p>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
