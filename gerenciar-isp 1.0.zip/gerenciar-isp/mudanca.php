﻿<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $ativo = $row["ativo"];
            $senha = $row["senha"];
            $cpf = $row["cpf"];
            $cepantigo = $row["cep"];
            $numeroantigo = $row["numero"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
        }
    }
}
else
{
    header('Location: login.php');
}


if($_POST['mudanca'] == 1)
{



    if($cepantigo ==  $_POST['cep'])
    {
        if($numeroantigo == $_POST['numero'])
        {
            echo "Você não pode se mudar para o mesmo lugar onde você mora, caso precise fazer a mudança do local do equipamento em sua casa, por favor abra um pedido de suporte";
        exit();
        }
    }
    $cep = trim($_POST['cep']);
    if (strpos($cep, 'AND') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (strpos($cep, ';') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (strpos($cep, "'") !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (strpos($cep, '"') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (!is_numeric($_POST['numero'])) {
        echo "Utilize somente numeros no campo numero da casa";
        exit();
    }

    $sql = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "' AND `disponivel` LIKE '1'";
    $result = $conn->query($sql);
    $disponivel = "0";
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
        $disponivel = "1";
        $nomerua = $row["rua"];
        }
    }
    if($disponivel == "0")
    {
        echo "Cep novo indisponivel";
        exit();
    }



    //$data = date('y-m-d');
    //$sql = "INSERT INTO `mudancas` (`id`, `idcliente`, `cepantigo`, `numeroantigo`, `cepnovo`, `numeronovo`, `andamento`, `data`) VALUES ('1', '1', '" . $cepantigo . "', '" . $numeroantigo . "', '" . $cep . "', '" . $_POST['numero'] . "', '0', '" . $data . "');";
//$result = $conn->query($sql);


}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />


   
<!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


</style>



<script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

    
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php
                    //parte 3
if($_POST['parte'] == 3)
{
    $cep = trim($_POST['cep']);
    if (strpos($cep, 'AND') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (strpos($cep, ';') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (strpos($cep, "'") !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (strpos($cep, '"') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (strpos($cep, '-') == false) {
        $cep = substr_replace($cep, '-', -3, 0);
        }
    if (!is_numeric($_POST['numero'])) {
        echo "Utilize somente numeros no campo numero da casa";
        exit();
    }

    if($cepantigo ==  $_POST['cep'])
    {
        if($numeroantigo == $_POST['numero'])
        {
            echo "Você não pode se mudar para o mesmo lugar onde você mora, caso precise fazer a mudança do local do equipamento em sua casa, por favor abra um pedido de suporte";
        exit();
        }
    }
    $sql = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "' AND `disponivel` LIKE '1'";
    $result = $conn->query($sql);
    $disponivel = "0";
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
        

            $sql = "SELECT * FROM `mudancas` WHERE `idcliente` = " . $id . " AND `andamento` = 1 OR `idcliente` = " . $id . " AND `andamento` = 0 ";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            }else{
    $data = date('y-m-d');
    $sql = "INSERT INTO `mudancas` (`id`, `idcliente`, `cepantigo`, `numeroantigo`, `cepnovo`, `numeronovo`, `andamento`, `data`) VALUES (null, '" . $id . "', '" . $cepantigo . "', '" . $numeroantigo . "', '" . $cep . "', '" . $_POST['numero'] . "', '0', '" . $data . "');";
$result = $conn->query($sql);
if($_POST['idagendamento'] == "0"){}else
{
    if (is_numeric($_POST['idagendamento'])) {}else{ exit();}
    $sql = "SELECT * FROM `agendas` WHERE `id` = " . $_POST['idagendamento'] . " AND `marcado` IS NULL";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {


        $sql = "SELECT * FROM `mudancas` WHERE `andamento` LIKE '0' AND `idcliente` LIKE '" . $id . "' ORDER BY `id` DESC LIMIT 1";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {$idmudanca = $row['id'];}}
            $sql = "UPDATE `agendas` SET `tipo` = '2', `idtipo` = '" . $idmudanca . "', `marcado` = '1' WHERE `agendas`.`id` = " . $_POST['idagendamento'] .";";
            if ($conn->query($sql) === TRUE) {
              //return "1";
            } else {
             // return $conn->error;
            }



    }
}            



}
?>
<div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Mudança de endereço realizada com sucesso!
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <div class="">

                                    <center>
    <img src="../imagens/ok.webp" width="100">
<h1 style="font-size: 25px; color: black;">Pronto! </h1>
<h2>Você já fez o pedido de mudança de endereço, e nosso técnico estará em sua nova casa para fazer a instalação na hora marcada. </h2>
<h3>Lembre-se de levar o modem e o roteador junto com as suas fontes(cabos de energia) para sua nova casa, para que o técnico faça a instalação dos equipamentos. </h3>
<h5>Diversos fatores podem fazer com que o técnico se atrase ou não possa fazer o seu atendimento, como um suporte anterior que demorou mais do que deveria, chuvas, raios, transito, etc...</h5>

<a href="painel.php" class="btn btn-success btn-lg">Página inicial</a>

                                        </div>
                                    </div>
                    </div>
                    </div>
<?php

        }
    }
    exit();
}



//parte 2
if($_POST['parte'] == 2)
{
?>
<div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Vamos agendar o dia?
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <div class="">
<h3>Vamos escolher o dia em que o técnico vai fazer a instalação em sua nova casa?</h3>
<h4>Lembre-se! no dia da instalação será necessario que todos os equipamentos de internet exceto o cabo que vem da rua esteja em sua casa nova, então leve seu modem e roteador com as fontes(cabo de energia) para sua casa nova para que o técnico faça a instalação </h5>				
<?php
$hora = date('H') + 2;
$data = date("Y-m-d");
$sql = "SELECT * FROM `agendas` WHERE `data` > '" . $data . " " . $hora . ":00:00' AND `marcado` IS NULL";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $idadmin = $row["idadmin"];
        $data = $row["data"];
        $idagendamento = $row["id"];
        $array=explode("-",$data);
        $mes = $array[1];
        $dia = $array[2];
        $arrayy=explode(" ",$dia);
        $dia = $arrayy[0];
        $hora = $arrayy[1];
        $arrayy=explode(":",$hora);
        $hora = $arrayy[0] . ":" . $arrayy[1];
        $ano = $array[0];
        $data =  "$dia/$mes/$ano as $hora";


        $sqll = "SELECT * FROM `admins` WHERE `id` = " . $idadmin;
$resultt = $conn->query($sqll);
if ($resultt->num_rows > 0) {
    // output data of each row
    while($roww = $resultt->fetch_assoc()) {
$nomeadmin = $roww["nome"];
    }
}
       ?>
       <div class="col-md-4 col-sm-4">
<div class="panel panel-primary">
<div class="panel-heading"><?php echo $data; ?> Horas</div>
<div class="panel-body">
<p>Agendamento para <?php echo $data; ?> pelo técnico <?php echo $nomeadmin; ?></p>
</div>
<div class="panel-footer">
<form method="post">
        <input type="hidden" name="parte" value="3">
        <input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
<input type="hidden" name="numero" value="<?php echo $_POST['numero']; ?>">
        <input type="hidden" name="idagendamento" value="<?php echo $idagendamento; ?>">
    

                                                    <input tabindex="3" type="submit" value="Marcar horário." class="btn btn-success" style="width: 200px;">

                                    </form>



                               </div>
</div>
</div>
       <?php
    }

    ?>
     <div class="col-md-4 col-sm-4">
<div class="panel panel-primary">
<div class="panel-heading">Nenhuma das anteriores</div>
<div class="panel-body">
<p>Não quero nenhum dos horários anteriores</p>
<h6>Entraremos em contato com você para marcar um horário</h6>
</div>
<div class="panel-footer">
<form method="post">
<input type="hidden" name="parte" value="3">
        <input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
<input type="hidden" name="numero" value="<?php echo $_POST['numero']; ?>">
        <input type="hidden" name="idagendamento" value="0">
    
    

                                                    <input tabindex="3" type="submit" value="Continuar." class="btn btn-success" style="width: 200px;">

                                    </form>



                               </div>
</div>
</div>
    <?php
}else{
    //não achou nenhum agendamento disponivel
    ?>
    <br>
    <div class="">
<div class="panel panel-default">
<div class="panel-heading">
Não existem horários agendados disponíveis
</div>
<div class="panel-body">

<h3>Infelizmente não existem horários agendados para os proximos dias.</h3>
<h4>Iremos abrir o seu pedido de suporte e assim que possivel, iremos ligar para você para agendar o seu suporte.</h4>

<form method="post">
<input type="hidden" name="parte" value="3">
        <input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
<input type="hidden" name="numero" value="<?php echo $_POST['numero']; ?>">

        <input type="hidden" name="idagendamento" value="0">
    

                                                    <input tabindex="3" type="submit" value="Confirmar." class="btn btn-success" style="width: 200px;">

                                    </form>

</div>
</div>
</div>
    <?php
}
?>
                                        </div>
                                    </div>
                    </div>
                    </div>

<?php
}

//parte 1
if($_POST['parte'] == 1)
{
    $cep = trim($_POST['cep']);
    if (strpos($cep, 'AND') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (strpos($cep, ';') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (strpos($cep, "'") !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (strpos($cep, '"') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
    if (strpos($cep, '-') == false) {
        $cep = substr_replace($cep, '-', -3, 0);
        }
    if (!is_numeric($_POST['numero'])) {
        echo "Utilize somente numeros no campo numero da casa";
        exit();
    }

    if($cepantigo ==  $_POST['cep'])
    {
        if($numeroantigo == $_POST['numero'])
        {
            echo "Você não pode se mudar para o mesmo lugar onde você mora, caso precise fazer a mudança do local do equipamento em sua casa, por favor abra um pedido de suporte";
        exit();
        }
    }
    $sql = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "' AND `disponivel` LIKE '1'";
    $result = $conn->query($sql);
    $disponivel = "0";
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
        $disponivel = "1";
        $nomerua = $row["rua"];

        ?>
        <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Vamos começar as mudanças?
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <div class="">
<h4>Seu novo endereço: <?php echo $nomerua; ?></h4>
<h4>Numero da sua casa nova: <?php echo $_POST['numero']; ?></h4>
<h4>Custo: Zero</h4>
<h5>Na Data Web vocẽ tem troca de endereço de graça! porém a gratuidade é valida por 1 instalação ao ano, a afim de evitar que o cliente não cause prejuizos trocando de endereço todo mês</h5>
<h5>Se você precisar fazer mais do que uma mudança de endereço por ano, podemos cobrar a você um valor de R$50 para custear a troca de cabos</h5>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
<form method="post">
<input type="hidden" name="parte" value="2">
<input type="hidden" name="cep" value="<?php echo $cep; ?>">
<input type="hidden" name="numero" value="<?php echo $_POST['numero']; ?>">
                                    <table class="login-box">

                        



                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        </div>
                                    </div>
                    </div>
                    </div>
        <?php
        }
    }else{
        ?>
        <div class="">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                            Não chegamos em sua nova rua!
                        </div>        
                                      
                                    <div class="panel-body"> 

                                    <div class="">
                                    <center>
<img src="imagens/triste.png" width="80px">
</center>
<h4>é com muita dor no coração que anunciamos a você que o seu novo endereço ainda não tem o nosso serviço de internet :c </h4>
<h5>Infelizmente não poderemos atender-lo em sua nova casa... </h5>
								<center>			
<a href="painel.php" class="btn btn-primary btn-lg">Página inicial.</a>
<br><br>
<a href="cancelar.php" class="btn btn-danger btn-lg">Cancelar serviço de internet.</a>
									</center>

                                        </div>
                                    </div>
                    </div>
                    </div>
        <?php
    }




}
if(empty($_POST['parte']))
{
    
//$sql = "SELECT * FROM `mudancas` WHERE `idcliente` = " . $id;
$sql = "SELECT * FROM `mudancas` WHERE `idcliente` = " . $id . " AND `andamento` = 1 OR `idcliente` = " . $id . " AND `andamento` = 0 ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $idcliente = $row["idcliente"];
        $andamento = $row["andamento"];
        if($id == $idcliente)
        {
            $mudanca = 1;
        }
    }
}
if($mudanca == 1)
{
    ?>
<H2>Mudança de endereço realizado com exito! </h2>
<h3>Estaremos em sua Residência para fazer a mudança de seus equipamentos em até 2 dias uteis.</h3>
<?php
if($andamento == "0")
{
echo "<h4>Status do pedido: aguardando um técnico </h4>";
}
if($andamento == "1")
{
echo "<h4>Status do pedido: Um técnico está atendendo a sua solicitação</h4>";
}
if($andamento == "2")
{
echo "<h4>Status do pedido: Mudança realizada com exito</h4>";
}
?>
<?php
}
else
{
?>
<center>
<img src="imagens/casa.png" width="80px">
<h3>Que bom que você está de casa nova, agora vamos mudar seus equipamentos de internet?</h3>
<br>
<form method="post">
<input type="hidden" name="parte" value="1">
                                    <table class="login-box">
                                        <tr>
                                            <td syle="padding: 14px 0 0 4px;">
                                               <h4>Digite o seu novo cep</h4>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="1" type="text" size="20px" style="width:240px;" name="cep" class="input is-large" required="" minlength="4" maxlength="80">
                                            </td>
                                        </tr>
                                       
                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                              <h4>O novo numero da sua casa</h4>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="1" type="text" size="20px" style="width:240px;" name="numero" class="input is-large" required=""  maxlength="80">
                                            </td>
                                        </tr>



                        



                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>



</div>
</div>
</div>



<?php
}

}
?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->

    
   
</body>
</html>
