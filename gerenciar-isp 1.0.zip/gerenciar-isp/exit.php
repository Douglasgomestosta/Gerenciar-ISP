<?php
session_start();
session_destroy();
?>
<head>
<script>
			var auth2 = gapi.auth2.getAuthInstance();
			auth2.signOut().then(function () {
			  console.log('User signed out.');
			});
		</script>
</head>
<?php

header('Location: login.php?exit=1');