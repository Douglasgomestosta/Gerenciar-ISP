﻿<?php
session_start();
//error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
require '../sistema/FUNCTIONS.php'; 

//fim



if (!is_numeric($_GET['plano'])) {
    header('Location: http://datawebtelecom.site/residencial/');
    exit();
}else{
	$sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $_GET['plano'] . "'";
	$result = $conn->query($sql);
	$disponivel = "0";
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$nome = $row["nome"];
			$velocidade = $row["velocidade"];
			$velocidademinima = $row["velocidademinima"];
			$preco = $row["preco"];
			$tecnologia = $row["tecnologia"];
		}
	}else
	{
		header('Location: http://datawebtelecom.site/residencial/');
		exit();
	}
}
if (empty($_POST['casa']) || empty($_POST['cep']) || empty($_POST['email'])) {
	header('Location: http://datawebtelecom.site/residencial/');
}
if($_POST['parte'] == "1")
{
	$_POST['cpf'] = trim($_POST['cpf']);
	if(strlen($_POST['cpf']) < 11) { echo "Digite o seu CPF completo:" . $_POST['cpf']; exit();}
	if (!is_numeric($_POST['telefone'])) {echo "Utilize somente numeros no campo telefone"; exit();}
	if(strlen($_POST['nome']) < 4) {echo "Por favor, digite seu nome completo no campo Nome Completo";exit();}

}


?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>

<script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>

        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   //require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">

                    <?php
//inicio
if(!$_POST['parte'] == "1")
{
    if(!$_POST['aceite'] == "1")
    {
        ?>
        <h3>Antes de começar sua adesão, leia nossos termos de uso e termos de privacidade </h3>
        <center><iframe src="termos.php" width="85%" height="400px"></iframe> </center>
        	<form class="" method="post" action="dados.php?plano=<?php echo $_GET['plano']; ?>">


<h5>A Data Web valoriza a sua privacidade e seus direitos! por isso recomendamos que você leia os seus termos de uso e privacidade do cliente. </h5>

<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
<input type="hidden" name="casa" value="<?php echo $_POST['casa']; ?>">
<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
<input type="hidden" name="aceite" value="1">

<input tabindex="3" type="submit" value="Aceito os termos de uso" class="button is-block is-link is-large is-fullwidth">



					

				
				</form>
        <?php
        exit();
    }

    //ver se é utp
    //if($tecnologia == "utp")
    //{
    //    if($_POST['utp'] == "1"){}else{

        //Para não aparecer por enquanto, depois é só descomentar os códigos acima e apagar o de baixo
        if(false){ if(false){
        
?>
<h3>Você escolheu um plano de baixa renda </h3>
<h4>A Data Web acredita que o acesso a internet deve estar disponível a todos, tanto classe baixa como classe média e alta, por esse motivo, disponibilizamos os planos de baixa renda. </h4>
<h4>Mas como esses planos tem pouco lucro, a tecnologia usada(UTP) é inferior a tecnologia dos planos normais de Fibra Óptica.</h4>
<h4>Por esses motivos, você pode enfrentar oscilações na sua internet, já que a tecnologia UTP sofre interferências, tem uma quantia de banda disponível baixa(100 Megas por caixa) e é suscetível a raios.</h4>
<h4>Isso não significa que você não pode utilizar-la para serviços simples, como assistir um vídeo em HD, acessar sites, usar o facebook ou o whatsapp, mas lembre-se que ela pode oscilar bastante e não ter o mesmo padrão de qualidade dos nossos planos normais de Fibra Óptica. </h4>
<h4>Por esse motivo, recomendamos fortemente que, se você tiver condições financeiras de pagar por um plano de Fibra Óptica, que você opte por ela, já que esse plano é feito pensado em famílias de baixa renda e não tem grandes velocidades de download/upload e estabilidade.</h4>

<form class="login100-form validate-form" method="post"  action="http://datawebtelecom.site/residencial/">

                <input tabindex="3" type="submit" value="Escolher um plano de Fibra Optica." class="button is-block is-link is-large is-fullwidth">
				
				</form>




<form class="login100-form validate-form" method="post">
				<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
				<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
				<input type="hidden" name="casa" value="<?php echo $_POST['casa']; ?>">
                <input type="hidden" name="utp" value="1">
                <input type="hidden" name="aceite" value="1">

                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
				
				</form>
<?php
        exit();
}
    }
?>
				<form class="login100-form validate-form" method="post">
				<input type="hidden" name="parte" value="1">

				<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
				<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
				<input type="hidden" name="casa" value="<?php echo $_POST['casa']; ?>">
                <input type="hidden" name="aceite" value="1">
					
						<h3>Agora precisamos saber um pouco mais sobre você.</h3>
						<h4>Não se preocupe, todos os dados são criptografados.</h4>
					
					

					<div class="wrap-input100 validate-input" data-validate = "Precisamos do seu CPF para criar sua conta">
						<input class="input100" type="text" name="cpf" placeholder="Seu CPF." minlength="11">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Qual o seu nome completo?">
						<input class="input100" type="text" name="nome" placeholder="O seu nome completo." minlength="4">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Seu numero de telefone">
						<input class="input100" type="text" name="telefone" placeholder="Numero de telefone." minlength="8">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							
						</span>
					
					</div>
					<h6>Entraremos em contato com você por whatsapp ou ligação se for necessário. </h6>
					
<br>

<h4>Você é uma pessoa com Deficiência?</h4>
                    <select id="ordenacao" name="deficiencias"  id="ddi">
                                        <option value="0">Não.</option>
                                        <option value="1">Sou deficiente auditivo.</option>
                                        <option value="2">Sou deficiente visual.</option>
                                        <option value="3">Sou deficiente de fala.</option>
                                        <option value="4">Tenho autismo ou sindrome de down.</option>
                                        </select>
<h6>Usaremos essa informação para que o suporte técnico possa lhe ajudar de maneira mais eficiente e inclusiva </h6>

<p id="texto"></p>


<script>
ddi.onchange = function() {

}
</script>
                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">


				</form>


				<?php
				if($erro == "1")
				{
					if($tipoerro == "casa")
					{
					?>
<form class="login100-form validate-form" method="post">
				<input type="hidden" name="parte" value="1">
					<span class="login100-form-title">
						Já estamos na <?php echo $rua; ?>!
						<h6>Agora vamos conhecer melhor você?</h6>
					</span>

				</form>
					<?php
					}	
			}
}else{

	?>


<h3>Qual roteador você deseja ter?</h3>
<h4>Esse roteador será seu mesmo que você cancele seu serviço de internet, se você já tiver um roteador poderá utilizar-lo</h4>









                <div class="col-md-4 col-sm-4">
<div class="panel panel-primary">
<div class="panel-heading">Já tenho um roteador!</div>
<div class="panel-body">
<p>Você já tem um roteador e vai usar-lo.</p>
</div>
<div class="panel-footer">
<form method="post" action="endereco.php?plano=<?php echo $_GET['plano']; ?>">
	<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
				<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
				<input type="hidden" name="casa" value="<?php echo $_POST['casa']; ?>">
				<input type="hidden" name="cpf" value="<?php echo $_POST['cpf']; ?>">
				<input type="hidden" name="nome" value="<?php echo $_POST['nome']; ?>">
				<input type="hidden" name="telefone" value="<?php echo $_POST['telefone']; ?>">
                <input type="hidden" name="deficiencias" value="<?php echo $_POST['deficiencias']; ?>">
                <input type="hidden" name="roteador" value="0">

			
                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
				</form>


                   </div>
</div>
</div>





<div class="col-md-4 col-sm-4">
<div class="panel panel-primary">
<div class="panel-heading">Roteador simples.</div>
<div class="panel-body">
<p>Um roteador simples no valor de R$100,00</p>
</div>
<div class="panel-footer">
<form method="post" action="endereco.php?plano=<?php echo $_GET['plano']; ?>">
	<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
				<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
				<input type="hidden" name="casa" value="<?php echo $_POST['casa']; ?>">
				<input type="hidden" name="cpf" value="<?php echo $_POST['cpf']; ?>">
				<input type="hidden" name="nome" value="<?php echo $_POST['nome']; ?>">
				<input type="hidden" name="telefone" value="<?php echo $_POST['telefone']; ?>">
                <input type="hidden" name="deficiencias" value="<?php echo $_POST['deficiencias']; ?>">
                <input type="hidden" name="roteador" value="1">
                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
				</form>


         </div>
</div>
</div>




<div class="col-md-4 col-sm-4">
<div class="panel panel-primary">
<div class="panel-heading">Roteador avançado</div>
<div class="panel-body">
<p>Um roteador avançado no valor de R$200,00</p>
</div>
<div class="panel-footer">
<form class="login100-form validate-form" method="post" action="endereco.php?plano=<?php echo $_GET['plano']; ?>">
	<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
				<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
				<input type="hidden" name="casa" value="<?php echo $_POST['casa']; ?>">
				<input type="hidden" name="cpf" value="<?php echo $_POST['cpf']; ?>">
				<input type="hidden" name="nome" value="<?php echo $_POST['nome']; ?>">
				<input type="hidden" name="telefone" value="<?php echo $_POST['telefone']; ?>">
                <input type="hidden" name="deficiencias" value="<?php echo $_POST['deficiencias']; ?>">
                <input type="hidden" name="roteador" value="2">
		
                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
				</form>



          </div>
</div>
</div>






                <h5>O pagamento pode ser feito no ato da instalação usando cartão de crédito, débito ou dinheiro a vista, podendo ser parcelado em até 3 vezes </h6>
	<?php

}
				?>



                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
   
    
   
</body>
</html>
