﻿<?php
session_start();
//error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
require '../sistema/FUNCTIONS.php'; 

//fim



if (!is_numeric($_GET['plano'])) {
    header('Location: http://datawebtelecom.site/residencial/');
    exit();
}else{
	$sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $_GET['plano'] . "'";
	$result = $conn->query($sql);
	$disponivel = "0";
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$nome = $row["nome"];
			$velocidade = $row["velocidade"];
			$velocidademinima = $row["velocidademinima"];
			$preco = $row["preco"];
			$tecnologia = $row["tecnologia"];
		}
	}else
	{
		header('Location: http://datawebtelecom.site/residencial/');
		exit();
	}
}
if (empty($_POST['casa']) || empty($_POST['cep']) || empty($_POST['email'])) {
	header('Location: http://datawebtelecom.site/residencial/');
}
if($_POST['parte'] == "1")
{
	$_POST['cpf'] = trim($_POST['cpf']);
	if(strlen($_POST['cpf']) < 11) { echo "Digite o seu CPF completo:" . $_POST['cpf']; exit();}
	if (!is_numeric($_POST['telefone'])) {echo "Utilize somente numeros no campo telefone"; exit();}
	if(strlen($_POST['nome']) < 4) {echo "Por favor, digite seu nome completo no campo Nome Completo";exit();}

}


?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

input[type=password], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

</style>

<script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>

        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   //require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">

        
<?php
//inicio
if(!$_POST['parte'] == "1")
{
?>
<h3>Só mais alguns detalhes...</h3>
<h4>Vamos escolher uma senha para proteger seu painel do assinante?</h4>
				<form class="login100-form validate-form" method="post">
				<input type="hidden" name="parte" value="1">
				<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
				<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
				<input type="hidden" name="casa" value="<?php echo $_POST['casa']; ?>">
				<input type="hidden" name="cpf" value="<?php echo $_POST['cpf']; ?>">
				<input type="hidden" name="nome" value="<?php echo $_POST['nome']; ?>">
				<input type="hidden" name="telefone" value="<?php echo $_POST['telefone']; ?>">
				<input type="hidden" name="roteador" value="<?php echo $_POST['roteador']; ?>">
                <input type="hidden" name="deficiencias" value="<?php echo $_POST['deficiencias']; ?>">

					

					<div class="wrap-input100 validate-input" data-validate = "Digite uma senha para o uso no seu painel do assinante">
						<input class="input100" type="password" name="senha" placeholder="Sua senha segura." minlength="6">
						<span class="focus-input100"></span>
						<span class="symbol-input100">


<input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">


					

				</form>


                <h5>Digite uma senha segura e que você se lembre para que você possa acessar o painel do assinante.</h5>

				<?php

}else{
$senha = $_POST['senha'];
	?>
	<form class="login100-form validate-form" method="post" action="pronto.php?plano=<?php echo $_GET['plano']; ?>">
	<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
				<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
				<input type="hidden" name="casa" value="<?php echo $_POST['casa']; ?>">
				<input type="hidden" name="cpf" value="<?php echo $_POST['cpf']; ?>">
				<input type="hidden" name="nome" value="<?php echo $_POST['nome']; ?>">
				<input type="hidden" name="telefone" value="<?php echo $_POST['telefone']; ?>">
				<input type="hidden" name="roteador" value="<?php echo $_POST['roteador']; ?>">
                <input type="hidden" name="deficiencias" value="<?php echo $_POST['deficiencias']; ?>">
                <input type="hidden" name="senha" value="<?php echo $senha; ?>">
					<span class="login100-form-title">
					Em que horário podemos ir até a sua casa?
											</span>

					<div class="wrap-input100 validate-input" data-validate = "...">
					<select id="ordenacao" name="horario">
                                        <option value="1">De manha</option>
                                        <option value="2">De tarde</option>
                                        </select>
										<h6>Nosso técnico entrara em contato com você por whatsapp ou ligação para agendar um dia disponível.</h6>

						</span>
					</div>


                    <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">


					

				
				</form>
	<?php

}
				?>
			</div>
		</div>
	</div>
	

                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
   
    
   
</body>
</html>
