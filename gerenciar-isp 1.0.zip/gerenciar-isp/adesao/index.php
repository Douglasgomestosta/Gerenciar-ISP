<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
if (!is_numeric($_GET['plano'])) {
    header('Location: http://datawebtelecom.site/residencial/');
    exit();
}else{
	$sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $_GET['plano'] . "'";
	$result = $conn->query($sql);
	$disponivel = "0";
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$nome = $row["nome"];
			$velocidade = $row["velocidade"];
			$velocidademinima = $row["velocidademinima"];
			$preco = $row["preco"];
			$tecnologia = $row["tecnologia"];
		}
	}else
	{
		header('Location: http://datawebtelecom.site/residencial/');
		exit();
	}
}

if($_POST['parte'] == "1")
{
$cep = trim($_POST['cep']);
if (strpos($cep, 'AND') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, ';') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, "'") !== false) { echo "Utilize somente numeros no campo CEP"; exit();}
if (strpos($cep, '"') !== false) { echo "Utilize somente numeros no campo CEP"; exit();}

if (strpos($cep, '-') == false) {
$cep = substr_replace($cep, '-', -3, 0);
}

if (!is_numeric($_POST['casa'])) {
	$erro = "1";
	$tipoerro = "casa";
	echo "Utilize somente numeros no campo numero da casa.";
	exit();
}
$disponivel = "0";
if(!$erro == "1")
{
$sql = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "' AND `disponivel` LIKE '1'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    $disponivel = "1";
	$rua = $row["rua"];
	$tecnologias = $row["tecnologias"];
    }
}
}
$_POST['email'] = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {}else{echo("Você não digitou um email valido"); exit();}

if($disponivel == "0")
{
	if(!$erro == "1")
	{
	$sql = "INSERT INTO `notificacaorua` (`id`, `email`, `cep`, `casa`) VALUES (NULL, '" . $_POST['email'] . "', '". $cep . "', '" . $_POST['casa'] . "');";
$result = $conn->query($sql);
	}
}


}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bem Vindo(a) a Data Web</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">


<?php
//inicio
if(!$_POST['parte'] == "1")
{
?>
				<form class="" method="post">
				<input type="hidden" name="parte" value="1">
					<span class="login100-form-title">
					Chegou a hora de você ter o melhor serviço de conexão a internet da sua cidade!
						<h6>Preencha alguns dados abaixo e veja se já chegamos a sua rua, é rapidinho.</h6>
					</span>
					

					<div class="wrap-input100 validate-input" data-validate = "Digite um email valido, ex: douglas@hotmail.com">
						<input class="input100" type="text" name="email" placeholder="Seu e-mail">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Por favor, digite o cep de sua rua">
						<input class="input100" type="text" name="cep" placeholder="CEP da sua rua" minlength="8">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Por favor, digite o numero da sua casa">
						<input class="input100" type="text" name="casa" placeholder="Numero da casa">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Continuar
						</button>
					</div>

					<h6>A Data Web salvará seus dados caso não tenha disponibilidade em sua rua para que você seja informado no dia em que chegamos. </h6>

					
				</form>


				<?php
				if($erro == "1")
				{
					if($tipoerro == "casa")
					{
					?>
<form class="login100-form validate-form" method="post">
				<input type="hidden" name="parte" value="1">
					<span class="login100-form-title">
						Numero da casa invalido
						<h6>Agora vamos conhecer melhor você?</h6>
					</span>

				</form>
					<?php
					}	
			}
}else{
if($disponivel == "1")
{
	?>
	<form class="" method="post" action="dados.php?plano=<?php echo $_GET['plano']; ?>">
					<span class="login100-form-title">
					<img src="images/coracao.png" alt="IMG" style="width: 25%;"><br>

						Já estamos na <?php echo $rua; ?>!
						<h6>Agora vamos conhecer melhor você?</h6>
					</span>
<input type="hidden" name="cep" value="<?php echo $cep; ?>">
<input type="hidden" name="casa" value="<?php echo $_POST['casa']; ?>">
<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Continuar
						</button>
					</div>

					

				
				</form>
	<?php
}else{
	if($erro == "1")
	{
		?>
		<form class="login100-form validate-form" method="post">
		<input type="hidden" name="parte" value="1">
			<span class="login100-form-title">
				Houve um erro
				<h6>.</h6>
			</span>

		</form>
		<?php
	}else{
		?>
			<form class="login100-form validate-form" method="post">
				<input type="hidden" name="parte" value="1">
					<span class="login100-form-title">
						Ainda não chegamos em sua rua...
						<h6>Mas não se preocupe, anotamos o seu email e assim que o serviço estiver disponivel em sua rua, avisaremos você.</h6>
					</span>
					

			

					

				
				</form>
		<?php
	}
}

}
				?>
			</div>
		</div>
	</div>
	
	

	
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>