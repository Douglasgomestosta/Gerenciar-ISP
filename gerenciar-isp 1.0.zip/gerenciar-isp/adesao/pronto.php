﻿<?php
session_start();
//error_reporting(E_ALL ^ E_NOTICE);
require '../sistema/db.php'; 
require '../sistema/FUNCTIONS.php'; 

//fim



if (!is_numeric($_GET['plano'])) {
    header('Location: http://datawebtelecom.site/residencial/');
    exit();
}else{
	$sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $_GET['plano'] . "'";
	$result = $conn->query($sql);
	$disponivel = "0";
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$nome = $row["nome"];
			$velocidade = $row["velocidade"];
			$velocidademinima = $row["velocidademinima"];
			$preco = $row["preco"];
			$tecnologia = $row["tecnologia"];
		}
	}else
	{
		header('Location: http://datawebtelecom.site/residencial/');
		exit();
	}
}
if (empty($_POST['casa']) || empty($_POST['cep']) || empty($_POST['email'])) {
	header('Location: http://datawebtelecom.site/residencial/');
}
if($_POST['parte'] == "1")
{
	$_POST['cpf'] = trim($_POST['cpf']);
	if(strlen($_POST['cpf']) < 11) { echo "Digite o seu CPF completo:" . $_POST['cpf']; exit();}
	if (!is_numeric($_POST['telefone'])) {echo "Utilize somente numeros no campo telefone"; exit();}
	if(strlen($_POST['nome']) < 4) {echo "Por favor, digite seu nome completo no campo Nome Completo";exit();}

}


?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

input[type=password], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

</style>

<script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="../assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>

        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   //require '../sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">

    
<?php
if(!$_POST['parte'] == "1")
{
//ver se tem algum erro
if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {}else{
  $erro = "1";
  $mensagemerro = "Você não digitou um email valido!";
}
$sql = "SELECT * FROM `adesao` WHERE `email` LIKE '" . $_POST['email'] . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe um pedido de adesão usando o mesmo e-mail que você!";}
$sql = "SELECT * FROM `usuarios` WHERE `email` LIKE '" . $_POST['email'] . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe um cliente utilizando o mesmo e-mail que você!";}

$cep = trim($_POST['cep']);
if (strpos($cep, 'AND') !== false) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo CEP";}
if (strpos($cep, ';') !== false) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo CEP";}
if (strpos($cep, "'") !== false) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo CEP";}
if (strpos($cep, '"') !== false) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo CEP";}
if (strpos($cep, '-') == false) {
$cep = substr_replace($cep, '-', -3, 0);
}
$cepnumero = strlen($cep);
if($cepnumero < 9 || $cepnumero > 9){ $erro = "1"; $mensagemerro = "Digite um CEP valido!";}
if (!is_numeric($_POST['casa'])) { $erro = "1"; $mensagemerro = "Utilize um numero da casa valido!"; }
if($_POST['casa'] > 5000) { $erro = "1"; $mensagemerro = "Utilize um numero da casa valido!"; }

$sql = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "' AND `disponivel` LIKE '1'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { }else{ $erro = "1"; $mensagemerro = "O cep inserido não está disponivel.";}


$sql = "SELECT * FROM `adesao` WHERE `cep` LIKE '" . $cep . "' AND `numero` LIKE '" . $_POST['casa'] . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe um pedido de adesão no endereço informado por você!";}

$sql = "SELECT * FROM `usuarios` WHERE `cep` LIKE '" . $cep . "' AND `numero` LIKE '" . $_POST['casa'] . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe um cliente de internet no endereço informado por você!";}

$cpf = sqlinjection($_POST['cpf']);
$cpf = trim($_POST['cpf']);
$cpf = str_replace('.', '', $cpf);
$cpf = str_replace('-', '', $cpf);
$cpfnumero = strlen($cpf);
if($cpfnumero < 11 || $cpfnumero > 11){ $erro = "1";   $mensagemerro = "Digite um CPF valido!";}

$sql = "SELECT * FROM `adesao` WHERE `cpf` LIKE '" . $cpf . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe uma adesão com o seu CPF!";}

$sql = "SELECT * FROM `usuarios` WHERE `cpf` LIKE '" . $cpf . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe um cliente com o seu CPF!";}

$nomenumero = strlen($_POST['nome']);
if($nomenumero < 4){$erro = "1"; $mensagemerro = "Digite o seu nome e sobrenome completo!";}
if (strpos($_POST['nome'], ' ') == false) { $erro = "1"; $mensagemerro = "Digite seu nome e sobrenome separados por espaço.";}

$_POST['telefone'] = str_replace('(', '', $_POST['telefone']);
$_POST['telefone'] = str_replace(')', '', $_POST['telefone']);
$_POST['telefone'] = str_replace(' ', '', $_POST['telefone']);
if (!is_numeric($_POST['telefone'])) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo telefone!"; }

if($_POST['roteador'] < 3){}else{$erro = "1"; $mensagemerro = "Dado invalido no roteador";}
if (!is_numeric($_POST['roteador'])) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo roteador!"; }
if($_POST['deficiencias'] < 5){}else{$erro = "1"; $mensagemerro = "Dado invalido no campo 'deficiencias'";}
if (!is_numeric($_POST['deficiencias'])) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo 'deficiencias'!"; }
if($_POST['horario'] == "1" || $_POST['horario'] == "2"){}else{$erro = "1"; $mensagemerro = "horario invalido!";}

if(strlen($_POST['senha']) < 6){$erro = "1"; $mensagemerro = "Digite uma senha que tenha pelo menos 6 caracteres!";}
if(strlen($_POST['senha']) > 20){$erro = "1"; $mensagemerro = "Sua senha não pode ter mais do que 20 caracteres";}
//fim ver se tem algum erro

if($erro == "1")
{
  ?>
  <h2>Ocorreu um erro ao tentar criar o seu pedido de adesão</h2>
  <h3>Erro: <?php echo $mensagemerro; ?></h3>
  <form class="login100-form validate-form" method="post" action="index.php?plano=<?php echo $_GET['plano']; ?>">
<input tabindex="3" type="submit" value="Voltar ao inicio." class="button is-block is-link is-large is-fullwidth" style="background-color:#DF0101;">
</form>
  <?php
}else
{

  if($_POST['horario'] == "1"){$horario = "Manha";}else{$horario = "Tarde";}
  if($_POST['deficiencias'] == "0"){$deficiencia = "Não";}else{$deficiencia = "Sim";}
  ?>
<h3>Tudo pronto, deseja fazer a sua adesão? </h3>
<h4>Dados fornecidos por você: </h4>
<h5>Email: <?php echo $_POST['email']; ?></h5>
<h5>Cep: <?php echo $_POST['cep']; ?></h5>
<h5>Casa: <?php echo $_POST['casa']; ?></h5>
<h5>CPF: <?php echo $_POST['cpf']; ?></h5>
<h5>Nome: <?php echo $_POST['nome']; ?></h5>
<h5>Telefone: <?php echo $_POST['telefone']; ?></h5>
<h5>Roteador: <?php echo $_POST['roteador']; ?></h5>
<h5>Pessoa com deficiencia: <?php echo $deficiencia; ?></h5>
<h5>Horário: <?php echo $horario; ?></h5>
<form class="login100-form validate-form" method="post" action="pronto.php?plano=<?php echo $_GET['plano']; ?>">
	<input type="hidden" name="email" value="<?php echo $_POST['email']; ?>">
				<input type="hidden" name="cep" value="<?php echo $_POST['cep']; ?>">
				<input type="hidden" name="casa" value="<?php echo $_POST['casa']; ?>">
				<input type="hidden" name="cpf" value="<?php echo $_POST['cpf']; ?>">
				<input type="hidden" name="nome" value="<?php echo $_POST['nome']; ?>">
				<input type="hidden" name="telefone" value="<?php echo $_POST['telefone']; ?>">
				<input type="hidden" name="roteador" value="<?php echo $_POST['roteador']; ?>">
                <input type="hidden" name="deficiencias" value="<?php echo $_POST['deficiencias'] ?>">
                <input type="hidden" name="horario" value="<?php echo $_POST['horario']; ?>">
                <input type="hidden" name="senha" value="<?php echo $_POST['senha']; ?>">
                <input type="hidden" name="parte" value="1">


                <h6>Esses dados serão armazenados em nossos servidores, a sua senha será criptografada em MD5. </h6>


                    <input tabindex="3" type="submit" value="Fazer a Adesão." class="button is-block is-link is-large is-fullwidth">
				</form>


        <br>


        <form class="login100-form validate-form" method="post" action="index.php?plano=<?php echo $_GET['plano']; ?>">



                    <input tabindex="3" type="submit" value="Voltar ao inicio." class="button is-block is-link is-large is-fullwidth" style="background-color:#DF0101;">


				</form>
  <?php
}



}else{



  //ver se tem algum erro
if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {}else{
  $erro = "1";
  $mensagemerro = "Você não digitou um email valido!";
}
$sql = "SELECT * FROM `adesao` WHERE `email` LIKE '" . $_POST['email'] . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe um pedido de adesão usando o mesmo e-mail que você!";}
$sql = "SELECT * FROM `usuarios` WHERE `email` LIKE '" . $_POST['email'] . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe um cliente utilizando o mesmo e-mail que você!";}

$cep = trim($_POST['cep']);
if (strpos($cep, 'AND') !== false) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo CEP";}
if (strpos($cep, ';') !== false) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo CEP";}
if (strpos($cep, "'") !== false) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo CEP";}
if (strpos($cep, '"') !== false) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo CEP";}
if (strpos($cep, '-') == false) {
$cep = substr_replace($cep, '-', -3, 0);
}
$cepnumero = strlen($cep);
if($cepnumero < 9 || $cepnumero > 9){ $erro = "1"; $mensagemerro = "Digite um CEP valido!";}
if (!is_numeric($_POST['casa'])) { $erro = "1"; $mensagemerro = "Utilize um numero da casa valido!"; }
if($_POST['casa'] > 5000) { $erro = "1"; $mensagemerro = "Utilize um numero da casa valido!"; }

$sql = "SELECT * FROM `ruas` WHERE `cep` LIKE '" . $cep . "' AND `disponivel` LIKE '1'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { }else{ $erro = "1"; $mensagemerro = "O cep inserido não está disponivel.";}


$sql = "SELECT * FROM `adesao` WHERE `cep` LIKE '" . $cep . "' AND `numero` LIKE '" . $_POST['casa'] . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe um pedido de adesão no endereço informado por você!";}

$sql = "SELECT * FROM `usuarios` WHERE `cep` LIKE '" . $cep . "' AND `numero` LIKE '" . $_POST['casa'] . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe um cliente de internet no endereço informado por você!";}

$cpf = sqlinjection($_POST['cpf']);
$cpf = trim($_POST['cpf']);
$cpf = str_replace('.', '', $cpf);
$cpf = str_replace('-', '', $cpf);
$cpfnumero = strlen($cpf);
if($cpfnumero < 11 || $cpfnumero > 11){ $erro = "1";   $mensagemerro = "Digite um CPF valido!";}

$sql = "SELECT * FROM `adesao` WHERE `cpf` LIKE '" . $cpf . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe uma adesão com o seu CPF!";}

$sql = "SELECT * FROM `usuarios` WHERE `cpf` LIKE '" . $cpf . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { $erro = "1"; $mensagemerro = "Já existe um cliente com o seu CPF!";}

$nomenumero = strlen($_POST['nome']);
if($nomenumero < 4){$erro = "1"; $mensagemerro = "Digite o seu nome e sobrenome completo!";}
if (strpos($_POST['nome'], ' ') == false) { $erro = "1"; $mensagemerro = "Digite seu nome e sobrenome separados por espaço.";}

$_POST['telefone'] = str_replace('(', '', $_POST['telefone']);
$_POST['telefone'] = str_replace(')', '', $_POST['telefone']);
$_POST['telefone'] = str_replace(' ', '', $_POST['telefone']);
if (!is_numeric($_POST['telefone'])) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo telefone!"; }

if($_POST['roteador'] < 3){}else{$erro = "1"; $mensagemerro = "Dado invalido no roteador";}
if (!is_numeric($_POST['roteador'])) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo roteador!"; }
if($_POST['deficiencias'] < 5){}else{$erro = "1"; $mensagemerro = "Dado invalido no campo 'deficiencias'";}
if (!is_numeric($_POST['deficiencias'])) { $erro = "1"; $mensagemerro = "Utilize somente numeros no campo 'deficiencias'!"; }
if($_POST['horario'] == "1" || $_POST['horario'] == "2"){}else{$erro = "1"; $mensagemerro = "horario invalido!";}

if(strlen($_POST['senha']) < 6){$erro = "1"; $mensagemerro = "Digite uma senha que tenha pelo menos 6 caracteres!";}
if(strlen($_POST['senha']) > 20){$erro = "1"; $mensagemerro = "Sua senha não pode ter mais do que 20 caracteres";}
//fim ver se tem algum erro





  if($erro == "1")
{
  ?>
  <h2>Ocorreu um erro ao tentar criar o seu pedido de adesão</h2>
  <h3>Erro: <?php echo $mensagemerro; ?></h3>
  <form class="login100-form validate-form" method="post" action="index.php?plano=<?php echo $_GET['plano']; ?>">
<input tabindex="3" type="submit" value="Voltar ao inicio." class="button is-block is-link is-large is-fullwidth" style="background-color:#DF0101;">
</form>
  <?php
}else{

$senha = md5($_POST['senha']);
  $sql = "INSERT INTO `adesao` (`id`, `email`, `nome`, `senha`, `cep`, `numero`, `sobreacasa`, `plano`, `cpf`, `roteador`, `datapedido`, `andamento`, `tecnico`, `cancelado`, `resposta`, `horario`, `finalizadodata`) VALUES (NULL, '" . $_POST['email'] . "', '" . $_POST['nome'] . "', '" . $senha . "', '" . $cep . "', '" . $_POST['casa'] . "', NULL, '" . $_GET['plano'] . "', '" . $cpf . "', '" . $_POST['roteador'] . "', CURRENT_TIMESTAMP, '0', '0', '0', '0', '" . $_POST['horario'] . "', null);";
	$result = $conn->query($sql);

?>
<center><img alt="" src="../imagens/ok.webp"  style="width: 90px; margin: 0px;">
<br>
					<h1 style="color:black;">Parabéns</h1>
						<h3>Incrível! Você já fez a sua adesão e em breve nosso técnico entrará em contato com você por whatsapp, telefone ou e-mail para agendar uma data exata para a instalação do seu serviço de internet.</h3>

<?php
$conteudo = "<center><h1>Bem Vindo(a) a Data Web!</h1> <h3>É uma honra para a Data Web ter você como cliente! e muito em breve estaremos em sua casa para fazer a sua instalação! </h3> <h6>Lembre-se que o técnico vai se comunicar com você por whatsapp, e-mail ou ligação para agendar a sua instalação! </h6> ";
criaremail("adesao", $_POST['email'], "Bem Vindo a Data Web!", $conteudo);
}
}
?>

			</div>
		</div>
	</div>
	

                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
   
    
   
</body>
</html>
