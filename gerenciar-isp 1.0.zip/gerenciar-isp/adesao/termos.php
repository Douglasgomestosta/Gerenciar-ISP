﻿<h4>Termos de uso e privacidade</h4>
<h5>Ultima atualização: 29/10/2020</h5>
<p>| Termos de uso |</p>
<p>Este termo de uso pode ser atualizado a qualquer momento pela Data Web, caso os termos de uso e privacidade sejam atualizados, todos os clientes ativos receberão um aviso por e-mail sobre a atualização, caso o cliente esteja em desacordo, poderá cancelar o seu serviço a qualquer momento </p>

<p>Perante a Anatel, a Data Web tem a obrigação de entregar pelo menos 40% da velocidade contratada entre o periodo de 08:00 a 22:00, embora a Data Web abra um pedido de suporte para solucionar seu problema caso a quantia de internet esteja abaixo de 60%<p>

<p>Perante a Anatel, a Data Web tem a obrigação de solucionar seu problema de internet em até 24 horas, embora a Data Web use como valor base os valores abaixo: </p>

<p>Para problemas externos: até 12 horas</p>
<p>Para problemas internos: De acordo com a hora marcada pelo cliente, com no maximo 24 horas</p>
<p>Os horários usam como base condições normais de funcionamento, não levando em considerações desastres naturais ou de causas humanas, nesses casos a Data Web poderá levar mais tempo para solucionar seu problema.</p>

<p>Perante a Anatel, a Data Web tem a obrigação de dar desconto na fatura pelas horas de interrupção do serviço caso tenha ultrapassado as 24 horas e a causa da interrupção não tenha sido causada pelo cliente </P>

<p>A Data Web se compromete em dar desconto na fatura pelas horas de interrupção não causada pelo cliente por problemas externos caso ultrapasse o valor de 12 horas </p>

<p>A Data Web se compromete em dar desconto na fatura pelas horas de interrupção não causada pelo cliente por problemas internos caso ultrapasse as 24 horas ou que o agendamento marcado tenha sido remarcado por problemas causados por parte do técnico, da empresa ou pelo clima, exceto por pedido do cliente.</p>

<p>A Data Web se compromete em adiar o pagamento de suas faturas pelos dias de indisponibilidade, caso o cliente fique impossibilidado de pagar sua fatura por indisponibilidade no painel do assinante, também conhecido como SAC </p>

<p>A Data Web se reserva ao direito de decidir entre o uso de ipv4 com CGNAT ou IPV6 publico para seus clientes</p>
<p>Em caso de uso de ipv4 com cgnat, é obrigação da Data Web perante a Anatel armazenar suas informações por até 1 ano, embora não seja da vontade da Data Web armazenar essas informações</p>

<p>Em caso de uso ilegal perante a justiça brasileira, a Data Web tem o direito e a obrigação de suspender o seu serviço de internet e reportar o uso indevido as autoridades</p>

<p>A Data Web tem o direito e a obrigação de informar as autoridades legais as informações fornecidas por você e armazenadas em nossos servidores em caso de requerimento por parte da justiça</p>

<p>Em caso de compartilhamento do serviço de internet para mais de 1 casa ou edificio, comercial ou residencial, a Data Web tem o direito de cancelar o seu serviço de internet por uso indevido</p>

<p>Em caso de compartilhamento do serviço de internet com outros edificos ou casas sem a devida legalidade da Anatel, a Data Web tem o direito e a obrigação de informar a Anatel sobre a exploração ilegal dos serviços de telecomunicações </p>

<P>| Termos de Privacidade |</p>

<p> A Data Web armazenara informações sobre você e seu serviço a fim de garantir uma melhor qualidade e comodidade no seu serviço de internet </p>
<p>A Data Web pode ou não salvar as informações abaixo: </p>

<p>Seu e-mail</p>
<p>Seu nome completo</p>
<p>Sua senha criptografada em MD5</p>
<P>Seu numero de telefone</p>
<p>Seu CEP e numero da casa</p>
<p>Seu plano de internet</p>
<P>Seu CPF ou CNPJ</p>
<p>Suas faturas de internet e a forma de pagamento</p>
<p>Seus dados do cartão de crédito somente para débito automatico se houver</p>
<p>A sua cidade e seu bairro <p>
<p>As coordenadas da sua casa</p>
<p>O nome da sua mâe</p>
<p>A sua data de nascimento</p>
<p>A sua cidade de nascimento</p>
<p>O seu RG</p>
<p>Historico do pedido de suporte </p>
<p>O nome de usuario e senha do seu serviço PPPOE ou Poe</p>
<P>O seu endereço ipv4, ipv6 ou os dois</p>
<P>O modelo do seu roteador</p>
<p>Endereço MAC do seu roteador </p>
<p>Bloqueio contra sites maliciosos e adultos se houver</P>
<P>Nome da rede WIFI</p>
<p>senha da rede wifi</p>
<p>Modelo da ONU se houver </p>
<p>Suas notificações e e-mail enviados a você</p>
<p>Seu historico de mudanças de endereço(do serviço)</p>
<p>Suas features postadas na Data Web Features</p>
<p>Suas doações mensais a Data Web Causas</p>
<p>Os descontos fornecidos a você</p>
<p>Seu cancelamento de serviço se houver</p>
<P>Suas autenticações ao painel do assinante junto com a data, o navegador e o ip</p>
<p>As agendas de manutenções em sua residencia feitas pelos nossos técnicos</p>
<p>As informações do servidor RADIUS sobre suas conexões ao serviço PPPOE tais como data de inicio, fim, ip, consumo de dados, etc...(função radacct)</p>
<p>As informações sobre autenticações ao serviço PPPOE usando Radius tais como username, status da tentativa, senha da tentativa e data</p>
<P> A Data Web também pode salvar informações não informadas acima, desde que seja informado ao cliente antes do ato </p>


<p>Glossário</p>
<p>Problema interno: interrupções no serviço causadas por uma falha de um equipamento dentro da casa do cliente ou por problemas no cabo de internet também conhecido como cabo assinante(drop) que seja de uso exclusivo do cliente </p>
<p>Problema externo:Interrupções no serviço causadas por uma falha da rede que esteja fora da rede interna do cliente, ex: rompimento de cabo AS de 1 ou mais fibras, Defeito em caixas CTO de Fibra optica, etc...