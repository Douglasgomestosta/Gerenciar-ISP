<?php
session_start();
require 'sistema/db.php'; 
$email = filter_input(INPUT_POST, 'userEmail', FILTER_SANITIZE_STRING);


$sql = "SELECT * FROM `usuarios` WHERE `email` LIKE '" . $email . "'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($email == $row["email"])
	{
		$_SESSION['login'] = "1";
          $_SESSION['email'] = $email;
          $_SESSION['senha'] = "0";
          $_SESSION['id'] = $row["id"];
		  $_SESSION['usuariocomum'] = "1";
		  $_SESSION['nome_completo'] = $row["nome"];
		  

		  //salva o log de login
          $id = $row["id"];
          $ip = $_SERVER['HTTP_CLIENT_IP'];
          $navegador = $_SERVER['HTTP_USER_AGENT'];
          $sql = "INSERT INTO `autenticacoes` (`id`, `idcliente`, `data`, `navegador`, `ip`) VALUES (NULL, '" . $id . "', CURRENT_TIMESTAMP, '" . $navegador . "', '" . $ip . "');";
$resultt = $conn->query($sql);


	}else
	{
		$resultado = 'erro';
		echo(json_encode($resultado));
	}
	
	
	}
}else
{
	$resultado = 'erro';
	echo(json_encode($resultado));	
}





exit();
$result_usuario = "SELECT * FROM usuarios WHERE email='$email' LIMIT 1";
$resultado_usuario = mysqli_query($conn, $result_usuario);
//Econtrado usuario com esse e-mail
if(($resultado_usuario) AND ($resultado_usuario->num_rows != 0)){
	$userName = filter_input(INPUT_POST, 'userName', FILTER_SANITIZE_STRING);
	$_SESSION['userName'] = $userName;
	$resultado = 'adm.php';
	echo $resultado;
}else{//Nenhum usuário encontrado
	$resultado = 'erro';
	echo(json_encode($resultado));
}