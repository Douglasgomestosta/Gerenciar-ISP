<?php

function antipalavroes($texto, $correcao) {

    if($correcao == 1)
    {
        $texto = str_replace('porra', '***', $texto);
        $texto = str_replace('caralho', '***', $texto);
        $texto = str_replace('buceta', '***', $texto);
        $texto = str_replace('xota', '***', $texto);
        $texto = str_replace('foda', '***', $texto);
        $texto = str_replace('fude', '***', $texto);
        $texto = str_replace('foder', '***', $texto);
        $texto = str_replace('cu', '***', $texto);
        $texto = str_replace('puta', '***', $texto);
        $texto = str_replace('viado', '***', $texto);
        $texto = str_replace('veado', '***', $texto);
        $texto = str_replace('boceta', '***', $texto);

    }else
    {

    }


    return $texto;
  }
  //fim anti palavrôes

  function sqlinjection($texto) {
    $texto = str_replace(';', '', $texto);
    $texto = str_replace("'", '', $texto);
    $texto = str_replace('*', '', $texto);
    $texto = str_replace('`', '', $texto);
    $texto = str_replace('=', '', $texto);
    $texto = str_replace(',', '', $texto);
    $texto = str_replace('"', '', $texto);

    return $texto;
}
//fim anti sql

  //Criar suporte no banco de dados

  function criarsuporte($nome, $titulo, $categoria , $log, $id, $texto, $externo, $importancia) {
    require 'db.php'; 
if($externo == "0")
{
  //$sql = "INSERT INTO `suporte` (`id`, `data`, `nome_cliente`, `problema`, `categoria`, `status`, `Log`, `idcliente`, `Resposta`, `respostacliente`, `atendente`, `resolvidodata`, `tipoproblema`, `externo`, `importancia`) VALUES (NULL, CURRENT_TIMESTAMP, '" . $nome . "', '" . $titulo . "', '" . $categoria . "', '0', '" . $log . "', '" . $id . "', '0', '" . $texto . "', '0', null, null, '1', '" . $importancia . "');";
  $sql = "INSERT INTO `suporte` (`id`, `data`, `nome_cliente`, `problema`, `categoria`, `status`, `Log`, `idcliente`, `Resposta`, `respostacliente`, `atendente`, `resolvidodata`, `tipoproblema`, `externo`, `importancia`) VALUES (NULL, CURRENT_TIMESTAMP, '" . $nome . "', '" . $titulo . "', '" . $categoria . "', '0', '" . $log . "', '" . $id . "', '0', '" . $texto . "', '0', null, null, null, '" . $importancia . "');";

}else{
  //$sql = "INSERT INTO `suporte` (`id`, `data`, `nome_cliente`, `problema`, `categoria`, `status`, `Log`, `idcliente`, `Resposta`, `respostacliente`, `atendente`, `resolvidodata`, `tipoproblema`, `externo`, `importancia`) VALUES (NULL, CURRENT_TIMESTAMP, '" . $nome . "', '" . $titulo . "', '" . $categoria . "', '0', '" . $log . "', '" . $id . "', '0', '" . $texto . "', '0', null, null, null, '" . $importancia . "');";
  $sql = "INSERT INTO `suporte` (`id`, `data`, `nome_cliente`, `problema`, `categoria`, `status`, `Log`, `idcliente`, `Resposta`, `respostacliente`, `atendente`, `resolvidodata`, `tipoproblema`, `externo`, `importancia`) VALUES (NULL, CURRENT_TIMESTAMP, '" . $nome . "', '" . $titulo . "', '" . $categoria . "', '0', '" . $log . "', '" . $id . "', '0', '" . $texto . "', '0', null, null, '" . $externo . "', '" . $importancia . "');";

}
    //$sql = "INSERT INTO `suporte` (`id`, `data`, `nome_cliente`, `problema`, `categoria`, `status`, `Log`, `idcliente`, `Resposta`, `respostacliente`, `atendente`, `resolvidodata`, `tipoproblema`) VALUES (NULL, CURRENT_TIMESTAMP, '" . $nome . "', '" . $titulo . "', '" . $categoria . "', '0', '" . $log . "', '" . $id . "', '0', '" . $texto . "', '0', null, null);";
    if ($conn->query($sql) === TRUE) {
      return "1";
    } else {
       return $conn->error . "<br> SQL:" . $sql . "<br>importancia: " . $importancia;
    }

}
//fim criar suporte


//doações dos usuarios
function doacao($idusuario) {
  require 'db.php'; 
  $sql = "INSERT INTO `doacoes` (`id`, `idcliente`, `data`, `valor`) VALUES (NULL, '" . $idusuario . "', CURRENT_TIMESTAMP, '0.50')";
  if ($conn->query($sql) === TRUE) {
    return "1";
  } else {
    return $conn->error;
  }
  return $sql;
}
//fim doações dos usuarios

//criar notificação a ser exibida para o cliente no banco de dados
function criarnotificacao($idusuario, $texto, $conteudo, $url) {
  require 'db.php'; 
  $sql = "INSERT INTO `notificacoes` (`id`, `idusuario`, `texto`, `conteudo`, `exibido`, `data`, `url`) VALUES (NULL, '" . $idusuario ."', '" . $texto . "', '" . $conteudo . "', '0', CURRENT_TIMESTAMP, '" . $url . "');";
  //return "Criação de notificação: id" . $idusuario . " texto: " . $texto . " Conteudo " . $conteudo . " url " . $url;
  if ($conn->query($sql) === TRUE) {
    return "1";
  } else {
    return $conn->error;
  }
}

//criar email para ser enviado no banco de dados
function criaremail($solicitante, $destino, $sobre, $conteudo) {
  require 'db.php'; 
  $sql = "INSERT INTO `emails` (`id`, `solicitante`, `data`, `destino`, `sobre`, `texto`) VALUES (NULL, '" . $solicitante . "', CURRENT_TIMESTAMP, '" . $destino . "', '" . $sobre . "', '" . $conteudo . "');";
  //return "Criação de notificação: id" . $idusuario . " texto: " . $texto . " Conteudo " . $conteudo . " url " . $url;
  if ($conn->query($sql) === TRUE) {
    return "1";
  } else {
    return $conn->error;
  }
}



//usuario instavel desconectando e conectando varias vezes
function clienteinstavel($roteador){
  require 'db.php'; 
  $instabilidade = "0";
  $sql = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $roteador . "' AND `acctstoptime` LIKE '%" . date('Y-m-d') . "%' ORDER BY `acctstarttime` DESC";
  $result = $connradius->query($sql);
  if ($result->num_rows > 0) {
      // output data of each row
      while($row = $result->fetch_assoc()) {
          $instabilidade = $instabilidade + 1;
          
      }
  }
return $instabilidade;
}

//função ver se o servidor está funcionando e sua latencia
function servidorping($ip){
  exec("ping -c 1 $ip", $output, $status);
  
  if ($status==0) {
      $ping = $output[1];
      $array = explode('time=', $ping);
  $ping = $array[1];
  $array = explode(' ', $ping);
  $ping = $array[0];
  return $ping;
  
  } else {
      return "0";
  }
}



//Clientes na rua instaveis, desconectando e conectando varias vezes.
function clientesruainstavel($cep){
  require 'db.php'; 
  $sql = "SELECT * FROM `usuarios` WHERE `cep` LIKE '" . $cep . "' AND `ativo` = 1";
  $result = $conn->query($sql);
  $instabilidade = "0";
  $instaveis = "0";
  if ($result->num_rows > 0) {
      // output data of each row
      while($row = $result->fetch_assoc()) {
        $idcliente = $row["id"];
        $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $idcliente;
                $resultl = $conn->query($sqll);
                if ($resultl->num_rows > 0) {  while($rowl = $resultl->fetch_assoc()) { $clientepppoe = $rowl["usuario"];} }
                

                $sqll = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $clientepppoe . "' AND `acctstoptime` LIKE '%" . date('Y-m-d') . "%' ORDER BY `acctstarttime` DESC";
                $resultt = $connradius->query($sqll);
                if ($resultt->num_rows > 4) {
                  $instaveis = $instaveis + 1;
                }

      }
    }

  return $instaveis;
}