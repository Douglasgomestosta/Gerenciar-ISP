<?php
session_start();
require 'db.php'; 
$data = date("Y-m-d");
$tem = "0";
$sql = "SELECT * FROM `notificacoes` WHERE `sms` = 0 AND `data` LIKE '%" . $data . "%' limit 1";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $conteudo = $row["conteudo"];
            $idusuario = $row["idusuario"];
            $tem = "1";
        }
    }

    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $idusuario;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $whatsapp = $row["whatsapp"];
        }
    }

    $sql = "UPDATE `notificacoes` SET `sms` = '1' WHERE `notificacoes`.`idusuario` = " . $idusuario . ";";
    $result = $conn->query($sql);


if($tem == "1")
{
header('Location: https://web.whatsapp.com/send?phone=55' . $whatsapp . '&text=' . $conteudo . '&source=&data=&app_absent=');
}else
{
?>
<div class="weEq5"><button class="_35EW6"><span data-icon="send" class=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M1.101 21.757L23.8 12.028 1.101 2.3l.011 7.912 13.623 1.816-13.623 1.817-.011 7.912z"></path></svg></span></button></div>
<?php

}