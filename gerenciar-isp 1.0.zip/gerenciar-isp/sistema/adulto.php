<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE); 
require 'db.php'; 



$key = $_GET['key'];
    $plano = $_GET['plano'];
    $key = $_GET['key'];
    if($key == "85473284duhj")
    {}else {echo "Não achou que seria tão facil assim, né?"; exit();}

    $sql = "SELECT * FROM `usuarios` WHERE  `ativo` = 1";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {













        $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $row["id"] . " AND `bloqueioadulto` = 1";
        $resultl = $conn->query($sqll);
        if ($resultl->num_rows > 0) {
            // output data of each row
            while($rowl = $resultl->fetch_assoc()) {
            echo $rowl["ip"] . "<br>";
            }
        }














        }
    }