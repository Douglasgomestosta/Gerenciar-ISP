<li>
                        <a  href="painel.php"><i class="fa fa-dashboard fa-3x"></i> Inicio</a>
                    </li>
                      <li>
                        <a  href="suportestatus.php"><i class="fa fa-desktop fa-3x"></i>Pedidos de suporte</a>
                    </li>
                    <li>
                        <a  href="firewall.php"><i class="fa fa-qrcode fa-3x"></i>Configurações do Firewall</a>
                    </li>
						   <li  >
                        <a  href="mudanca.php"><i class="fa fa-bar-chart-o fa-3x"></i>Trocar de endereço</a>
                    </li>	
                      <li  >
                        <a  href="mudarplano.php"><i class="fa fa-table fa-3x"></i>Trocar de plano</a>
                    </li>
                    <li  >
                        <a  href="cancelar.php"><i class="fa fa-edit fa-3x"></i>Cancelar serviço</a>
                    </li>	

                    <li>
                        <a href="#"><i class="fa fa-sitemap fa-3x"></i> Roteador<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="wifi.php">Dados do WI-FI</a>
                            </li>
                            <li>
                                <a href="pppoe.php">Dados do PPPoE</a>
                            </li>

                            <li>
                            <a  href="conexoes.php">Tentativas de conexão</a>
                            </li>
                           
                        </ul>
                      </li> 



                    <li  >
                        <a  href="faturas.php"><i class="fa fa-edit fa-3x"></i>Pagamentos</a>
                    </li>

                    <?php
$cont = 0;
$sql = "SELECT * FROM `notificacoes` WHERE `idusuario` = " . $id . " AND `exibido` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>

                    <li  >
                        <a  href="notify.php"><i class="fa fa-edit fa-3x"></i>Notificações(<?php echo $cont; ?>)</a>
                    </li>
					

                           <li  >
                        <a  href="features.php"><i class="fa fa-edit fa-3x"></i>Features</a>
                    </li>             
                    
                  <li  >
                        <a class="active-menu"  href="blank.html"><i class="fa fa-square-o fa-3x"></i> Blank Page</a>
                    </li>	
                </ul>