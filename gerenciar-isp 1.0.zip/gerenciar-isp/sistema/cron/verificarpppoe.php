<?php
session_start();
require '/var/www/html/painel/sistema/db.php'; 
require '/var/www/html/painel/sistema/FUNCTIONS.php'; 
$sql = "SELECT * FROM `servidores`";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
$ippublico = $row['ippublico'];
$secret = $row['secret'];

$connection = ssh2_connect($ippublico, 22);
            ssh2_auth_password($connection, 'vyos', $secret);
            $data = " ";
            $stream = ssh2_shell($connection);
                    fwrite($stream, "show pppoe-server sessions". PHP_EOL);
                    fwrite($stream, PHP_EOL);
                    sleep(2);
                    $data .= stream_get_contents($stream);
                    //print_r($data);
                    fclose($stream);


                    $sqll = "SELECT * FROM `radacct` WHERE `nasipaddress` LIKE '" . $ippublico . "' AND `acctstoptime` IS NULL;";
                 
                    $resultt = $connradius->query($sqll);
if ($resultt->num_rows > 0) {
    while($roww = $resultt->fetch_assoc()) {
        $username = $roww['username'];
        $radacctid = $roww['radacctid'];
        if (strpos($data, $username) == false) {
        echo "Usuario: $username desconectado do servidor pppoe! <br>";
        $sqlll = "UPDATE `radacct` SET `acctstoptime` = CURRENT_TIMESTAMP, `acctterminatecause` = 'server-erro' WHERE `radacct`.`radacctid` = " . $radacctid . ";";
        $resulttt = $connradius->query($sqlll);

        }

    }
}
                    
             


    }
}

