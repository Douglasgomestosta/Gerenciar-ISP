<?php
session_start();
require '/var/www/html/painel/sistema/db.php'; 
require '/var/www/html/painel/sistema/FUNCTIONS.php'; 
$data = date("Y-m");
$dia = date("d");
$dia = $dia - 1;
$data = date("Y-m");
$datateste = $data . "-" . $dia;

$outrodia = $dia - 3;
$datafim = $data . "-" . $outrodia;
$sql = "SELECT * FROM `pagamentos` WHERE `vencimento` < '" . $datateste . "' AND `vencimento` > '" . $datafim . "' AND `pago` IS NULL AND `vencido` IS NOT NULL ORDER BY `id` DESC";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $vencimento = $row["vencimento"];
        $id = $row["id"];
        $checkout = $row["checkout"];
        $idusuario = $row["idusuario"];
        $sqll = "SELECT * FROM `usuarios` WHERE `id` = " . $idusuario;
$resultt = $conn->query($sqll);

            //ver se a fatura já foi paga no mercadopago
            if($checkout == "mercadopago")
            {
                $referencia = $id;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.mercadopago.com/v1/payments/search?access_token=TOKEN-MERCADO-PAGO&external_reference=' . $referencia);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch, CURLOPT_POST, 1);
//curl_setopt($ch, CURLOPT_POSTFIELDS, "{\n    \"items\": [\n        {\n            \"title\": \"Conexão a internet Data Web, fatura numero " . $idfatura . "\",\n            \"quantity\": 1,\n            \"unit_price\": " . $preco . "\n        }\n    ]\n}");
//curl_setopt($ch, CURLOPT_POSTFIELDS, "access_token=-207928615&status=approved&offset=0&limit=10`");

$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'Cache-Control: no-cache';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);


//print_r($result);
$result = json_decode( $result, FALSE );

$status = $result->results[0]->status;
            }

//$status = "approved";
            if($status == "approved")
                    {
                  
                        $sqll = "UPDATE `pagamentos` SET `pago` = '1', `pagodata` = CURRENT_TIMESTAMP WHERE `pagamentos`.`id` = " . $referencia .  ";";
                        //doacao($idusuario);
                        $resultt = $conn->query($sqll);
                    }else{
                    
            $sqll = "UPDATE `usuarios` SET `desativado` = '1' WHERE `usuarios`.`id` = " . $idusuario . ";";
            $resultt = $conn->query($sqll);
            $sqll = "UPDATE `pppoe` SET `ativo` = '0' WHERE `pppoe`.`idcliente` = " . $idusuario . ";";
            $resultt = $conn->query($sqll);

            echo criaremail("Sistema", $email, "Seu serviço foi suspenso!", "<center><H2>Como não ocorreu o pagamento de sua fatura de internet, seu serviço foi automaticamente suspenso</h2> </h3> http://painel.datawebtelecom.site/faturas");

            echo criarnotificacao($idusuario, "Seu serviço de internet foi suspenso!", "Infelizmente seu serviço foi suspenso por falta de pagamento.", "http://painel.datawebtelecom.site/");

                $connakauting = new mysqli($servername, $username, $password, "akauting");
                //$sqlakauting = "INSERT INTO `5du_invoices` (null, 1, '" . $idfaturanova . "', NULL, 'sent', CURRENT_TIMESTAMP, '" . $datacompleta . " 23:59:99', " . $preco . ".0000, 'BRL', 1.00000000, 8, 4, 'todos', NULL, NULL, NULL, 'Todos os clientes juntos', NULL, NULL, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL);";
               $sqlakauting = "DELETE FROM `5du_invoices` WHERE `5du_invoices`.`invoice_number` = '" . $id . "';";
               $resultakauting = $connakauting->query($sqlakauting);


                    }
            
        }
        
        
    }



    $sql = "INSERT INTO `cronjobs` (`id`, `datetime`, `tipo`) VALUES (NULL, current_timestamp, 'suspender');";
    $resultt = $conn->query($sql);