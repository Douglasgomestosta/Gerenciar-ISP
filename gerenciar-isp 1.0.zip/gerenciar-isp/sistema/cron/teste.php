<?php
require '../db.php'; 
$id = "1";
$preco = "100";
$desconto = 0;
$sqll = "SELECT * FROM `descontos` WHERE `idcliente` = " . $id . "  ORDER BY `id` DESC";
            $resultt = $conn->query($sqll);
            if ($resultt->num_rows > 0) {
                while($roww = $resultt->fetch_assoc()) {
                $iddesconto = $roww["id"];
                $valordesconto = $roww["valor"];
                $permanente = $roww["permanente"];
                $desconto = $desconto + $valordesconto;
                $descontosobre = " + Desconto de R$" . $desconto;

                            //Se o desconto não é vitalicio, apaga o desconto
            if(!$permanente == "1")
            {
                $sqlll = "DELETE FROM `descontos` WHERE `descontos`.`id` = " . $iddesconto;
                $resulttt = $conn->query($sqlll);
            }


            }}
$preco = $preco - $desconto;

//se sobrar desconto, ele cria um desconto com o resto do valor
if($preco < 0)
{
$novodesconto = str_replace('-', '', $preco);
$preco = "0";
$sqlll = "INSERT INTO `descontos` (`id`, `idcliente`, `valor`, `data`, `permanente`, `excluirplano`, `geradorid`, `descricao`) VALUES (NULL, '" . $id . "', '" . $novodesconto . "', CURRENT_TIMESTAMP, NULL, NULL, NULL, NULL);";
                $resulttt = $conn->query($sqlll);
}
?>