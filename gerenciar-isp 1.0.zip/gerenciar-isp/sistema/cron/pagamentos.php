<?php
session_start();
require '/var/www/html/painel/sistema/db.php'; 
require '/var/www/html/painel/sistema/FUNCTIONS.php'; 


$sql = "SELECT * FROM `usuarios` WHERE `desativado` IS NULL";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<br>-------------------------<br>";
        $vencimento = $row["vencimento"];
        $id = $row["id"];
        echo "Cliente  $id <br>";
        $plano = $row["plano"];
        $email = $row["email"];
        $dia = date("d");
        $vencimentofalta = $vencimento - $dia;
        if($vencimentofalta <= 5)
        {
            if($vencimentofalta <= -1){}else{
                echo "Vencimento:" . $vencimento . "/" . $dia . "- " . $vencimentofalta . "<br>";
                $datacompleta = date("Y-m-") . $vencimento;

//ver plano do usuario
$sqll = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";

            $resultt = $conn->query($sqll);
            if ($resultt->num_rows > 0) {
                // output data of each row
                while($roww = $resultt->fetch_assoc()) {
                    $preco = $roww["preco"];
                }
            }
                //ver se já tem fatura
            $sqll = "SELECT * FROM `pagamentos` WHERE `idusuario` = " . $id . " AND `vencimento` = '" . $datacompleta . "' ORDER BY `id` DESC";

            $resultt = $conn->query($sqll);
            if ($resultt->num_rows > 0) {
echo "<br>Já tem fatura na data</br>";
            }else{
//criar fatura se não houver
//ver se cliente tem desconto
$desconto = 0;
$sqll = "SELECT * FROM `descontos` WHERE `idcliente` = " . $id . "  ORDER BY `id` DESC";
            $resultt = $conn->query($sqll);
            if ($resultt->num_rows > 0) {
                while($roww = $resultt->fetch_assoc()) {
                $iddesconto = $roww["id"];
                $valordesconto = $roww["valor"];
                $permanente = $roww["permanente"];
                $desconto = $desconto + $valordesconto;
                $descontosobre = "<br>Desconto de R$" . $desconto;

                            //Se o desconto não é vitalicio, apaga o desconto
            if(!$permanente == "1")
            {
                $sqlll = "DELETE FROM `descontos` WHERE `descontos`.`id` = " . $iddesconto;
                $resulttt = $conn->query($sqlll);
            }


            }}
$preco = $preco - $desconto;

//se sobrar desconto, ele cria um desconto com o resto do valor
if($preco < 0)
{
$novodesconto = str_replace('-', '', $preco);
$preco = "0";
$sqlll = "INSERT INTO `descontos` (`id`, `idcliente`, `valor`, `data`, `permanente`, `excluirplano`, `geradorid`, `descricao`) VALUES (NULL, '" . $id . "', '" . $novodesconto . "', CURRENT_TIMESTAMP, NULL, NULL, NULL, NULL);";
                $resulttt = $conn->query($sqlll);
                echo "Criou sobra de desconto<br>";
}
//fim ver se cliente tem desconto

                //criar nova fatura
                if($preco < 1)
                {
                    $sqll = "INSERT INTO `pagamentos` (`id`, `idusuario`, `vencimento`, `pago`, `pagodata`, `vencido`, `valor`, `checkout`, `checkoutid`, `descricao`) VALUES (NULL, '" . $id . "', '" . $datacompleta . "', '1', '" . $datacompleta . "', NULL, '" . $preco . "', 'desconto na fatura', NULL, 'Pagamento do seu serviço de internet " . $descontosobre . "');";
                }else
                {
                $sqll = "INSERT INTO `pagamentos` (`id`, `idusuario`, `vencimento`, `pago`, `pagodata`, `vencido`, `valor`, `checkout`, `checkoutid`, `descricao`) VALUES (NULL, '" . $id . "', '" . $datacompleta . "', NULL, NULL, NULL, '" . $preco . "', NULL, NULL, 'Pagamento do seu serviço de internet " . $descontosobre . "');";
                }
                $resultt = $conn->query($sqll);
                echo "Criou a fatura!<br>";
                //enviar email avisando sobre a fatura
                echo criaremail("Sistema", $email, "Sua fatura de internet chegou!", "<center><H2>Sua fatura de internet chegou!</h2><br> <h3>Sua nova fatura de internet do desse mês já está disponivel para ser paga no painel do assinante </h3> http://painel.datawebtelecom.site/faturas");
 echo criarnotificacao($id, "Sua fatura de internet chegou!", "Sua fatura de internet desse mês já está disponivel para pagamento no aplicativo ou no site Data Web :)", "http://painel.datawebtelecom.site/faturas");

    //colocar a fatura no akauting
    $sqll = "SELECT * FROM `pagamentos` WHERE `idusuario` = " . $id . " AND `vencimento` = '" . $datacompleta . "' ORDER BY `id` DESC LIMIT 1";

    $resultt = $conn->query($sqll);
    if ($resultt->num_rows > 0) {
        while($roww = $resultt->fetch_assoc()) {
            $idfaturanova = $roww['id'];
            echo "pegou a fatura $idfaturanova ";
        }
    }
    $connakauting = new mysqli($servername, $username, $password, "akauting");
    //$sqlakauting = "INSERT INTO `5du_invoices` (null, 1, '" . $idfaturanova . "', NULL, 'sent', CURRENT_TIMESTAMP, '" . $datacompleta . " 23:59:99', " . $preco . ".0000, 'BRL', 1.00000000, 8, 4, 'todos', NULL, NULL, NULL, 'Todos os clientes juntos', NULL, NULL, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, NULL);";
   $sqlakauting = "INSERT INTO `5du_invoices` (`id`, `company_id`, `invoice_number`, `order_number`, `status`, `invoiced_at`, `due_at`, `amount`, `currency_code`, `currency_rate`, `category_id`, `contact_id`, `contact_name`, `contact_email`, `contact_tax_number`, `contact_phone`, `contact_address`, `notes`, `footer`, `parent_id`, `created_at`, `updated_at`, `deleted_at`) VALUES (NULL, '1', '" . $idfaturanova . "', null, 'sent', CURRENT_TIMESTAMP, '" . $datacompleta . " 23:59:59', '" . $preco . "', 'BRL', '1.00000000', '8', '4', 'todos', null, null, null, '" . $id . "', NULL, NULL, '0', CURRENT_TIMESTAMP, NULL, NULL);";
   $resultakauting = $connakauting->query($sqlakauting);
    //fim colocar a fatura no akauting

}

            }
            



        }
        }
        
    }



$sql = "INSERT INTO `cronjobs` (`id`, `datetime`, `tipo`) VALUES (NULL, current_timestamp, 'pagamentos');";
    $resultt = $conn->query($sql);
