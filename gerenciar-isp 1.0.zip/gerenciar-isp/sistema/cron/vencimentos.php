<?php
session_start();
require 'D:\isp\sistema\db.php'; 
require 'D:\isp\sistema\FUNCTIONS.php'; 
$data = date("Y-m-d");
$sql = "SELECT * FROM `pagamentos` WHERE `vencimento` < '" . $data . "' AND `pago` IS NULL AND `vencido` IS NULL";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $vencimento = $row["vencimento"];
        $id = $row["id"];
        $checkout = $row["checkout"];
        $idusuario = $row["idusuario"];

        $sqll = "SELECT * FROM `usuarios` WHERE `id` = " . $idusuario;
$resultt = $conn->query($sqll);
if ($resultt->num_rows > 0) {
    while($roww = $resultt->fetch_assoc()) {
    $email = $roww["email"];
    }
}


      
            //ver se a fatura já foi paga no mercadopago
            if($checkout == "mercadopago")
            {
                $referencia = $id;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.mercadopago.com/v1/payments/search?access_token=TOKEN-MERCADO-PAGO&external_reference=' . $referencia);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch, CURLOPT_POST, 1);
//curl_setopt($ch, CURLOPT_POSTFIELDS, "{\n    \"items\": [\n        {\n            \"title\": \"Conexão a internet Data Web, fatura numero " . $idfatura . "\",\n            \"quantity\": 1,\n            \"unit_price\": " . $preco . "\n        }\n    ]\n}");
//curl_setopt($ch, CURLOPT_POSTFIELDS, "access_token=A78f027ca140-207928615&status=approved&offset=0&limit=10`");

$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'Cache-Control: no-cache';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);


//print_r($result);
$result = json_decode( $result, FALSE );

$status = $result->results[0]->status;
            }

//$status = "approved";
            if($status == "approved")
                    {
                  //cliente pagou a fatura
                        $sqll = "UPDATE `pagamentos` SET `pago` = '1', `pagodata` = CURRENT_TIMESTAMP WHERE `pagamentos`.`id` = " . $referencia .  ";";
                        doacao($idusuario);
                    }else{
                    //cliente não pagou a fatura
            $sqll = "UPDATE `pagamentos` SET `vencido` = '1' WHERE `pagamentos`.`id` = " . $id . ";";
            echo criaremail("Sistema", $email, "Sua fatura de internet está vencida!", "<center><H2>Sua fatura de internet está vencida!</h2><br> <h3>O prazo de pagamento de sua fatura de internet está vencida, se não houver o pagamento da mesma em até 2 dias apos o vencimento, o seu serviço será automaticamente cancelado. </h3> http://painel.datawebtelecom.site/faturas");

            echo criarnotificacao($idusuario, "Sua fatura de internet está vencida!", "Infelizmente sua fatura de internet está vencida, caso ocorra o não pagamento pelos proximos 2 dias do vencimento o seu serviço será automaticamente cancelado.", "http://painel.datawebtelecom.site/faturas");

                    }
            $resultt = $conn->query($sqll);
        }
        
        
    }


    $sql = "INSERT INTO `cronjobs` (`id`, `datetime`, `tipo`) VALUES (NULL, current_timestamp, 'vencimentos');";
    $resultt = $conn->query($sql);