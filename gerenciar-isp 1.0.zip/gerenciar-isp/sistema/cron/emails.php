<?php
require '/var/www/html/painel/sistema/db.php'; 
$sql = "SELECT * FROM `emails` ORDER BY `id` ASC LIMIT 25";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $destino = $row["destino"];
        $sobre = $row["sobre"];
        $texto = $row["texto"];
        $from = "douglasgomestosta@gmail.com";
    $to = "test@hostinger.com";
    $subject = "Checking PHP mail";
    $message = "PHP mail works just fine";
    $headers = "From:" . $from;
    mail($destino,$sobre,$texto, $headers);
    }
}
?>