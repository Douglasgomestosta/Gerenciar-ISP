<?php
session_start();
require '/var/www/html/painel/sistema/db.php'; 



$sql = "DELETE FROM `radcheck`";
    //$result = $connradius->query($sql);

    $sql = "DELETE FROM `radreply`";
    //$result = $connradius->query($sql);




$sql = "SELECT * FROM `usuarios` WHERE `desativado` IS NULL";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {

   
//ver velocidade do plano do usuario///
$sqll = "SELECT * FROM `planos` WHERE `id` LIKE '" . $row["plano"] . "'";
$resultt = $conn->query($sqll);
if ($resultt->num_rows > 0) {
    while($roww = $resultt->fetch_assoc()) {

        $hora = date("H:i:s");
        if($hora >= "00:00:00" && $hora <= "06:00:00")
        {
            $velocidade = $roww["velocidade"];
            $velocidade = $velocidade * 2;
            $velocidade = $velocidade . "000/" . $velocidade . "000";
        }else
        {
            $velocidade = $roww["velocidade"] . "000/" . $roww["velocidade"] . "000";
        }



    
    }
}
//fim


        $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $row["id"];
        $resultl = $conn->query($sqll);
        if ($resultl->num_rows > 0) {
            // output data of each row
            while($rowl = $resultl->fetch_assoc()) {

            $idpppoe = $rowl["id"];
            $usuariopppoe = $rowl["usuario"];
            $senhapppoe = $rowl["senha"];
            $ippppoe = $rowl["ip"];
            $servidor = $rowl["servidor"];
//deletar dados velhos
$sqldeletar = "DELETE FROM `radcheck` WHERE `radcheck`.`id` = " . $idpppoe;
$deletado = $connradius->query($sqldeletar);
$sqldeletar = 'DELETE FROM radreply WHERE username = "' . $usuariopppoe . '";';
$deletado = $connradius->query($sqldeletar);
//fim deletar dados velhos
            //dns
            $bloqueiovirus = $rowl["bloqueiovirus"];
            $bloqueioadulto = $rowl["bloqueioadulto"];

            if($bloqueiovirus == "0" && $bloqueioadulto == "0"){$dns = "1.1.1.1"; $dnssecundario = "1.0.0.1";}
            if($bloqueiovirus == "1" && $bloqueioadulto == "0"){$dns = "1.1.1.2"; $dnssecundario = "1.0.0.2";}
            if($bloqueiovirus == "1" && $bloqueioadulto == "1"){$dns = "1.1.1.3"; $dnssecundario = "1.0.0.3";}
            //fim dns
            $sqll = "INSERT INTO `radcheck` (`id`, `username`, `attribute`, `op`, `value`) VALUES ('" . $idpppoe . "', '" . $usuariopppoe . "', 'Cleartext-Password', ':=', '" . $senhapppoe . "');";
        if (!$connradius->query($sqll)) { echo("Error description: " . $connradius->error);}



        //radreply
        $sqll = "INSERT INTO `radreply` (`id`, `username`, `attribute`, `op`, `value`) VALUES (NULL, '" . $usuariopppoe . "', 'Framed-IP-Address', ':=', '" . $ippppoe . "');";
        if (!$connradius->query($sqll)) { echo("Error description: " . $connradius->error);}
        





          $sqll = "INSERT INTO `radreply` (`id`, `username`, `attribute`, `op`, `value`) VALUES (NULL, '" . $usuariopppoe . "', 'Simultaneous-Use', ':=', '1');";
          if (!$connradius->query($sqll)) { echo("Error description: " . $connradius->error);}
          
  


          $sqll = "INSERT INTO `radreply` (`id`, `username`, `attribute`, `op`, `value`) VALUES (NULL, '" . $usuariopppoe . "', 'Acct-Interim-Interval', ':=', '20');";
          if (!$connradius->query($sqll)) { echo("Error description: " . $connradius->error);}
          
   

        
          $sqll = "INSERT INTO `radreply` (`id`, `username`, `attribute`, `op`, `value`) VALUES (NULL, '" . $usuariopppoe . "', 'Filter-Id', ':=', '" . $velocidade . "');";
          if (!$connradius->query($sqll)) { echo("Error description: " . $connradius->error);}
          
   


          $sqll = "INSERT INTO `radreply` (`id`, `username`, `attribute`, `op`, `value`) VALUES (NULL, '" . $usuariopppoe . "', 'MS-Primary-DNS-Server', ':=', '" . $dns . "');";
          if (!$connradius->query($sqll)) { echo("Error description: " . $connradius->error);}
          
        


          $sqll = "INSERT INTO `radreply` (`id`, `username`, `attribute`, `op`, `value`) VALUES (NULL, '" . $usuariopppoe . "', 'MS-Secondary-DNS-Server', ':=', '" . $dnssecundario . "');";
          if (!$connradius->query($sqll)) { echo("Error description: " . $connradius->error);}
          
     

          $sqll = "SELECT * FROM `servidores` WHERE `id` = " . $servidor;
          $resultt = $conn->query($sqll);
          if ($resultt->num_rows > 0) {
              // output data of each row
              while($roww = $resultt->fetch_assoc()) {
                  $ipservidor = $roww["ipprivado"];
                  $secret = $roww["secret"];

                  
                  shell_exec('echo "User-Name=' . $usuariopppoe . ',Filter-Id=' . $velocidade .  '" | radclient ' . $ipservidor . ':3799 coa ' . $secret);

//echo 'echo "User-Name=' . $usuariopppoe . ',Filter-Id=' . $velocidade .  '" | radclient ' . $ipservidor . ':3799 coa ' . $secret;
                  


              }
          }

         




            }
        }



    }
}












///desconectar usuarios pppoe cancelados
$sql = "SELECT * FROM `usuarios` WHERE `desativado` IS NOT NULL";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {

        $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $row["id"];
        $resultl = $conn->query($sqll);
        if ($resultl->num_rows > 0) {
            // output data of each row
            while($rowl = $resultl->fetch_assoc()) {
                $usuariopppoe = $rowl["usuario"];
                $servidor = $rowl["servidor"];
                $idpppoe = $rowl["id"];

                //deletar dados velhos
$sqldeletar = "DELETE FROM `radcheck` WHERE `radcheck`.`id` = " . $idpppoe;
$deletado = $connradius->query($sqldeletar);
$sqldeletar = 'DELETE FROM radreply WHERE username = "' . $usuariopppoe . '";';
$deletado = $connradius->query($sqldeletar);
//fim deletar dados velhos


                $sqll = "SELECT * FROM `servidores` WHERE `id` = " . $servidor;
                $resultt = $conn->query($sqll);
                if ($resultt->num_rows > 0) {
                    // output data of each row
                    while($roww = $resultt->fetch_assoc()) {
                        $ipservidor = $roww["ipprivado"];
                        $secret = $roww["secret"];
                        shell_exec('echo "User-Name=' . $usuariopppoe . ',Filter-Id=25/25" | radclient ' . $ipservidor . ':3799 coa ' . $secret);
                        shell_exec('echo "User-Name=' . $usuariopppoe . '" | radclient -x ' . $ipservidor . ':3799 disconnect ' . $secret);
//echo "<br>" . 'echo "User-Name=' . $usuariopppoe . '" | radclient -x ' . $ipservidor . ':3799 disconnect ' . $secret;


                    }
                }



            }
        }

    }
}
//fim 

