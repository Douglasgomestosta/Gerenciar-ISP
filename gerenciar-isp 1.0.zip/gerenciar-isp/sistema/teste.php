<?php
require 'db.php'; 
$stmt = $conn->prepare("SELECT * FROM `usuarios` WHERE `email` = ?");

// depois de nosso statement estar preparado com a string da query e as interrogações
// nós iremos definir quais variaveis entram em quais lugares, e seus tipos
// através da função ->bind_param(string de tipos, ...variaveis em ordem da interrogação )
$email = "douglasgomestosta@gmail.com";
$stmt->bind_param('s', $email);
// ps: a "string de tipos" que é o primeiro parametro é composta pela inicial dos tipos
//     das variáveis que estão sendo adicionadas. 

// Os tipos permitidos são: 
//    i  -  variaveis inteiras
//    d  -  variaveis double
//    s  -  variaveis string
//    b  -  variaveis que fornecem dados para um blob

// após definirmos quais variáveis entraram em quais lugares, 
// nós executamos nosso statement
/* execute query */
$stmt->execute();
/* Store the result (to get properties) */
$stmt->store_result();

/* Get the number of rows */
$num_of_rows = $stmt->num_rows;

/* Bind the result to variables */
$stmt->bind_result($id, $first_name, $last_name, $username);

while ($stmt->fetch()) {
     echo 'ID: '.$id.'<br>';
     echo 'First Name: '.$first_name.'<br>';
     echo 'Last Name: '.$last_name.'<br>';
     echo 'Username: '.$username.'<br><br>';
}

/* free results */
$stmt->free_result();

/* close statement */
$stmt->close();