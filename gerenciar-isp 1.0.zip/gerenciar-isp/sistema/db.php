<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "painel";
$versao = "BETA 1.0";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    header('Location: ../errodb.php');
    exit();
}


//database radius
// Create connection
$connradius = new mysqli($servername, $username, $password, "radius");
// Check connection
if ($connradius->connect_error) {
    header('Location: ../errodb.php');
    exit();
}
$conn->set_charset('utf8');