<li>
                        <a  href="../painel.php"><i class=""></i> Inicio</a>
                    </li>
                      <li>
                        <a  href="../suporte/index.php"><i class=""></i>Pedidos de suporte</a>
                    </li>
                    <li>
                        <a  href="../firewall.php"><i class=""></i>Configurações do Firewall</a>
                    </li>
						   <li  >
                        <a  href="../mudanca.php"><i class=""></i>Trocar de endereço</a>
                    </li>	
                      <li  >
                        <a  href="../mudarplano.php"><i class=""></i>Trocar de plano</a>
                    </li>
                    <li  >
                        <a  href="../cancelar.php"><i class=""></i>Cancelar serviço</a>
                    </li>	

                    <li  >
                        <a  href="../perfil.php"><i class=""></i>Modificar meus dados pessoais</a>
                    </li>  


                    <li>
                        <a href="#"><i class=""></i> Roteador<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="../wifi.php">Dados do WI-FI</a>
                            </li>
                            <li>
                                <a href="../pppoe.php">Dados do PPPoE</a>
                            </li>

                            <li>
                            <a  href="../conexoes.php">Tentativas de conexão</a>
                            </li>
                           
                        </ul>
                      </li> 



                    <li  >
                        <a  href="../faturas.php"><i class=""></i>Pagamentos</a>
                    </li>

                    <?php
$cont = 0;
$sql = "SELECT * FROM `notificacoes` WHERE `idusuario` = " . $id . " AND `exibido` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>

                    <li  >
                        <a  href="../notify.php"><i class=""></i>Notificações(<?php echo $cont; ?>)</a>
                    </li>
					

                     

                           <li  >
                        <a  href="../features.php"><i class=""></i>Features</a>
                    </li>             
                    
                  <li  >
                        <a class="active-menu"  href="blank.html"><i class=""></i> Blank Page</a>
                    </li>	
                </ul>