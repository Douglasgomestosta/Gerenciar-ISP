<?php
//$sql = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usuariopppoe . "' ORDER BY `acctstarttime` DESC LIMIT 1";
$sql = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usuariopppoe . "' ORDER BY `radacctid` DESC limit 1";
    $result = $connradius->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $idacct = $row["radacctid"];
            $stoptime = $row["acctstoptime"];
            $starttime = $row["acctstarttime"];
            $motivodesconect = $row["acctterminatecause"];
        }
    }else{
        $nuncaconectou = "1";
    }
    if(empty($motivodesconect)){
        $desconectado = 0;
    }else
    {
        $desconectado = 1;
    }
    if($motivodesconect == "Lost-Service") {$motivodesconect = "Perda da conexão com o roteador";}
        if($motivodesconect == "Lost-Carrier") {$motivodesconect = "Perda da conexão com o roteador";}
        if($motivodesconect == "User-Request") {$motivodesconect = "Desconectado pelo usuario";}
        $array=explode("-",$stoptime);
$mes = $array[1];
$dia = $array[2];
$arrayy=explode(" ",$dia);
$dia = $arrayy[0];
$hora = $arrayy[1];
$ano = $array[0];
$stoptime =  "$dia/$mes/$ano as $hora";

$array=explode("-",$stoptime);
$mes = $array[1];
$dia = $array[2];
$arrayy=explode(" ",$dia);
$dia = $arrayy[0];
$hora = $arrayy[1];
$ano = $array[0];
$stoptime =  "$dia/$mes/$ano as $hora";
$array=explode("-",$starttime);
$mes = $array[1];
$dia = $array[2];
$arrayy=explode(" ",$dia);
$dia = $arrayy[0];
$hora = $arrayy[1];
$ano = $array[0];
$starttime =  "$dia/$mes/$ano as $hora";
