-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 12/08/2020 às 22:10
-- Versão do servidor: 5.7.31-0ubuntu0.18.04.1
-- Versão do PHP: 7.2.24-0ubuntu0.18.04.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `painel`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `adesao`
--

CREATE TABLE `adesao` (
  `id` int(11) NOT NULL,
  `email` varchar(244) NOT NULL,
  `nome` varchar(244) NOT NULL,
  `senha` varchar(244) NOT NULL,
  `cep` varchar(244) NOT NULL,
  `numero` varchar(244) NOT NULL,
  `sobreacasa` varchar(244) DEFAULT NULL,
  `plano` varchar(244) NOT NULL,
  `cpf` varchar(244) NOT NULL,
  `roteador` varchar(244) NOT NULL,
  `datapedido` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `andamento` int(244) NOT NULL,
  `tecnico` int(244) NOT NULL,
  `cancelado` int(244) NOT NULL,
  `resposta` varchar(244) NOT NULL,
  `horario` varchar(244) NOT NULL,
  `finalizadodata` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `admins`
--

CREATE TABLE `admins` (
  `id` int(244) NOT NULL,
  `email` varchar(244) NOT NULL,
  `senha` varchar(244) NOT NULL,
  `nome` varchar(244) NOT NULL,
  `nivel` int(11) NOT NULL,
  `cidade` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `admins`
--

INSERT INTO `admins` (`id`, `email`, `senha`, `nome`, `nivel`, `cidade`) VALUES
(1, 'douglasgomestosta@gmail.com', 'd7c617850d8aaef3fe0f599e7752270d', 'Douglas Gomes', 1, 'seropedica');

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas`
--

CREATE TABLE `agendas` (
  `id` int(244) NOT NULL,
  `idadmin` int(244) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tipo` int(244) NOT NULL,
  `idtipo` int(244) DEFAULT NULL,
  `resolvido` int(244) DEFAULT NULL,
  `resolvidodata` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Despejando dados para a tabela `agendas`
--

INSERT INTO `agendas` (`id`, `idadmin`, `data`, `tipo`, `idtipo`, `resolvido`, `resolvidodata`) VALUES
(2, 1, '2020-07-31 10:00:00', 1, 12, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `Artérias`
--

CREATE TABLE `Artérias` (
  `id` varchar(244) NOT NULL,
  `capacidade` varchar(244) NOT NULL,
  `tipo` varchar(244) NOT NULL,
  `rotas` varchar(244) NOT NULL,
  `atendendo` varchar(244) NOT NULL,
  `mapa` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `Artérias`
--

INSERT INTO `Artérias` (`id`, `capacidade`, `tipo`, `rotas`, `atendendo`, `mapa`) VALUES
('1', '0.1', 'UTP', '23894-786', '23894-786', 'n/a');

-- --------------------------------------------------------

--
-- Estrutura para tabela `autenticacoes`
--

CREATE TABLE `autenticacoes` (
  `id` int(244) NOT NULL,
  `idcliente` int(244) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `navegador` varchar(244) COLLATE utf8_bin NOT NULL,
  `ip` varchar(244) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Despejando dados para a tabela `autenticacoes`
--

INSERT INTO `autenticacoes` (`id`, `idcliente`, `data`, `navegador`, `ip`) VALUES
(3, 1, '2020-06-28 08:36:13', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/81.0.4044.138 Chrome/81.0.4044.138 Safari/537.36', ''),
(4, 1, '2020-06-28 09:49:49', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/81.0.4044.138 Chrome/81.0.4044.138 Safari/537.36', ''),
(5, 1, '2020-07-04 18:46:58', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/81.0.4044.138 Chrome/81.0.4044.138 Safari/537.36', ''),
(6, 1, '2020-07-07 00:28:36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/81.0.4044.138 Chrome/81.0.4044.138 Safari/537.36', ''),
(7, 1, '2020-07-12 21:59:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.191', ''),
(8, 1, '2020-07-14 04:44:19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.191', ''),
(9, 1, '2020-07-14 05:09:53', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.191', ''),
(10, 1, '2020-07-14 05:12:49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.191', ''),
(11, 1, '2020-07-14 05:13:54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.191', ''),
(12, 1, '2020-07-14 05:25:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.191', ''),
(13, 1, '2020-07-14 05:32:28', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36', ''),
(14, 1, '2020-07-14 05:36:17', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36', ''),
(15, 1, '2020-07-14 05:37:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.191', ''),
(16, 1, '2020-07-14 05:54:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.191', ''),
(17, 1, '2020-07-14 11:20:50', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36', ''),
(18, 1, '2020-07-15 23:58:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.191', ''),
(19, 1, '2020-07-16 01:26:09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.191', ''),
(20, 1, '2020-07-19 18:35:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.197', ''),
(21, 1, '2020-07-19 18:41:22', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Mobile Safari/537.36', ''),
(22, 1, '2020-07-19 19:10:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.197', ''),
(23, 1, '2020-07-20 09:26:58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.197', ''),
(24, 1, '2020-07-20 10:43:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.197', ''),
(25, 1, '2020-07-20 10:59:04', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Mobile Safari/537.36', ''),
(26, 1, '2020-07-24 07:48:07', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.197', ''),
(27, 1, '2020-07-25 21:06:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.206', ''),
(28, 1, '2020-07-27 21:13:27', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Mobile Safari/537.36', ''),
(29, 1, '2020-07-27 21:31:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.206', ''),
(30, 1, '2020-07-28 04:20:10', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.206', ''),
(31, 1, '2020-07-30 05:02:15', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Mobile Safari/537.36', ''),
(32, 1, '2020-08-02 22:48:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.206', ''),
(33, 1, '2020-08-03 02:31:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.206', ''),
(34, 1, '2020-08-05 09:39:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.206', ''),
(35, 1, '2020-08-06 02:04:12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.206', ''),
(36, 1, '2020-08-06 06:02:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.206', ''),
(37, 1, '2020-08-06 06:15:41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.206', ''),
(38, 1, '2020-08-11 12:36:06', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', ''),
(39, 1, '2020-08-11 12:36:22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', ''),
(40, 1, '2020-08-12 08:49:08', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.206', ''),
(41, 1, '2020-08-12 15:22:15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', ''),
(42, 1, '2020-08-12 16:35:01', 'Mozilla/5.0 (Linux; Android 7.1.1; Moto E (4) Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `caixas`
--

CREATE TABLE `caixas` (
  `id` int(244) NOT NULL,
  `cep` varchar(244) NOT NULL,
  `poste` varchar(244) DEFAULT NULL,
  `Tamanho` varchar(244) NOT NULL,
  `switch` varchar(244) NOT NULL,
  `tecnologia` varchar(244) NOT NULL,
  `portas` varchar(244) NOT NULL,
  `porta1` varchar(244) NOT NULL,
  `porta2` varchar(244) NOT NULL,
  `porta3` varchar(244) NOT NULL,
  `porta4` varchar(244) NOT NULL,
  `porta5` varchar(244) NOT NULL,
  `porta6` varchar(244) NOT NULL,
  `porta7` varchar(244) NOT NULL,
  `porta8` varchar(244) NOT NULL,
  `porta9` varchar(244) NOT NULL,
  `porta10` varchar(244) NOT NULL,
  `porta11` varchar(244) NOT NULL,
  `porta12` varchar(244) NOT NULL,
  `porta13` varchar(244) NOT NULL,
  `porta14` varchar(244) NOT NULL,
  `porta15` varchar(244) NOT NULL,
  `porta16` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `caixas`
--

INSERT INTO `caixas` (`id`, `cep`, `poste`, `Tamanho`, `switch`, `tecnologia`, `portas`, `porta1`, `porta2`, `porta3`, `porta4`, `porta5`, `porta6`, `porta7`, `porta8`, `porta9`, `porta10`, `porta11`, `porta12`, `porta13`, `porta14`, `porta15`, `porta16`) VALUES
(1, '23894-786', NULL, '100', 'SWITCH 8 PORTAS 10/100 VLAN POE 2FLEX 2F-1008V', 'utp', '8', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cancelamentos`
--

CREATE TABLE `cancelamentos` (
  `idcliente` varchar(244) NOT NULL,
  `data` varchar(244) NOT NULL,
  `motivo` varchar(244) NOT NULL,
  `andamento` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura para tabela `configs`
--

CREATE TABLE `configs` (
  `novasadesao` int(11) NOT NULL,
  `bandamaxima` int(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `configs`
--

INSERT INTO `configs` (`novasadesao`, `bandamaxima`) VALUES
(1, 100);

-- --------------------------------------------------------

--
-- Estrutura para tabela `descontos`
--

CREATE TABLE `descontos` (
  `id` int(244) NOT NULL,
  `idcliente` int(244) NOT NULL,
  `valor` int(244) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `permanente` int(244) DEFAULT NULL,
  `geradorid` int(244) DEFAULT NULL,
  `descricao` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Despejando dados para a tabela `descontos`
--

INSERT INTO `descontos` (`id`, `idcliente`, `valor`, `data`, `permanente`, `geradorid`, `descricao`) VALUES
(2, 1, 100, '2020-08-11 20:07:13', 1, NULL, 'internet de graça para mim =D');

-- --------------------------------------------------------

--
-- Estrutura para tabela `emails`
--

CREATE TABLE `emails` (
  `id` varchar(244) NOT NULL,
  `solicitante` varchar(244) NOT NULL,
  `destino` varchar(244) NOT NULL,
  `sobre` varchar(244) NOT NULL,
  `texto` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `emails`
--

INSERT INTO `emails` (`id`, `solicitante`, `destino`, `sobre`, `texto`) VALUES
('1', 'Douglas Gomes', 'apkedition@gmail.com', 'Mudança de velocidade da sua internet', 'Parabens! a sua velocidade de internet recebeu um Upgrade, de 25 megas, agora você tem 50 Megas! mantendo o mesmo preço de antes, aproveite<3');

-- --------------------------------------------------------

--
-- Estrutura para tabela `features`
--

CREATE TABLE `features` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `nome` varchar(244) COLLATE utf8_bin NOT NULL,
  `sobre` text COLLATE utf8_bin NOT NULL,
  `categoria` int(11) NOT NULL,
  `solucionado` int(11) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `resposta` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Despejando dados para a tabela `features`
--

INSERT INTO `features` (`id`, `userid`, `nome`, `sobre`, `categoria`, `solucionado`, `data`, `resposta`) VALUES
(1, 1, 'aaa   and delete   ', 'seila     caramba        -se mano    ', 1, 0, '2020-06-27 13:41:14', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `mudancas`
--

CREATE TABLE `mudancas` (
  `id` int(244) NOT NULL,
  `idcliente` int(244) NOT NULL,
  `cepantigo` varchar(244) NOT NULL,
  `numeroantigo` int(244) NOT NULL,
  `cepnovo` varchar(244) NOT NULL,
  `numeronovo` int(244) NOT NULL,
  `andamento` int(244) NOT NULL,
  `data` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `notas_fiscais`
--

CREATE TABLE `notas_fiscais` (
  `id` int(244) NOT NULL,
  `nome` varchar(244) NOT NULL,
  `preco` varchar(244) NOT NULL,
  `foto` varchar(244) NOT NULL,
  `data` date NOT NULL,
  `codigo` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `notas_fiscais`
--

INSERT INTO `notas_fiscais` (`id`, `nome`, `preco`, `foto`, `data`, `codigo`) VALUES
(1, '1x caixa hermetica, 2x switch 10/100mbs 2flex, alicate de crimprar rj45, 50x conectores rj45', '124,70', 'https://drive.google.com/open?id=1CukLGcoy4ElzZa0qpL3veT4I7B7ifqiT', '2020-01-11', '3319 1230 6107 4600 0188 5500 1000 0010 5910 0091 9689'),
(2, 'Maquina de cartão mercadopago', '19,90', 'https://drive.google.com/drive/u/0/folders/1XN-P9rzv93H-qVTC9X1Ngc00OceNqxcK', '2020-01-11', '3520 0129 3181 0800 0109 5500 2000 0402 0019 2357 5314'),
(3, '2 Fita Bap', '58,40', '', '2020-01-21', '5220 0129 7192 8500 0105 5500 1000 0054 6811 1814 9684'),
(4, 'esticador cabo drop + testador de cabos rj45 + conector 2flex gold 25', '68,30', 'https://drive.google.com/file/d/1fL9gyqHJIDJtFHTtLVm0WzTdn6YCS_oI/view?usp=sharing', '2020-06-12', '3320 0630 6107 4600 0188 5500 1000 0014 7410 0108 6780'),
(5, 'Panfletos', '95,95', 'https://drive.google.com/file/d/1_Ljx2hdlvUFpFUY29mknWnqTWZRiHj6r/view?usp=sharing', '2020-07-31', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `notificacaorua`
--

CREATE TABLE `notificacaorua` (
  `id` int(244) NOT NULL,
  `email` varchar(244) COLLATE utf8_bin NOT NULL,
  `cep` varchar(244) COLLATE utf8_bin NOT NULL,
  `casa` varchar(244) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Despejando dados para a tabela `notificacaorua`
--

INSERT INTO `notificacaorua` (`id`, `email`, `cep`, `casa`) VALUES
(5, 'douglasgomestosta@gmail.com', '23894-886', '23'),
(6, 'sadsad@gm.com', '2-123', '123213');

-- --------------------------------------------------------

--
-- Estrutura para tabela `notificacoes`
--

CREATE TABLE `notificacoes` (
  `id` int(244) NOT NULL,
  `idusuario` int(244) NOT NULL,
  `texto` varchar(244) NOT NULL,
  `conteudo` longtext NOT NULL,
  `exibido` int(244) NOT NULL,
  `sms` int(244) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `notificacoes`
--

INSERT INTO `notificacoes` (`id`, `idusuario`, `texto`, `conteudo`, `exibido`, `sms`, `data`) VALUES
(10, 1, 'Problema resolvidoo', 'Seu problema de perda de pacotes já foi solucionado! agradecemos por escolher a Data Web como sua provedora de acesso a internet! <3', 1, 1, '2020-05-22 15:02:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pagamentos`
--

CREATE TABLE `pagamentos` (
  `id` int(244) NOT NULL,
  `idusuario` int(244) NOT NULL,
  `vencimento` date NOT NULL,
  `pago` int(244) DEFAULT NULL,
  `pagodata` date DEFAULT NULL,
  `vencido` int(11) DEFAULT NULL,
  `valor` text COLLATE utf8_bin NOT NULL,
  `checkout` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `checkoutid` varchar(244) COLLATE utf8_bin DEFAULT NULL,
  `descricao` varchar(244) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Despejando dados para a tabela `pagamentos`
--

INSERT INTO `pagamentos` (`id`, `idusuario`, `vencimento`, `pago`, `pagodata`, `vencido`, `valor`, `checkout`, `checkoutid`, `descricao`) VALUES
(4, 1, '2020-06-24', 1, '2020-07-20', NULL, '80', 'mercadopago', '1', NULL),
(8, 2, '2020-08-19', NULL, NULL, NULL, '80', NULL, NULL, 'Pagamento da seu serviÃ§o de internet'),
(9, 1, '2020-06-24', 1, NULL, NULL, '80', 'mercadopago', '207928615-5879b486-3863-4289-ae6e-d93ab94409a8', 'Pagamento do seu serviÃ§o de internet'),
(10, 1, '2020-07-29', NULL, NULL, 1, '120', 'mercadopago', '207928615-9b5a8588-ab23-407b-941e-213170faa51d', 'Pagamento do seu serviÃ§o de internet'),
(11, 1, '2020-08-06', NULL, NULL, NULL, '10', 'mercadopago', '207928615-da3dc08c-29b0-40d4-8e9d-2954f0b25127', NULL),
(23, 1, '2020-08-15', 1, '2020-08-15', NULL, '-20', 'desconto na fatura', NULL, 'Pagamento do seu serviÃ§o de internet  + Desconto de R$100');

-- --------------------------------------------------------

--
-- Estrutura para tabela `planos`
--

CREATE TABLE `planos` (
  `id` int(244) NOT NULL,
  `nome` varchar(244) NOT NULL,
  `velocidade` varchar(244) NOT NULL,
  `velocidademinima` varchar(244) NOT NULL,
  `preco` varchar(244) NOT NULL,
  `scm` int(244) DEFAULT NULL,
  `tecnologia` varchar(244) NOT NULL,
  `visivel` int(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `planos`
--

INSERT INTO `planos` (`id`, `nome`, `velocidade`, `velocidademinima`, `preco`, `scm`, `tecnologia`, `visivel`) VALUES
(1, 'internet 25 + Serviços de suporte de rede', '25', '10', '80', 40, 'utp', 1),
(2, 'internet 35  + Serviços de suporte de rede', '35', '14', '100', 60, 'utp', 1),
(3, 'internet 50  + Serviços de suporte de rede', '50', '20', '120', 80, 'utp', 1),
(4, 'Conexão a internet 35 Megas + Clube de vantagens Data Web', '35', '14', '100', 60, 'utp', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pppoe`
--

CREATE TABLE `pppoe` (
  `id` bigint(255) NOT NULL,
  `idcliente` int(244) NOT NULL,
  `usuario` varchar(244) NOT NULL,
  `senha` varchar(244) NOT NULL,
  `ip` varchar(244) NOT NULL,
  `ipv6` varchar(244) DEFAULT NULL,
  `plano` int(244) NOT NULL,
  `roteador` varchar(244) NOT NULL,
  `mac` varchar(244) NOT NULL,
  `ativo` int(244) NOT NULL,
  `bloqueiovirus` int(244) NOT NULL,
  `bloqueioadulto` int(244) NOT NULL,
  `ssidwifi` varchar(244) NOT NULL,
  `senhawifi` varchar(244) NOT NULL,
  `servidor` int(244) NOT NULL,
  `onu` varchar(244) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `pppoe`
--

INSERT INTO `pppoe` (`id`, `idcliente`, `usuario`, `senha`, `ip`, `ipv6`, `plano`, `roteador`, `mac`, `ativo`, `bloqueiovirus`, `bloqueioadulto`, `ssidwifi`, `senhawifi`, `servidor`, `onu`) VALUES
(1, 1, 'roteador', '26823352', '192.168.2.1', '', 1, 'n/a', 'n/a', 1, 0, 0, 'Data Web provedor de internet', '095901372908', 1, ''),
(2, 2, 'douglas', '26823352', '192.168.2.2', '', 1, 'n/a', 'n/a', 1, 1, 0, '', '', 1, ''),
(6, 7, 'gabriel', '123456', '192.168.2.3', '', 2, 'n/a', 'n/a', 1, 0, 0, '', '', 1, '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `problemas`
--

CREATE TABLE `problemas` (
  `id` int(244) NOT NULL,
  `firewall` int(244) NOT NULL,
  `titulo` varchar(244) COLLATE utf8_bin NOT NULL,
  `sobre` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Despejando dados para a tabela `problemas`
--

INSERT INTO `problemas` (`id`, `firewall`, `titulo`, `sobre`) VALUES
(1, 1, 'Sobrecarga na rede por COVID-19', 'Devido a COVID-19, estamos com uma sobrecarga em nossa rede, causando lentidão em horários de picos, estamos fazendo o possível para resolver todos os problemas.');

-- --------------------------------------------------------

--
-- Estrutura para tabela `ruas`
--

CREATE TABLE `ruas` (
  `id` int(11) NOT NULL,
  `cep` varchar(244) NOT NULL,
  `rua` varchar(244) NOT NULL,
  `cidade` varchar(244) NOT NULL,
  `bairro` varchar(244) NOT NULL,
  `cabo` varchar(244) NOT NULL,
  `capacidade` varchar(244) NOT NULL,
  `disponivel` varchar(244) NOT NULL,
  `rota` int(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `ruas`
--

INSERT INTO `ruas` (`id`, `cep`, `rua`, `cidade`, `bairro`, `cabo`, `capacidade`, `disponivel`, `rota`) VALUES
(1, '23894-786', 'Rua jose pereira dos santos', 'seropedica', 'Boa esperança', 'CAT5E', '100', '1', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `servidores`
--

CREATE TABLE `servidores` (
  `id` int(244) NOT NULL,
  `ippublico` varchar(244) COLLATE utf8_bin NOT NULL,
  `ipprivado` varchar(244) COLLATE utf8_bin NOT NULL,
  `firewall` varchar(244) COLLATE utf8_bin NOT NULL,
  `secret` varchar(244) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Despejando dados para a tabela `servidores`
--

INSERT INTO `servidores` (`id`, `ippublico`, `ipprivado`, `firewall`, `secret`) VALUES
(1, '0', '192.168.0.108', 'vyos', 'usuario26823352');

-- --------------------------------------------------------

--
-- Estrutura para tabela `suporte`
--

CREATE TABLE `suporte` (
  `id` int(244) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nome_cliente` varchar(244) NOT NULL,
  `problema` varchar(244) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `categoria` varchar(244) NOT NULL,
  `status` varchar(244) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Log` text NOT NULL,
  `idcliente` varchar(244) NOT NULL,
  `Resposta` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `respostacliente` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `atendente` int(244) NOT NULL,
  `resolvidodata` datetime DEFAULT NULL,
  `tipoproblema` int(244) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `suporte`
--

INSERT INTO `suporte` (`id`, `data`, `nome_cliente`, `problema`, `categoria`, `status`, `Log`, `idcliente`, `Resposta`, `respostacliente`, `atendente`, `resolvidodata`, `tipoproblema`) VALUES
(18, '2020-08-12 08:53:09', 'Douglas Gomes', 'Sem conexÃ£o a internet', '1', '1', 'Usuario PPPOE Conectado<br>Sem instabilidade detectada<br>0 vezes conectado no mesmo dia <br>Motivo da desconexÃ£o: <br> Aparentemente nÃ£o hÃ¡ outros clientes desconectados<br>Usuario relatou vento<br>Usuario nÃ£o relatou falta de luz nas ultimas 12 horas<br>Usuario nÃ£o relatou raios', '1', '0', 'comeÃ§ou a acontecer depois da chuva', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `trocardeplanos`
--

CREATE TABLE `trocardeplanos` (
  `id` int(244) NOT NULL,
  `usuarioid` int(244) NOT NULL,
  `planoanterior` int(244) NOT NULL,
  `novoplano` int(244) NOT NULL,
  `data` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `trocardeplanos`
--

INSERT INTO `trocardeplanos` (`id`, `usuarioid`, `planoanterior`, `novoplano`, `data`) VALUES
(2, 1, 3, 3, '22/05/2020'),
(3, 1, 3, 1, '03/08/2020');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` bigint(255) NOT NULL,
  `email` varchar(244) NOT NULL,
  `nome` varchar(244) NOT NULL,
  `senha` varchar(244) NOT NULL,
  `whatsapp` varchar(244) NOT NULL,
  `cep` varchar(244) NOT NULL,
  `numero` varchar(244) NOT NULL,
  `plano` int(11) NOT NULL,
  `cpf` int(11) NOT NULL,
  `cnpj` int(11) NOT NULL,
  `ativo` int(11) NOT NULL,
  `vencimento` varchar(244) NOT NULL,
  `observacoes` varchar(244) NOT NULL,
  `caixa` int(244) NOT NULL,
  `genero` varchar(244) NOT NULL,
  `idoso` int(244) NOT NULL,
  `cidade` varchar(244) NOT NULL,
  `antisocial` int(244) NOT NULL,
  `carismatico` int(244) NOT NULL,
  `coordenadas` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `email`, `nome`, `senha`, `whatsapp`, `cep`, `numero`, `plano`, `cpf`, `cnpj`, `ativo`, `vencimento`, `observacoes`, `caixa`, `genero`, `idoso`, `cidade`, `antisocial`, `carismatico`, `coordenadas`) VALUES
(1, 'douglasgomestosta@gmail.com', 'Douglas Gomes', 'd7c617850d8aaef3fe0f599e7752270d', '21966589046', '23894-786', '23', 1, 123456, 0, 1, '15', 'seila', 1, 'm', 0, 'seropedica', 1, 0, '-22.739817, -43.705874'),
(2, 'suportdsworld@gmail.com', 'Josivaldo pinto', 'd7c617850d8aaef3fe0f599e7752270d', '26823352', '23894-786', '23', 1, 6493972, 0, 1, '22', 'seila', 1, 'm', 0, 'seropedica', 1, 0, '-22.736693, -43.702647'),
(7, 'gabriel@gmail.com', 'Gabriel Peixoto Chileli', 'e10adc3949ba59abbe56e057f20f883e', '0', '23894-786', '23', 2, 0, 0, 1, '7', '0', 0, 'm', 0, 'seropedica', 0, 0, '-22.736525, -43.702873');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `adesao`
--
ALTER TABLE `adesao`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `agendas`
--
ALTER TABLE `agendas`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `Artérias`
--
ALTER TABLE `Artérias`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `autenticacoes`
--
ALTER TABLE `autenticacoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `caixas`
--
ALTER TABLE `caixas`
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices de tabela `cancelamentos`
--
ALTER TABLE `cancelamentos`
  ADD PRIMARY KEY (`idcliente`);

--
-- Índices de tabela `configs`
--
ALTER TABLE `configs`
  ADD UNIQUE KEY `novasadesao` (`novasadesao`);

--
-- Índices de tabela `descontos`
--
ALTER TABLE `descontos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `emails`
--
ALTER TABLE `emails`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `mudancas`
--
ALTER TABLE `mudancas`
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices de tabela `notas_fiscais`
--
ALTER TABLE `notas_fiscais`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `notificacaorua`
--
ALTER TABLE `notificacaorua`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `notificacoes`
--
ALTER TABLE `notificacoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `planos`
--
ALTER TABLE `planos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices de tabela `pppoe`
--
ALTER TABLE `pppoe`
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices de tabela `problemas`
--
ALTER TABLE `problemas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices de tabela `ruas`
--
ALTER TABLE `ruas`
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices de tabela `servidores`
--
ALTER TABLE `servidores`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `suporte`
--
ALTER TABLE `suporte`
  ADD UNIQUE KEY `id` (`id`);

--
-- Índices de tabela `trocardeplanos`
--
ALTER TABLE `trocardeplanos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `adesao`
--
ALTER TABLE `adesao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `agendas`
--
ALTER TABLE `agendas`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `autenticacoes`
--
ALTER TABLE `autenticacoes`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT de tabela `caixas`
--
ALTER TABLE `caixas`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `descontos`
--
ALTER TABLE `descontos`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `features`
--
ALTER TABLE `features`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `mudancas`
--
ALTER TABLE `mudancas`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `notas_fiscais`
--
ALTER TABLE `notas_fiscais`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `notificacaorua`
--
ALTER TABLE `notificacaorua`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `notificacoes`
--
ALTER TABLE `notificacoes`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `planos`
--
ALTER TABLE `planos`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `pppoe`
--
ALTER TABLE `pppoe`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `problemas`
--
ALTER TABLE `problemas`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `servidores`
--
ALTER TABLE `servidores`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `suporte`
--
ALTER TABLE `suporte`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `trocardeplanos`
--
ALTER TABLE `trocardeplanos`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
