﻿<?php
$url = "http://192.168.0.1/login.asp?0";
$cookie = "/var/www/html/painel/cookie.txt";
$fields = array('Username' => 'YWRtaW4=', 'Password' => 'YWRtaW4=', 'checkEn' => '0');
$ch = curl_init();

curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt ($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);

$result = curl_exec($ch);

curl_close($ch);
print_r($result);