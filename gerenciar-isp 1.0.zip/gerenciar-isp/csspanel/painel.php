<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `admins` WHERE `id` LIKE '" . $id . "'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
        }
    }
}
else
{
    header('Location: login.php');
}
?>
<html lang="en"><head>
<title>Painel de administração | Data Web</title>




<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<link rel="icon" href="../files/assets/images/favicon.ico" type="image/x-icon">

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="csspanel/bootstrap.min.css">

<link rel="stylesheet" href="csspanel/waves.min.css" type="text/css" media="all">

<link rel="stylesheet" type="text/css" href="csspanel/feather.css">

<link rel="stylesheet" type="text/css" href="csspanel/font-awesome-n.min.css">

<link rel="stylesheet" href="csspanel/chartist.css" type="text/css" media="all">

<link rel="stylesheet" type="text/css" href="csspanel/style.css">
<link rel="stylesheet" type="text/css" href="csspanel/widget.css">
</head>
<body themebg-pattern="theme1">

<div class="loader-bg" style="display: none;">
<div class="loader-bar"></div>
</div>

<div id="pcoded" class="pcoded iscollapsed" nav-type="st2" theme-layout="vertical" vertical-placement="left" vertical-layout="wide" pcoded-device-type="desktop" vertical-nav-type="expanded" vertical-effect="shrink" vnavigation-view="view1" fream-type="theme1" layout-type="light">
<div class="pcoded-overlay-box"></div>
<div class="pcoded-container navbar-wrapper">



<div>

<div class="page-header card">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">

<div class="d-inline">
</div>
</div>
</div>
<div class="col-lg-4">
<div class="page-header-breadcrumb">

</div>
</div>
</div>
</div>

<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-body">

<div class="row">

<div class="col-md-12 col-xl-8">
<div class="card sale-card">
<div class="card-header">
<h5>Estatisticas</h5>
</div>
<div class="card-block">
<h3> PPPoe Ativos: 0/0 </h3>
<?php
$sql = "SELECT * FROM `adesao`";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>

<h3> Instalações pendentes: <?php echo $cont; ?>  <a href="adesao.php">Ver Todos</a>  <a href="addadesao.php">Criar novo</a> </h3>

<?php
$sql = "SELECT * FROM `caixas`";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>
<h3> Caixas instaladas: <?php echo $cont; ?>   <a href="caixa.php">Ver Todos</a> <a href="addcaixa.php">Adicionar novo</a></h3>
<?php
$sql = "SELECT * FROM `ruas`";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>
<h3> Ruas atendidas: <?php echo $cont; ?>   <a href="ruas.php">Ver Todas</a> <a href="addruas.php">Adicionar nova</a></h3>
</div>
</div>
</div>
<div class="col-md-12 col-xl-4">
<div class="card comp-card">
<div class="card-body">
<div class="row align-items-center">
<div class="col">
<h6 class="m-b-25">Clientes totais</h6>
<?php
$sql = "SELECT * FROM usuarios";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>
<h3 class="f-w-700 text-c-blue"><?php echo $cont; ?></h3>
<a href="adduser.php">Adicionar novo</a> <br>
<a href="usuarios.php">Ver Todos</a>
</div>

 </div>
</div>
</div>
<div class="card comp-card">
<div class="card-body">
<div class="row align-items-center">
<div class="col">
<h6 class="m-b-25">Clientes ativos</h6>
<?php
$sql = "SELECT * FROM `usuarios` WHERE `ativo` = 1";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);
?>
<h3 class="f-w-700 text-c-green"><?php echo $cont; ?></h3>
<p class="m-b-0">////</p>
</div>

</div>
</div>
</div>
<div class="card comp-card">
<div class="card-body">
<div class="row align-items-center">
<div class="col">
<h6 class="m-b-25">Clientes inativos</h6>
<?php
$sql = "SELECT * FROM `usuarios` WHERE `ativo` = 0";
$result = $conn->query($sql);
$cont = mysqli_num_rows($result);

?>
<h3 class="f-w-700 text-c-yellow"><?php echo $cont; ?></h3>
<p class="m-b-0">/////</p>
</div>

</div>
</div>
</div>
</div>


<div class="col-xl-12">
<div class="card proj-progress-card">
<div class="card-block">
<div class="row">
<div class="col-xl-3 col-md-6">
<h6>Published Project</h6>
<h5 class="m-b-30 f-w-700">532<span class="text-c-green m-l-10">+1.69%</span></h5>
<div class="progress">
<div class="progress-bar bg-c-red" style="width:25%"></div>
</div>
</div>
<div class="col-xl-3 col-md-6">
<h6>Completed Task</h6>
<h5 class="m-b-30 f-w-700">4,569<span class="text-c-red m-l-10">-0.5%</span></h5>
<div class="progress">
 <div class="progress-bar bg-c-blue" style="width:100%"></div>
</div>
</div>
<div class="col-xl-3 col-md-6">
<h6>Successfull Task</h6>
<h5 class="m-b-30 f-w-700">89%<span class="text-c-green m-l-10">+0.99%</span></h5>
<div class="progress">
<div class="progress-bar bg-c-green" style="width:85%"></div>
</div>
</div>
<div class="col-xl-3 col-md-6">
<h6>Ongoing Project</h6>
<h5 class="m-b-30 f-w-700">365<span class="text-c-green m-l-10">+0.35%</span></h5>
<div class="progress">
<div class="progress-bar bg-c-yellow" style="width:45%"></div>
</div>
</div>
</div>
</div>
</div>
</div>


<div class="col-md-12 col-xl-4">
<div class="card card-blue text-white">
<div class="card-block p-b-0">
<div class="row m-b-50">
<div class="col">
<h6 class="m-b-5">Sales In July</h6>
<h5 class="m-b-0 f-w-700">$2665.00</h5>
</div>
<div class="col-auto text-center">
<p class="m-b-5">Direct Sale</p>
<h6 class="m-b-0">$1768</h6>
</div>
<div class="col-auto text-center">
<p class="m-b-5">Referal</p>
<h6 class="m-b-0">$897</h6>
</div>
</div>
<div id="sec-ecommerce-chart-line" class="" style="height: 60px; padding: 0px; position: relative;"><canvas class="flot-base" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 270.656px; height: 60px;" width="270" height="60"></canvas><div class="flot-text" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; font-size: smaller; color: rgb(84, 84, 84);"><div class="flot-x-axis flot-x1-axis xAxis x1Axis" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px;"><div style="position: absolute; max-width: 38px; top: 60px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 8px; text-align: center;">0.0</div><div style="position: absolute; max-width: 38px; top: 60px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 53px; text-align: center;">2.5</div><div style="position: absolute; max-width: 38px; top: 60px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 99px; text-align: center;">5.0</div><div style="position: absolute; max-width: 38px; top: 60px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 144px; text-align: center;">7.5</div><div style="position: absolute; max-width: 38px; top: 60px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 190px; text-align: center;">10.0</div><div style="position: absolute; max-width: 38px; top: 60px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 235px; text-align: center;">12.5</div></div><div class="flot-y-axis flot-y1-axis yAxis y1Axis" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px;"><div style="position: absolute; top: 52px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 0px; text-align: right;">0</div><div style="position: absolute; top: 37px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 0px; text-align: right;">10</div><div style="position: absolute; top: 23px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 0px; text-align: right;">20</div><div style="position: absolute; top: 8px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 0px; text-align: right;">30</div></div></div><canvas class="flot-overlay" width="270" height="60" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 270.656px; height: 60px;"></canvas></div>
<div id="sec-ecommerce-chart-bar" style="height: 195px; padding: 0px; position: relative;"><canvas class="flot-base" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 270.656px; height: 195px;" width="270" height="195"></canvas><div class="flot-text" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; font-size: smaller; color: rgb(84, 84, 84);"><div class="flot-x-axis flot-x1-axis xAxis x1Axis" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px;"><div style="position: absolute; max-width: 33px; top: 195px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 6px; text-align: center;">0.0</div><div style="position: absolute; max-width: 33px; top: 195px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 52px; text-align: center;">2.5</div><div style="position: absolute; max-width: 33px; top: 195px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 98px; text-align: center;">5.0</div><div style="position: absolute; max-width: 33px; top: 195px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 145px; text-align: center;">7.5</div><div style="position: absolute; max-width: 33px; top: 195px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 191px; text-align: center;">10.0</div><div style="position: absolute; max-width: 33px; top: 195px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 237px; text-align: center;">12.5</div></div><div class="flot-y-axis flot-y1-axis yAxis y1Axis" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px;"><div style="position: absolute; top: 195px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 0px; text-align: right;">0</div><div style="position: absolute; top: 163px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 0px; text-align: right;">5</div><div style="position: absolute; top: 130px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 0px; text-align: right;">10</div><div style="position: absolute; top: 98px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 0px; text-align: right;">15</div><div style="position: absolute; top: 65px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 0px; text-align: right;">20</div><div style="position: absolute; top: 33px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 0px; text-align: right;">25</div><div style="position: absolute; top: 0px; font: 400 0px/0px &quot;open sans&quot;, sans-serif; color: transparent; left: 0px; text-align: right;">30</div></div></div><canvas class="flot-overlay" width="270" height="195" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 270.656px; height: 195px;"></canvas></div>
</div>
</div>
</div>
<div class="col-xl-4 col-md-12">
<div class="card latest-update-card">
<div class="card-header">
<h5>What’s New</h5>
<div class="card-header-right">
<ul class="list-unstyled card-option">
<li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
<li><i class="feather icon-maximize full-card"></i></li>
<li><i class="feather icon-minus minimize-card"></i></li>
<li><i class="feather icon-refresh-cw reload-card"></i></li>
<li><i class="feather icon-trash close-card"></i></li>
<li><i class="feather icon-chevron-left open-card-option"></i></li>
</ul>
</div>
</div>
<div class="card-block">
<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 290px;"><div class="scroll-widget" style="overflow: hidden; width: auto; height: 290px;">
<div class="latest-update-box">
<div class="row p-t-20 p-b-30">
<div class="col-auto text-right update-meta p-r-0">
<img src="../files/assets/images/avatar-4.jpg" alt="user image" class="img-radius img-40 align-top m-r-15 update-icon">
</div>
<div class="col p-l-5">
<a href="#!"><h6>Your Manager Posted.</h6></a>
<p class="text-muted m-b-0">Jonny michel</p>
</div>
</div>
<div class="row p-b-30">
<div class="col-auto text-right update-meta p-r-0">
<i class="feather icon-briefcase bg-c-red update-icon"></i>
</div>
<div class="col p-l-5">
<a href="#!"><h6>You have 3 pending Task.</h6></a>
<p class="text-muted m-b-0">Hemilton</p>
</div>
</div>
<div class="row p-b-30">
<div class="col-auto text-right update-meta p-r-0">
<i class="feather icon-check f-w-600 bg-c-green update-icon"></i>
</div>
<div class="col p-l-5">
<a href="#!"><h6>New Order Received.</h6></a>
<p class="text-muted m-b-0">Hemilton</p>
</div>
</div>
<div class="row p-b-30">
<div class="col-auto text-right update-meta p-r-0">
<img src="../files/assets/images/avatar-4.jpg" alt="user image" class="img-radius img-40 align-top m-r-15 update-icon">
</div>
<div class="col p-l-5">
<a href="#!"><h6>Your Manager Posted.</h6></a>
<p class="text-muted m-b-0">Jonny michel</p>
</div>
</div>
<div class="row p-b-30">
<div class="col-auto text-right update-meta p-r-0">
<i class="feather icon-briefcase bg-c-red update-icon"></i>
</div>
<div class="col p-l-5">
<a href="#!"><h6>You have 3 pending Task.</h6></a>
<p class="text-muted m-b-0">Hemilton</p>
</div>
</div>
<div class="row">
<div class="col-auto text-right update-meta p-r-0">
<i class="feather icon-check f-w-600 bg-c-green update-icon"></i>
</div>
<div class="col p-l-5">
<a href="#!"><h6>New Order Received.</h6></a>
<p class="text-muted m-b-0">Hemilton</p>
</div>
</div>
</div>
</div><div class="slimScrollBar" style="background: rgb(0, 0, 0); width: 5px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 188.565px;"></div><div class="slimScrollRail" style="width: 5px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
</div>
</div>
</div>
<div class="col-xl-4 col-md-6">
<div class="card latest-update-card">
<div class="card-header">
<h5>Latest Activity</h5>
<div class="card-header-right">
<ul class="list-unstyled card-option">
<li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
<li><i class="feather icon-maximize full-card"></i></li>
<li><i class="feather icon-minus minimize-card"></i></li>
<li><i class="feather icon-refresh-cw reload-card"></i></li>
<li><i class="feather icon-trash close-card"></i></li>
<li><i class="feather icon-chevron-left open-card-option"></i></li>
</ul>
</div>
</div>
<div class="card-block">
<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 290px;"><div class="scroll-widget" style="overflow: hidden; width: auto; height: 290px;">
<div class="latest-update-box">
<div class="row p-t-20 p-b-30">
<div class="col-auto text-right update-meta p-r-0">
<i class="b-primary update-icon ring"></i>
</div>
<div class="col p-l-5">
<a href="#!"><h6>Devlopment &amp; Update</h6></a>
<p class="text-muted m-b-0">Lorem ipsum dolor sit amet, <a href="#!" class="text-c-blue"> More</a></p>
</div>
</div>
<div class="row p-b-30">
<div class="col-auto text-right update-meta p-r-0">
<i class="b-primary update-icon ring"></i>
</div>
<div class="col p-l-5">
<a href="#!"><h6>Showcases</h6></a>
<p class="text-muted m-b-0">Lorem dolor sit amet, <a href="#!" class="text-c-blue"> More</a></p>
</div>
</div>
<div class="row p-b-30">
<div class="col-auto text-right update-meta p-r-0">
<i class="b-success update-icon ring"></i>
</div>
<div class="col p-l-5">
<a href="#!"><h6>Miscellaneous</h6></a>
<p class="text-muted m-b-0">Lorem ipsum dolor sit ipsum amet, <a href="#!" class="text-c-green"> More</a></p>
</div>
</div>
<div class="row p-b-30">
<div class="col-auto text-right update-meta p-r-0">
<i class="b-danger update-icon ring"></i>
</div>
 <div class="col p-l-5">
<a href="#!"><h6>Your Manager Posted.</h6></a>
<p class="text-muted m-b-0">Lorem ipsum dolor sit amet, <a href="#!" class="text-c-red"> More</a></p>
</div>
</div>
<div class="row p-b-30">
<div class="col-auto text-right update-meta p-r-0">
<i class="b-primary update-icon ring"></i>
</div>
<div class="col p-l-5">
<a href="#!"><h6>Showcases</h6></a>
<p class="text-muted m-b-0">Lorem dolor sit amet, <a href="#!" class="text-c-blue"> More</a></p>
</div>
</div>
<div class="row">
<div class="col-auto text-right update-meta p-r-0">
<i class="b-success update-icon ring"></i>
</div>
<div class="col p-l-5">
<a href="#!"><h6>Miscellaneous</h6></a>
<p class="text-muted m-b-0">Lorem ipsum dolor sit ipsum amet, <a href="#!" class="text-c-green"> More</a></p>
</div>
</div>
</div>
</div><div class="slimScrollBar" style="background: rgb(0, 0, 0); width: 5px; position: absolute; top: 0px; opacity: 0.4; display: block; border-radius: 7px; z-index: 99; right: 1px; height: 161.111px;"></div><div class="slimScrollRail" style="width: 5px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
</div>
</div>
</div>


<div class="col-md-12">
<div class="card table-card">
<div class="card-header">
<h5>Pedidos de suporte</h5>
<div class="card-header-right">

<a href="addsuporte.php">Adicionar novo</a>

</div>
</div>
<div class="card-block p-b-0">
<div class="table-responsive">
<table class="table table-hover m-b-0">
<thead>
<tr>
<th>Cliente</th>
<th>Tipo de Problema</th>
<th>Rua</th>
<th>Status</th>
<th>Nivel</th>
</tr>
</thead>
<tbody>




<?php
$sql = "SELECT * FROM `suporte` ORDER BY `data` DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $nome = $row["nome_cliente"];
        $problema = $row["problema"];
        $rua = $row["Rua"];
        $status = $row["status"];
        $idsuporte = $row["id"];
        ?>
<tr>

<td> <a href="suporte.php?id=<?php echo $idsuporte; ?>"><?php echo $nome; ?></a></td> 
<td><?php echo $problema; ?></td>
<td><?php echo $rua; ?></td>
<?php
if($status == 0){?>
<td><label class="label label-danger">Aguardando...</label></td>
<?php }
if($status == 1){?>
<td><label class="label label-danger">Em andamento</label></td>
<?php }
if($status == 2){?>
<td><label class="label label-success">Encerrado</label></td>
<?php }?>
<td>
Medio
</td>
</tr>

        <?php
    }
}
mysqli_close($conn);
?>














</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>



</div>

</div>
</div>
</div>
</div>
</div>

<div id="styleSelector">
</div>

</div>
</div>
</div>
</div>




<script type="text/javascript" src="jspanel/jquery-ui.min.js"></script>
<script type="text/javascript" src="jspanel/popper.min.js"></script>
<script type="text/javascript" src="jspanel/bootstrap.min.js"></script>

<script src="jspanel/waves.min.js" type="text/javascript"></script>

<script type="text/javascript" src="jspanel/jquery.slimscroll.js"></script>

<script src="jspanel/jquery.flot.js" type="text/javascript"></script>
<script src="jspanel/jquery.flot.categories.js" type="text/javascript"></script>
<script src="jspanel/curvedLines.js" type="text/javascript"></script>
<script src="jspanel/jquery.flot.tooltip.min.js" type="text/javascript"></script>

<script src="jspanel/chartist.js" type="text/javascript"></script>

<script src="jspanel/amcharts.js" type="text/javascript"></script>
<script src="jspanel/serial.js" type="text/javascript"></script>
<script src="jspanel/light.js" type="text/javascript"></script>

<script src="jspanel/pcoded.min.js" type="text/javascript"></script>
<script src="jspanel/vertical-layout.min.js" type="text/javascript"></script>
<script type="text/javascript" src="jspanel/custom-dashboard.min.js"></script>
<script type="text/javascript" src="jspanel/script.min.js"></script>




<div class="flotTip" style="display: none; position: absolute; background: rgb(255, 255, 255); z-index: 1040; padding: 0.4em 0.6em; border-radius: 0.5em; font-size: 0.8em; border: 1px solid rgb(17, 17, 17); white-space: nowrap;"></div></body></html>