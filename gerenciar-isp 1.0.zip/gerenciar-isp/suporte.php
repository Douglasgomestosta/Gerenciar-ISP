﻿<?php
session_start();
//error_reporting(E_ALL ^ E_NOTICE);
require 'sistema/db.php'; 
require 'sistema/FUNCTIONS.php'; 
if($_SESSION['login'] == 1)
{
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $senha = $_SESSION['senha'];
    $sql = "SELECT * FROM `usuarios` WHERE `id` = " . $id;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $nome = $row["nome"];
            $vencimento = $row["vencimento"];
            $plano = $row["plano"];
            $cep = $row["cep"];
            $ativo = $row["ativo"];
        }
    }



    $sql = "SELECT * FROM `planos` WHERE `id` LIKE '" . $plano . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $preco = $row["preco"];
            $velocidade = $row["velocidade"];
            $velocidademinima = $row["velocidademinima"];
        }
    }
    $sql = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $id;
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $usuariopppoe = $row["usuario"];
            $ssidwifi = $row["ssidwifi"];
           
        }
    }





}
else
{
    header('Location: login.php?redirect=suporte.php');
}

if(empty($_POST['parte']))
{
    $_POST['parte'] = "0";
}
//continuar teste mesmo sem estar conectado no mesmo wifi
if($_GET['continuarteste'] == "1")
{
    $_POST['parte'] = "1";
    $_POST['tipo'] = "2";
    $_SESSION['continuarwifinome'] = "1";
}
//trocar GET para POST
if($_GET['tipo'] > 0){
    $_POST['tipo'] = $_GET['tipo'];
    $_POST['parte'] = "1";
}
//fim
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Data Web</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <!--- >
Botão azul do submit
<--->
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>

<script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Data Web</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Ultimo acesso: *** &nbsp; <a href="exit.php" class="btn btn-danger square-btn-adjust">Sair</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <!--- <img src="assets/img/find_user.png" class="user-image img-responsive"/> --->
					</li>
				
					
                   <?php
                   require 'sistema/menu.php'; 
                   ?>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
                    <?php
if($_GET['criado'] == 1)
{
    ?><center>
    <img src="imagens/ok.webp" width="100">
<h1 style="font-size: 25px; color: black;">Pronto! </h1>
<h3>Seu pedido de suporte já foi registrado no sistema e em breve será respondido </h3>
<a href="suportestatus.php">Saiba Mais</a>
    <?php
    exit();
}
if($_POST['parte'] == 0)
{
    ?>

<h2>Em que podemos ajudar você, <?php echo $nome; ?>?</h2>


<!--- Inicio --->
                                <div class="col-md-7">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

                    <a href="?tipo=1">


<h4> <img src="imagens/semconexao.png" width="52px"> Estou sem conexão a internet</h4>
    
</a>
                   
                </div>
            </div>
                          </div>
                          <!--- fim --->


<!--- Inicio --->
<div class="col-md-5">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

                    <a href="?tipo=2">


<h4> <img src="imagens/internetlenta.png" width="52px">Minha conexão a internet está lenta</h4>
    
</a>
                   
                </div>
            </div>
                          </div>
                          <!--- fim --->



                          
<!--- Inicio --->
<div class="col-md-7">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

                    <a href="?tipo=3">


<h4> <img src="imagens/latencia.png" width="52px">Estou com perda de pacotes ou alta latencia</h4>
    
</a>
                   
                </div>
            </div>
                          </div>
                          <!--- fim --->


                          <!--- Inicio --->
<div class="col-md-5">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

                    <a href="?tipo=4">


<h4> <img src="imagens/money.png" width="52px">Tenho problemas com o pagamento</h4>
    
</a>
                   
                </div>
            </div>
                          </div>
                          <!--- fim --->



<!--- Inicio --->
<div class="col-md-7">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

                    <a href="?tipo=5">


<h4> <img src="imagens/duvida.png" width="52px"> Estou com dúvidas</h4>
    
</a>
                   
                </div>
            </div>
                          </div>
                          <!--- fim --->


                          <!--- Inicio --->
<div class="col-md-5">
                    <div class="panel panel-default">
                                
                                      
                                    <div class="panel-body"> 

                    <a href="?tipo=6">


<h4> <img src="imagens/outros.png" width="52px"> Outros assuntos</h4>
    
</a>
                   
                </div>
            </div>
                          </div>
                          <!--- fim --->


<br>
                                <h4>Outros meios de atendimento </h4>
                                <h6>Estes meios de atendimento não são automatizados e por isso seu atendimento pode levar um tempo extra </h6>
                                <a href="https://www.messenger.com/t/datawebbrasil" style="font-size: 30px;"> <img src="imagens/messenger.png" width="52px">  Facebook Messenger</a><br>
    <?php
}
//parte 1 das categorias
if($_POST['parte'] == 1)
{
    //categoria sem internet
    if($_POST['tipo'] == 1)
    {

        if($ativo == 0)
{
    ?>
    <h2>Ops... parece que seu serviço esta inativo</h2>
    <h4>O seu serviço de internet pode ter sido desativado por falta de pagamento, descumprimento de contrato ou a pedido do cliente </h4>
    <h5>Vocẽ pode entrar em contrato conosco pedindo a reativação de seu serviço </h5>
    <br><br>
<a href="../index.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar a pagina inicial</a><br><br>
    <?php
    exit();
}
        //Ver se usuario está conectado
        require 'sistema/logadopppoe.php'; 
        if($desconectado == 1){
     $conectado = "0";
     if($motivodesconect == "User-Request") {
        if($_GET['conectado'] == "1")
        {} else{
        ?>
        <h2>Que estranho... parece que você foi desconectado por requisição do seu roteador </h2>
        <h4>é possivel que um usuario de sua rede tenha acessado o painel de administração de seu roteador e requisitado que ele se desconecte de nosso sistema, com isso, causando indisponibilidade em seu serviço </h4>
        <h3>Não sabe o que pode ter sido? você ainda pode abrir um pedido de suporte </h3>
        <form method="post" action="?conectado=1">
    <input type="hidden" name="parte" value="1">
    <input type="hidden" name="tipo" value="1">
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
        <?php
        exit();
        }
         $motivodesconect = "Desconectado pelo usuario";
        }
    
    } else
{
    $conectado = "1";
    if($_GET['conectado'] == "1")
    {} else{
    ?>
    <h2>Que estranho... nosso sistema diz que você está conectado a internet... </h2>
    <h5>Status: <a style="color:green;">CONECTADO</a> Conexão realizada as: <?php echo $starttime; ?> </h5>
<h4>Você tem certeza que está sem conexão a internet? é possivel que o problema seja perda de pacotes, ou até mesmo o seu telefone </h4>
    <h5>Vocẽ pode saber mais sobre o que pode está causando a o seu problema de conexão em nosso blog ;) </h5>
    <a href="http://datawebtelecom.site/ufaqs/minha-internet-esta-lenta-o-que-pode-esta-acontecendo/" style="font-size: 25px;">Saiba Mais</a>
    <h4>Se você acredita que isso é um erro, e que você realmente está sem conexão a internet, você pode ainda assim abrir um pedido de suporte </h4>
    <form method="post" action="?conectado=1">
    <input type="hidden" name="parte" value="1">
    <input type="hidden" name="tipo" value="1">
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
    <?php
exit();
    }
}
// fim ver se usuario está online
//Ver se usuario está sendo desconectado e conectado varias vezes
$instabilidade = "0";
$sql = "SELECT * FROM `radacct` WHERE `username` LIKE 'roteador' AND `acctstoptime` LIKE '%" . date('Y-m-d') . "%' ORDER BY `acctstarttime` DESC";
$result = $connradius->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $instabilidade = $instabilidade + 1;
        
    }
}
$vezesconectado = $instabilidade;
if($instabilidade > 5)
{
$instabilidade = "1";
}else { $instabilidade = "0";}
//fim se usuario está sendo desconectado e conectado varias vezes

//Ver se outros usuarios estão com problemas na rua
$cont = 0;
$desconectados = 0;
$sql = "SELECT * FROM `usuarios` WHERE `cep` LIKE '" . $cep . "' AND `ativo` = 1";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $idcliente = $row["id"];
            $cont = $cont + 1;

            $sqll = "SELECT * FROM `pppoe` WHERE `idcliente` = " . $idcliente;
            $resultl = $conn->query($sqll);
            
            if ($resultl->num_rows > 0) {
                // output data of each row
                while($rowl = $resultl->fetch_assoc()) {
                    $usuariopppoeoutro = $rowl["usuario"];
                    


                    
                    $sql = "SELECT * FROM `radacct` WHERE `username` LIKE '" . $usuariopppoeoutro . "' ORDER BY `acctstarttime` DESC LIMIT 1";
$resultt = $connradius->query($sql);
if ($resultt->num_rows > 0) {
    // output data of each row
    while($row = $resultt->fetch_assoc()) {
        $stoptimeoutro = $row["acctstoptime"];
        $motivodesconectoutro = $row["acctterminatecause"];
    }
}
if(isset($stoptimeoutro)){ if($usuariopppoeoutro == $usuariopppoe) {} else{
    if("Lost-Service" == $motivodesconectoutro)
    $desconectados = $desconectados + 1;
}}
if($desconectados >= 1)
{
    $externo = "1";
}


                }
            }




        }
    }
//
       ?>
       <h2>Sentimos muito por você estar com o seu serviço indisponivel :\ </h2>
       <h3>Diversos fatores podem fazer a sua internet ficar indisponivel, como rompimento de cabo em poste, manutenção, até mesmo problemas dentro da sua propria casa, você pode ver nosso post que explica sobre tudo o que pode fazer sua internet ficar lenta ou fora do ar ;) </h3>
       <a href="http://datawebtelecom.site/ufaqs/minha-internet-esta-lenta-o-que-pode-esta-acontecendo/" style="font-size: 25px;">Saiba Mais</a>
       <br><h4>Antes de abrir um pedido de suporte por indisponibilidade, por favor, experimente reinciar seu roteador</h4>
       <?php
       if($conectado == "0")
       {
           ?>
                   <h6>Atualmente, seu roteador está <a style="color:red;">DESCONECTADO</a> a internet, você foi desconectado as <?php echo $stoptime; ?> pelo motivo: <?php echo $motivodesconect; ?></h6>

           <?php
       }
       if($instabilidade == "1")
       {
           ?>
           <h6 style="color:red;">Detectamos que você está com problema de oscilação na conexão, você foi reconectado no servidor <?php echo $vezesconectado; ?> Vezes no mesmo dia </h6>
           <?php
       }else
       {
        ?>
        <h6 style="color:green;">Você não aparenta ter problemas de oscilações de internet.</h6>
        <?php
       }

       if($externo == "1")
       {
           ?>
           <h6 style="color:red;">Detectamos que outros clientes em sua rua também estão sofrendo problemas de falta de conexão.</h6>
           <?php
       }else{
        ?>
        <h6 style="color:green;">Não detectamos outros usuarios com problemas de conexão em sua rua</h6>
        <?php
       }
       ?>
       <h3>Você deseja abrir um pedido de suporte? </h3>
       <h4>Por favor preencha alguns dados para que possamos abrir um pedido de suporte </h4>
       
       <form method="post">
    <input type="hidden" name="parte" value="2">
    <input type="hidden" name="tipo" value="1">
    <input type="hidden" name="conectado" value="<?php echo $conectado; ?>">
    <input type="hidden" name="instabilidade" value="<?php echo $instabilidade; ?>">
    <input type="hidden" name="vezesconectado" value="<?php echo $vezesconectado; ?>">
    <input type="hidden" name="motivodesconect" value="<?php echo $motivodesconect; ?>">
    <input type="hidden" name="externo" value="<?php echo $externo; ?>">
    <input type="hidden" name="desconectados" value="<?php echo $desconectados; ?>">


                                    <table class="login-box">
                                        
                                    
<select id="ordenacao" name="vento">
                                    <option value="0">Não houve ventos fortes nas ultimas 12 horas</option>
                                    <option value="1">Houve vento forte nas ultimas 12 horas</option>
                                    </select>
<br><br>
<select id="ordenacao" name="luz">
                                    <option value="0">Não houve quedas de energia nas ultimas 12 horas</option>
                                    <option value="1">Houve quedas de energia nas ultimas 12 horas</option>
                                    </select>
<br><br>
<select id="ordenacao" name="raios">
                                    <option value="0">Não houve raios nas ultimas 12 horas</option>
                                    <option value="1">Houve raios nas ultimas 12 horas</option>
                                    </select>


                                    <tr>
                                            <td style="padding: 12px 0 0 2px;">
Deseja acrecentar algo?                                               
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            
                                                <input tabindex="2" type="text" size="50px"  style="width:240px;"  class="input is-large" name="texto"   maxlength="200"> 

                                            </td>
                                        </tr>
                                        <tr>
                                        </tr>
<br><br>

                                        <tr>

                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                                <h6>Coloque informações como se o problema é recorrente, se ele ocorre em um dia ou horario especifico(ex: todo sabado a noite) para que possamos resolver seu problema </h6>

       <?php
    }
    //Opção internet lenta
    if($_POST['tipo'] == 2)
    {
        if($ativo == 0)
        {
            ?>
            <h2>Ops... parece que seu serviço esta inativo</h2>
            <h4>O seu serviço de internet pode ter sido desativado por falta de pagamento, descumprimento de contrato ou a pedido do cliente </h4>
            <h5>Vocẽ pode entrar em contrato conosco pedindo a reativação de seu serviço </h5>
            <br><br>
        <a href="../index.php" style="width: 100%;
          background-color: #4CAF50;
          color: white;
          padding: 14px 20px;
          margin: 8px 0;
          border: none;
          border-radius: 4px;
          cursor: pointer;">Voltar a pagina inicial</a><br><br>
            <?php
            exit();
        }

        require 'sistema/logadopppoe.php';
        if($desconectado == 1)
        {
            ?>
            <H3>Você está desconectado a internet! </h3>
            <?php


if($desconectado == 1){
    ?>
    <h4>Atualmente, seu roteador está <a style="color:red;">DESCONECTADO</a> a internet, você foi desconectado as <?php echo $stoptime; ?> pelo motivo: <?php echo $motivodesconect; ?></h4>
<h4>Caso você esteja com problemas de conexão a internet, causada por uma total indisponibilidade do seu serviço, por favor abra um pedido de suporte como 'estou sem internet' </h4>


<form method="post">
    <input type="hidden" name="parte" value="1">
    <input type="hidden" name="tipo" value="1">
                                        <tbody><tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Abrir pedido de suporte como sem internet" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </form>





<br><br>
<a href="../index.php" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Voltar a pagina inicial</a><br><br>

<?php
exit();
}
else
{
    ?>
<h4>Atualmente, seu roteador está <a style="color:green;">CONECTADO</a> a internet, conexão realizada em <?php echo $starttime; ?></h4>
<?php
}

        }
        if($_SESSION['conectadowifi'] == "1")
        {
$ssidwifi = '"' . $ssidwifi . '"';
if($_SESSION['nomewifi'] == $ssidwifi){}else
{
    if($_SESSION['continuarwifinome'] == 0)
    {
    ?>
    <h2>Você está realmente conectado a sua rede wifi? </h2>
    <h3>Detectamos que você está conectado no wifi <?php echo $_SESSION['nomewifi']; ?> enquanto que, de acordo com nosso sistema, o seu wifi é <?php echo $ssidwifi; ?> </h3>
    <H3>Se de fato você não estiver conectado em sua rede wifi, por favor conecte-se para fazer o teste de velocidade, caso sua rede wifi está sem conexão a internet, selecione a categoria "estou sem conexão a internet" na hora de criar o seu pedido de suporte </h3>
    <h4>Caso você tenha trocado o nome do seu roteador wifi, por favor, envie-nos um pedido de suporte com o novo nome, para que possamos atualizar em nosso banco de dados </h4>
    <h3>Deseja continuar mesmo assim? </h3>

    <br><br>
<a href="?continuarteste=1" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Continuar o teste</a><br><br>
    <?php
    exit();
    }
}



if($_SESSION['velocidadewifi'] < "45")
{
    ?>
    <h2>Velocidade teorica abaixo da recomendada! </h2>
    <h3>Detectamos que a sua velocidade teorica de conexão ao wifi é menos de 45MBPS </h3>
    <h3>Isso significa que sua conexão ao roteador wifi é de no maximo 45 Megas, mesmo que devido a interferencias de outras redes wifi sua conexão nunca chegara  tal velocidade </h3>
    <h3>Os principais motivos que podem fazer com que sua velocidade teorica seja tão baixa são: <br> 1 - Seu telefone não suporta velocidades acima de 45 Megas, verifique a ficha tecnica para esclarecer essa duvida <br> 2 - Você está longe do seu roteador wifi o que causa uma perda da conectividade, para esclarecer essa dúvida, aproxime-se do roteador <br> 3 - Seu roteador é obsoleto, roteador de 1 antena e com "45MBPS" escrito são obsoletos para os dias atuais, por favor abra um pedido de suporte pedindo a substituição do mesmo</h3>
    <?php
}

        }
if($_POST['datadownload'] == 0)
{
        ?>
        <h3>Vamos verificar se você está recebendo ou não a sua velocidade de internet? </h3>
        <h4>Lembre-se que no horario de 10:00 a 22:00 você pode receber até no minimo 40% da velocidade contratada.</h4>
        <h4>Para que o teste seja efetivo, você precisa estar perto do seu roteador, quanto mais longe do roteador a intensidade do sinal é pior e pode reduzir a velocidade de acesso do seu dispositivo </h4>
        <h4>Caso você deseja aumentar o alcance do seu sinal de wifi, será necessario comprar um repetidor de sinal wifi,entre em contato para mais detalhes </h4>
        <h4>Deseja começar o teste de velocidade? </h4>
        <br><br>
<a href="../speedtest" style="width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;">Começar teste de velocidade</a><br><br>
        <?php
}else
{
?>
<h4>Estes são os resultados finais... </h4>
<?php 
if($_POST['dataping'] < 12)
{echo '<h5 <a style="color:green;">Você está com uma boa latência'; $errolatencia = "0";} else {echo '<h5 <a style="color:red;">Você está com problemas de alta latência'; $errolatencia = "1";}

if($_POST['datadownload'] > $velocidademinima){echo '<h5 <a style="color:green;">Você está recebendo uma velocidade de Download maior do que o seu minimo'; $errodownload = "0";} else { echo '<h5 <a style="color:red;">Você está recebendo menos do que a sua velocidade minima de Download de ' . $velocidademinima . ' Megas'; $errodownload = "1";}

if($_POST['dataupload'] > $velocidademinima){echo '<h5 <a style="color:green;">Você está recebendo uma velocidade de Upload maior do que o seu minimo'; $erroupload = "0";} else { echo '<h5 <a style="color:red;">Você está recebendo menos do que a sua velocidade minima de Upload de ' . $velocidademinima . ' Megas'; $erroupload = "1";}



if($errolatencia == "1" | $errodownload == "1" | $erroupload == "1")
{
    ?>
    <h2>Detectamos um problema na velocidade de sua conexão a internet! </h2>
    <h3>Você não está recebendo o minimo de sua velocidade contratada e isso pode ser resultado de diversos tipos de problemas, desde seu roteador, um cabo defeituoso, ou sobrecarga em nossos serviços </h3>
    <h3>Você deseja abrir um pedido de ajuda para solucionar seu problema? </h3>

    <form method="post">
    <input type="hidden" name="parte" value="2">
    <input type="hidden" name="tipo" value="2">
    <input type="hidden" name="ping" value="<?php echo $_POST['dataping']; ?>">
    <input type="hidden" name="download" value="<?php echo $_POST['datadownload']; ?>">
    <input type="hidden" name="upload" value="<?php echo $_POST['dataupload']; ?>">

                                        <tr>

                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="btn btn-primary btn-lg">
                                            </td>
                                        </tr>
                                    </table>
                                </form>



    <?php
}else{
    ?>
    <br>
    <h2>Tudo ok com o seu serviço de conexão a internet </h2>
    <h3>Você está com uma boa latencia e recebendo a sua velocidade de download e upload minimo. </h3>
    <h2>Você está com um prolema especifico de um site ou aplicativo? </h2>
    <h3>é possivel que seu problema seja causado por uma falha de um aplicativo ou site, como uma sobrecarga no site especifico, uma manutenção, diversos serviços sofrem com problemas de instabilidades incluindo os maiores como Google e Facebook </h3>
    <h3>Você pode ver se o serviço está com problemas utilizando o site Downdetector </h3>
    <a href="https://downdetector.com.br" class="btn btn-primary btn-lg">Acessar Downdetector</a><br><br>
    <a href="painel.php" class="btn btn-success btn-lg">Voltar a página inicial</a>
    <?php
}



?>

<?php

}

    }
    if($_POST['tipo'] == 3)
    {echo "Opção temporariamente indisponivel, por favor utilize a opção outros assuntos";}
    if($_POST['tipo'] == 4)
    {echo "Opção temporariamente indisponivel, por favor utilize a opção outros assuntos";}
    if($_POST['tipo'] == 5)
    {
        ?>
        <H3>Talvez a gente já tenha a sua pergunta respondida em nossa página de perguntas frequentes, dê uma olhada lá ;) </h3> <a href="http://datawebtelecom.site/ufaqs/" style="font-size: 25px;">Ver perguntas frequentes</a>
        <h4>Não achou a sua dúvida por lá? não tem problema! preencha os campos abaixo para que a gente responda você </h4>
        <form method="post">
<input type="hidden" name="parte" value="2">
<input type="hidden" name="tipo" value="5">
                                    <table class="login-box">
                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                               Escreva sua dúvida abaixo
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="1" type="text" size="20px" style="width:240px;" name="duvida" class="input is-large" required="" minlength="6" maxlength="80">
                                            </td>
                                        </tr>
                                        
                                        
                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
        <?php
    }
    if($_POST['tipo'] == 6)
    {
    ?>
    <form method="post" id="form">
<input type="hidden" name="parte" value="2">
<input type="hidden" name="tipo" value="6">
                                    <table class="login-box">
                                        <tr>
                                            <td syle="padding: 12px 0 0 2px;">
                                                O que você deseja conversar conosco?
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input tabindex="1" type="text" size="20px" style="width:240px;" name="sobre" class="input is-large" required=""  minlength="10" maxlength="40">
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                            <td style="padding: 12px 0 0 2px;">
                                                Escreva um texto bastante explicativo <br>para que possamos saber o que você deseja
                                               
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            
                                                <input tabindex="2" type="text" size="50px"  style="width:240px;"  class="input is-large" name="texto" required=""  minlength="30" maxlength="200"> 
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="28px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0 0 12px 0;">
                                                <input tabindex="3" type="submit" value="Continuar" class="button is-block is-link is-large is-fullwidth">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
    <?PHP
    }
}
//parte 2 das etapas
if($_POST['parte'] == 2)
{
    //categoria sem internet
    if($_POST['tipo'] == 1)
    {
        if($_POST['conectado'] == "1"){$conectado = "Usuario PPPOE Conectado";} else {$conectado = "Usuario PPPOE Desconectado";}
        if($_POST['instabilidade'] == "1"){$instabilidade = "Usuario com instabilidade";} else {$instabilidade = "Sem instabilidade detectada";}
        if($_POST['externo'] == "1"){$externo = "Problema possivelmente extero, Outros " . $desconectados . " Clientes desconectados";} else {$externo = "Aparentemente não há outros clientes desconectados";}

        if (is_numeric($_POST['vezesconectado'])) {$vezesconectado = $_POST['vezesconectado'];} else {$vezesconectado = "0";}
        if (is_numeric($_POST['desconectados'])) {$desconectados = $_POST['desconectados'];} else {$desconectados = "0";}


        if (strpos($_POST['motivodesconect'], '"') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], "'") !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], ';') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], '*') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], '`') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['motivodesconect'], '=') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if(strlen($_POST['motivodesconect']) > 50) {echo "Houve um erro! tente novamente"; exit();}
$motivodesconect = $_POST['motivodesconect'];

if($_POST['vento'] == "1"){$vento = "Usuario relatou vento";} else {$vento = "Usuario não relatou vento";}
if($_POST['luz'] == "1"){$luz = "Usuario relatou Falta de luz nas ultimas 12 horas";} else {$luz = "Usuario não relatou falta de luz nas ultimas 12 horas";}
if($_POST['raios'] == "1"){$raios = "Usuario relatou raios";} else {$raios = "Usuario não relatou raios";}


$log = $conectado . "<br>" . $instabilidade . "<br>" . $vezesconectado . " vezes conectado no mesmo dia <br>Motivo da desconexão: " . $motivodesconect . "<br> " . $externo . "<br>" . $vento . "<br>" . $luz . "<br>" . $raios;


        $texto = $_POST['texto'];
        if (strpos($_POST['texto'], '"') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], "'") !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], ';') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '*') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '`') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '=') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if(strlen($_POST['texto']) > 100) {echo "O seu texto pode ter no maximo 100 caracteres"; exit();}

//nome, titulo do problema, categoria do suporte, log, id do cliente, texto do cliente
criarsuporte($nome, 'Sem conexão a internet', '1', $log, $id, $texto);
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
echo "Redirecionando...";

    }
//usuario com internet baixa
    if($_POST['tipo'] == 2)
    {
        if (!is_numeric($_POST['ping']) || !is_numeric($_POST['download']) || !is_numeric($_POST['upload'])) {
            exit();
        }


        $idsuporte = rand(1,999999999);
        $data = "CURRENT_TIMESTAMP";
        $log = "Ping: " . $_POST['ping'] . "ms<br>" . "Download: " . $_POST['download'] . "MB<br>" . "Upload: " . $_POST['upload'] . "MB<br>";
        $sql = "INSERT INTO `suporte` (`id`, `data`, `nome_cliente`, `problema`, `categoria`, `Rua`, `status`, `Log`, `idcliente`, `Resposta`, `respostacliente`, `atendente`) VALUES (NULL, CURRENT_TIMESTAMP, '" . $nome . "', 'Conexão a internet lenta', '2', '0', '0', '" . $log . "', '" . $id . "', '0', '" . $texto . "', '0');";
$result = $conn->query($sql);
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
echo "Redirecionando...";

    }


    if($_POST['tipo'] == 5)
    {
        $duvida = $_POST['duvida'];
        $data = "CURRENT_TIMESTAMP";
$idsuporte = rand(1,999999999);
        if (strpos($_POST['duvida'], '"') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['duvida'], "'") !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['duvida'], ';') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['duvida'], '*') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['duvida'], '`') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['duvida'], '=') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if(strlen($_POST['duvida']) < 6) {echo "A sua duvida precisa ter pelo menos 6 caracteres"; exit();}
if(strlen($_POST['duvida']) > 80) {echo "A sua duvida pode ter no maximo 80 caracteres"; exit();}
$sql = "INSERT INTO `suporte` (`id`, `data`, `nome_cliente`, `problema`, `categoria`, `Rua`, `status`, `Log`, `idcliente`, `Resposta`, `respostacliente`, `atendente`) VALUES (NULL, CURRENT_TIMESTAMP, '" . $nome . "', '" . $duvida . "', '5', '0', '0', '0', '" . $id . "', '0', '" . $duvida . "', '0');";
$result = $conn->query($sql);
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
    }
    if($_POST['tipo'] == 6)
    {
$sobre = $_POST['sobre'];
if (strpos($_POST['sobre'], '"') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['sobre'], "'") !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['sobre'], ';') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['sobre'], '*') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['sobre'], '`') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['sobre'], '=') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if(strlen($_POST['sobre']) < 10) { echo "para que possamos de ajudar, por favor escreva um texto bom o suficiente no campo o que você deseja conversar, com no minimo 10 letras";exit();}
if(strlen($_POST['sobre']) > 40) {echo "utilize no maximo 40 caracteres no campo o que você deseja conversar"; exit();}



$texto = $_POST['texto'];
if (strpos($_POST['texto'], '"') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], "'") !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], ';') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '*') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '`') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if (strpos($_POST['texto'], '=') !== false) {echo "Caracteres invalidos, por favor não utilize nenhum caractere especial";exit();}
if(strlen($_POST['texto']) < 30) { echo "para que possamos de ajudar, por favor escreva um texto bom o suficiente no campo escreva um texto, com no minimo 30 letras";exit();}
if(strlen($_POST['texto']) > 200) {echo "escreva um texto com no maximo 200 letras no campo escreva um texto"; exit();}



//$data = date('y-m-d');
$data = "CURRENT_TIMESTAMP";
$idsuporte = rand(1,999999999);
$sql = "INSERT INTO `suporte` (`id`, `data`, `nome_cliente`, `problema`, `categoria`, `Rua`, `status`, `Log`, `idcliente`, `Resposta`, `respostacliente`, `atendente`) VALUES (NULL, CURRENT_TIMESTAMP, '" . $nome . "', '" . $sobre . "', '6', '0', '0', '0', '" . $id . "', '0', '" . $texto . "', '0');";
$result = $conn->query($sql);
?><head> <meta http-equiv="refresh" content="0; URL='?criado=1'"/> </head><?php
    }
}
?>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
   
    
   
</body>
</html>
