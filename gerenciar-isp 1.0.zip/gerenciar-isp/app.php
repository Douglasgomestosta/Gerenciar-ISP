<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE); 
require 'sistema/db.php'; 


if($_SESSION['login'] == 1)
{
$conectadowifi = $_GET['conectadowifi'];
$nomewifi = $_GET['nomewifi'];
$velocidadewifi = $_GET['velocidadewifi'];
$servidordisponivel = $_GET['servidordisponivel'];
$macwifi = $_GET['macwifi'];
if($servidordisponivel == 0){$servidordisponivel = 1;}else{$servidordisponivel = "0";}
if($conectadowifi == "0" || $conectadowifi == "1")
{
    if($conectadowifi == "1")
    {
        $_SESSION['conectadowifi'] = "1";
        $_SESSION['nomewifi'] = $nomewifi;
        $_SESSION['velocidadewifi'] = $velocidadewifi;
        $_SESSION['servidordisponivel'] = $servidordisponivel;
        $_SESSION['macwifi'] = $macwifi;
    }else
    {
        $_SESSION['conectadowifi'] = "0";
        $_SESSION['nomewifi'] = "0";
        $_SESSION['velocidadewifi'] = "0"; 
        $_SESSION['macwifi'] = "0"; 
    }
}else
{
    $_SESSION['conectadowifi'] = "0";
}
echo "1";
}
else
{
    echo "0";
}
?>
